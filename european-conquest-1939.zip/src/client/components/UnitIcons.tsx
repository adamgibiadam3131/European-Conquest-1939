import React from 'react';
import type { AirUnitType, LandUnitType, NavalUnitType, ProductionItemType } from '../../shared/types.ts';

export const LandUnitSvg: React.FC<{ type: LandUnitType; className?: string }> = ({
  type,
  className = 'w-6 h-6',
}) => {
  switch (type) {
    case 'infantry':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="none">
          <path d="M4 14C4 9 7.5 5 12 5C16.5 5 20 9 20 14H4Z" fill="#65a30d" stroke="#ecfccb" strokeWidth="1.4" />
          <path d="M3 14H21" stroke="#ecfccb" strokeWidth="1.6" strokeLinecap="round" />
          <path d="M8 14L9 19H15L16 14" stroke="#d97706" strokeWidth="1.5" />
        </svg>
      );
    case 'tank':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="none">
          <rect x="3" y="13" width="18" height="5" rx="2.5" fill="#4d7c0f" stroke="#ecfccb" strokeWidth="1.4" />
          <path d="M7 13L9 8H15L17 13" fill="#65a30d" stroke="#ecfccb" strokeWidth="1.4" />
          <line x1="15" y1="10" x2="22" y2="10" stroke="#e2e8f0" strokeWidth="2" strokeLinecap="round" />
          <circle cx="7" cy="15.5" r="1" fill="#ecfccb" />
          <circle cx="12" cy="15.5" r="1" fill="#ecfccb" />
          <circle cx="17" cy="15.5" r="1" fill="#ecfccb" />
        </svg>
      );
    case 'antitank':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="none">
          <circle cx="9" cy="16" r="3" fill="#475569" stroke="#e2e8f0" strokeWidth="1.4" />
          <path d="M12 16L19 18" stroke="#e2e8f0" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M8 12L21 8" stroke="#f59e0b" strokeWidth="2.2" strokeLinecap="round" />
          <path d="M8 9V15" stroke="#94a3b8" strokeWidth="2" />
        </svg>
      );
    case 'artillery':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="none">
          <circle cx="9" cy="16" r="3.2" fill="#78716c" stroke="#f5f5f4" strokeWidth="1.4" />
          <path d="M11 16L18 19" stroke="#d6d3d1" strokeWidth="2" strokeLinecap="round" />
          <path d="M8 13L20 5" stroke="#fb923c" strokeWidth="2.6" strokeLinecap="round" />
        </svg>
      );
    case 'motorized':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="none">
          <rect x="3" y="8" width="12" height="8" rx="1.5" fill="#4d7c0f" stroke="#e2e8f0" strokeWidth="1.4" />
          <path d="M15 10H19L21 13V16H15V10Z" fill="#65a30d" stroke="#e2e8f0" strokeWidth="1.4" />
          <circle cx="7" cy="17.5" r="2" fill="#1e293b" stroke="#e2e8f0" strokeWidth="1.3" />
          <circle cx="18" cy="17.5" r="2" fill="#1e293b" stroke="#e2e8f0" strokeWidth="1.3" />
        </svg>
      );
    case 'antiair':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="none">
          <rect x="6" y="15" width="12" height="4" rx="1" fill="#475569" stroke="#e2e8f0" strokeWidth="1.3" />
          <path d="M10 15L15 5" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
          <path d="M13 15L19 7" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
  }
};

export const AirUnitSvg: React.FC<{ type: AirUnitType; className?: string }> = ({
  type,
  className = 'w-6 h-6',
}) => {
  const color =
    type === 'fighter' ? '#38bdf8' : type === 'cas' ? '#4ade80' : type === 'bomber' ? '#f59e0b' : '#c084fc';
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <path
        d="M12 3L14.5 9.5L21 12L14.5 14L13.5 20L12 18.5L10.5 20L9.5 14L3 12L9.5 9.5L12 3Z"
        fill={color}
        fillOpacity="0.25"
        stroke={color}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export const NavalUnitSvg: React.FC<{ type: NavalUnitType; className?: string }> = ({
  type,
  className = 'w-6 h-6',
}) => {
  if (type === 'submarine') {
    return (
      <svg viewBox="0 0 24 24" className={className} fill="none">
        <rect x="3" y="13" width="18" height="5" rx="2.5" fill="#334155" stroke="#38bdf8" strokeWidth="1.4" />
        <path d="M10 13V9H14V13" stroke="#38bdf8" strokeWidth="1.4" />
        <line x1="12" y1="9" x2="12" y2="6" stroke="#e2e8f0" strokeWidth="1.4" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none">
      <path d="M2 15H22L19 19H5L2 15Z" fill="#475569" stroke="#e2e8f0" strokeWidth="1.4" strokeLinejoin="round" />
      <rect x="7" y="10" width="9" height="5" fill="#64748b" stroke="#e2e8f0" strokeWidth="1.2" />
      {type === 'battleship' || type === 'carrier' ? (
        <line x1="11" y1="6" x2="11" y2="10" stroke="#fbbf24" strokeWidth="1.6" />
      ) : null}
    </svg>
  );
};

export const ProductionSvg: React.FC<{ item: ProductionItemType; className?: string }> = ({
  item,
  className = 'w-6 h-6',
}) => {
  switch (item) {
    case 'infantry_gear':
      return <LandUnitSvg type="infantry" className={className} />;
    case 'tank_parts':
      return <LandUnitSvg type="tank" className={className} />;
    case 'antitank_weapons':
      return <LandUnitSvg type="antitank" className={className} />;
    case 'artillery_guns':
      return <LandUnitSvg type="artillery" className={className} />;
    case 'consumer_goods':
      return (
        <svg viewBox="0 0 24 24" className={className} fill="none">
          <rect x="4" y="8" width="16" height="11" rx="2" fill="#38bdf8" fillOpacity="0.25" stroke="#38bdf8" strokeWidth="1.6" />
          <path d="M8 8V6C8 4.9 8.9 4 10 4H14C15.1 4 16 4.9 16 6V8" stroke="#e2e8f0" strokeWidth="1.5" />
          <line x1="9" y1="13" x2="15" y2="13" stroke="#facc15" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'fighters':
      return <AirUnitSvg type="fighter" className={className} />;
    case 'bombers':
      return <AirUnitSvg type="bomber" className={className} />;
    case 'warships':
      return <NavalUnitSvg type="battleship" className={className} />;
    case 'submarines':
      return <NavalUnitSvg type="submarine" className={className} />;
  }
};
