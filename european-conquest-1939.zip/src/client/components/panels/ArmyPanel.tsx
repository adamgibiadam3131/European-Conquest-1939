import React, { useState } from 'react';
import { Plus, Users, Lock, CheckCircle2, Star, Flag } from 'lucide-react';
import type { ClientAction, GameState, LandUnitType, MapDataStatic } from '../../../shared/types.ts';
import { LAND_UNITS } from '../../../shared/data/units.ts';
import { COUNTRIES } from '../../../shared/data/countries.ts';
import { getCommandersForCountry } from '../../../shared/data/commanders.ts';
import { formatCompact, getArmyTotal } from '../../../shared/utils/gameHelpers.ts';
import { LandUnitSvg } from '../UnitIcons.tsx';
import { CommanderPortrait } from '../CommanderPortrait.tsx';
import { PanelShell } from './PanelShell.tsx';

interface ArmyPanelProps {
  state: GameState;
  mapData: MapDataStatic;
  playerCountryId: string;
  onAction: (action: ClientAction) => void;
  onClose: () => void;
}

const UNIT_ORDER: LandUnitType[] = [
  'infantry',
  'tank',
  'antitank',
  'artillery',
  'motorized',
  'antiair',
];

export const ArmyPanel: React.FC<ArmyPanelProps> = ({
  state,
  mapData,
  playerCountryId,
  onAction,
  onClose,
}) => {
  const [tab, setTab] = useState<'units' | 'commanders'>('units');
  const country = state.countries[playerCountryId];
  const staticCountry = COUNTRIES[playerCountryId];
  if (!country) return null;

  const ownedProvs = Object.values(state.provinces)
    .filter((p) => p.controllerId === playerCountryId)
    .map((p) => ({
      id: p.id,
      name: mapData.provinces.find((mp) => mp.id === p.id)?.name || p.id,
      isCapital: p.id === staticCountry?.capitalProvinceId,
    }))
    .sort((a, b) => (a.isCapital ? -1 : b.isCapital ? 1 : a.name.localeCompare(b.name)));

  const effectiveRecruitId =
    country.recruitProvinceId && state.provinces[country.recruitProvinceId]?.controllerId === playerCountryId
      ? country.recruitProvinceId
      : ownedProvs[0]?.id || '';

  const myArmies = Object.values(state.armies).filter((a) => a.countryId === playerCountryId);
  const counts: Record<LandUnitType, number> = {
    infantry: 0,
    tank: 0,
    antitank: 0,
    artillery: 0,
    motorized: 0,
    antiair: 0,
  };
  for (const a of myArmies) {
    for (const ut of UNIT_ORDER) counts[ut] += a.units[ut];
  }
  const queuedCounts: Record<LandUnitType, number> = {
    infantry: 0,
    tank: 0,
    antitank: 0,
    artillery: 0,
    motorized: 0,
    antiair: 0,
  };
  for (const q of country.trainingQueue) queuedCounts[q.unitType] += 1;

  const commanders = getCommandersForCountry(playerCountryId, staticCountry?.region);

  return (
    <PanelShell
      title="Ordu ve Komutanlar"
      helpText="Buradan 1K (1.000 asker) gruplar halinde kara birlikleri eğitebilir, insan gücü seferberliği başlatabilir ve diplomasi puanı harcayarak tarihsel komutanların kilidini açıp ordularınıza atayabilirsiniz."
      onClose={onClose}
    >
      <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-3">
        <button
          onClick={() => setTab('units')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
            tab === 'units'
              ? 'bg-sky-600 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Kara Birimleri ({Object.values(counts).reduce((a, b) => a + b, 0)}K)
        </button>
        <button
          onClick={() => setTab('commanders')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
            tab === 'commanders'
              ? 'bg-sky-600 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Komutanlar ({Object.values(country.commanders).filter((c) => c.unlocked).length}/
          {commanders.length})
        </button>
      </div>

      {tab === 'units' ? (
        <div className="space-y-4">
          {/* Rally / Recruit Spawn City Picker */}
          <div className="px-4 py-3 rounded-xl bg-emerald-950/35 border border-emerald-600/40 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <Flag className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-emerald-200">
                  Ordu Oluşturma (Çıkış) Şehri
                </div>
                <div className="text-[11px] text-slate-400">
                  Eğittiğiniz tüm yeni birlikler bu şehirde toplanır. Haritada şehre tıklayıp da değiştirebilirsiniz.
                </div>
              </div>
            </div>
            <select
              value={effectiveRecruitId}
              onChange={(e) =>
                onAction({ type: 'SET_RECRUIT_PROVINCE', provinceId: e.target.value })
              }
              className="px-3 py-1.5 rounded-lg bg-slate-900 border border-emerald-500/60 text-xs font-bold text-white"
            >
              {ownedProvs.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} {p.isCapital ? '★' : ''}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2.5">
            {UNIT_ORDER.map((ut) => {
              const spec = LAND_UNITS[ut];
              const unlocked = !spec.requiredTech || country.researchedTechs.includes(spec.requiredTech);
              const canAfford = country.money >= spec.moneyCost && country.manpower >= spec.manpowerCost;
              const qCount = queuedCounts[ut];

              return (
                <div
                  key={ut}
                  className={`flex flex-wrap sm:flex-nowrap items-center justify-between gap-3 px-4 py-3 rounded-xl border ${
                    unlocked
                      ? 'bg-slate-950/60 border-slate-800'
                      : 'bg-slate-950/30 border-slate-800/50 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-[200px]">
                    <div className="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                      <LandUnitSvg type={ut} className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-100">{spec.name}</div>
                      <div className="text-[11px] text-slate-400">{spec.description}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="font-mono-num text-sm font-bold text-slate-100">
                        {counts[ut]}K{' '}
                        {qCount > 0 && (
                          <span className="text-amber-400 text-xs">+{qCount}K eğitimde</span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Bakım: -{spec.dailyUpkeep}/gün · Süre: {spec.trainDays}g
                      </div>
                    </div>

                    {unlocked ? (
                      <button
                        disabled={!canAfford}
                        onClick={() =>
                          onAction({
                            type: 'RECRUIT_UNIT',
                            unitType: ut,
                            provinceId: effectiveRecruitId || undefined,
                          })
                        }
                        className="px-3.5 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>1K Eğit</span>
                        <span className="font-mono-num text-[11px] text-amber-200">
                          {formatCompact(spec.moneyCost)} · 1K
                        </span>
                      </button>
                    ) : (
                      <div className="px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-[11px] text-amber-300 flex items-center gap-1.5 whitespace-nowrap">
                        <Lock className="w-3.5 h-3.5" />
                        Araştırma Gerekli
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom Summary Bar matching Reference Ordu Screen */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-sky-400" />
                  Seferberlik ve Asker Takviyesi
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Hızlı seferberlik ile insan gücü havuzunuza +10K asker ekler.
                </div>
              </div>
              <button
                disabled={country.money < 12000}
                onClick={() => onAction({ type: 'BUY_MANPOWER_CAMPAIGN' })}
                className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold whitespace-nowrap"
              >
                +10K Kazan (12K Para)
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold text-slate-200">Askerî Bakım Maliyetleri</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Aktif Ordu Sayısı: {myArmies.length} · Eğitim Kuyruğu: {country.trainingQueue.length}
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono-num text-base font-bold text-rose-400">
                  -{formatCompact(country.economy.armyUpkeep)} / Gün
                </div>
                <div className="text-[11px] text-slate-400">Toplam Kara Gideri</div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Commanders Tab matching Reference Commander Cards */
        <div className="space-y-3">
          {commanders.map((cmd) => {
            const cState = country.commanders[cmd.id] || {
              id: cmd.id,
              unlocked: false,
              assignedArmyId: null,
              level: 1,
              xp: 0,
            };
            const assignedArmy = cState.assignedArmyId ? state.armies[cState.assignedArmyId] : null;
            const canUnlock = country.diplomacyPoints >= cmd.unlockCost;

            return (
              <div
                key={cmd.id}
                className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-4 p-3.5 rounded-xl bg-slate-950/65 border border-slate-800"
              >
                <div className="flex items-center gap-3.5">
                  <CommanderPortrait commander={cmd} className="w-16 h-16" />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-display text-lg font-bold text-white">{cmd.name}</span>
                      {cmd.isLegacy && (
                        <span className="text-[10px] font-medium text-amber-300">· Özel / Legacy</span>
                      )}
                      {cState.unlocked && (
                        <span className="text-[11px] text-sky-300 font-mono-num flex items-center gap-0.5">
                          <Star className="w-3 h-3 text-amber-400" /> Sv.{cState.level}
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 mb-1.5">{cmd.title}</div>
                    <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs font-medium">
                      <span className="text-emerald-400">+{Math.round(cmd.attackBonus * 100)}% Saldırı</span>
                      <span className="text-sky-400">+{Math.round(cmd.defenseBonus * 100)}% Savunma</span>
                      <span className="text-amber-300">+{Math.round(cmd.tankBonus * 100)}% Tank</span>
                      <span className="text-lime-300">+{Math.round(cmd.infantryBonus * 100)}% Piyade</span>
                      <span className="text-indigo-300">+{Math.round(cmd.xpBonus * 100)}% Deneyim</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {!cState.unlocked ? (
                    <button
                      disabled={!canUnlock}
                      onClick={() => onAction({ type: 'UNLOCK_COMMANDER', commanderId: cmd.id })}
                      className="px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Kilidi Aç</span>
                      <span className="font-mono-num text-amber-200">{cmd.unlockCost} DP</span>
                    </button>
                  ) : (
                    <div className="flex flex-col items-end gap-1.5">
                      <div className="text-[11px] text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {assignedArmy
                          ? `Görevli: ${assignedArmy.name} (${getArmyTotal(assignedArmy.units)}K)`
                          : 'Atanmaya Hazır'}
                      </div>
                      <select
                        value={cState.assignedArmyId || ''}
                        onChange={(e) =>
                          onAction({
                            type: 'ASSIGN_COMMANDER',
                            commanderId: cmd.id,
                            armyId: e.target.value || null,
                          })
                        }
                        className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                      >
                        <option value="">Orduya Ata (Boşta)</option>
                        {myArmies.map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.name} ({getArmyTotal(a.units)}K)
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </PanelShell>
  );
};
