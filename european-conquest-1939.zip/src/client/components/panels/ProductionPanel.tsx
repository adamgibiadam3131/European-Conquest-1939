import React from 'react';
import { Factory, Minus, Plus, Lock } from 'lucide-react';
import type { ClientAction, GameState } from '../../../shared/types.ts';
import { PRODUCTION_ITEMS } from '../../../shared/data/units.ts';
import { formatCompact } from '../../../shared/utils/gameHelpers.ts';
import { ProductionSvg } from '../UnitIcons.tsx';
import { PanelShell } from './PanelShell.tsx';

interface ProductionPanelProps {
  state: GameState;
  playerCountryId: string;
  onAction: (action: ClientAction) => void;
  onClose: () => void;
}

export const ProductionPanel: React.FC<ProductionPanelProps> = ({
  state,
  playerCountryId,
  onAction,
  onClose,
}) => {
  const country = state.countries[playerCountryId];
  if (!country) return null;

  const totalWeight = Object.values(country.productionAllocations).reduce((a, b) => a + Math.max(0, b), 0);

  return (
    <PanelShell
      title="Üretim ve Gelir Dengesi"
      helpText="Fabrika kapasitenizi piyade ekipmanı, tank parçaları, topçu, tüketim malları ve araştırılan uçak/gemi hatlarına dağıtın. Tüketim malları günlük vergi geliri sağlar; askerî stoklar birlik eğitimini hızlandırır."
      onClose={onClose}
      widthClass="max-w-[1000px]"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Production Rows */}
        <div className="lg:col-span-8 space-y-2.5">
          {PRODUCTION_ITEMS.map((item) => {
            const locked = Boolean(item.requiredTech && !country.researchedTechs.includes(item.requiredTech));
            const weight = country.productionAllocations[item.id] || 0;
            const effectiveFactories =
              totalWeight > 0 ? Math.round(((weight / totalWeight) * country.totalFactories) * 10) / 10 : 0;
            const stock = country.stockpiles[item.id] || 0;
            const daily = country.dailyProduction[item.id] || 0;
            const stockPct =
              item.maxStock > 10000 ? 100 : Math.min(100, Math.round((stock / item.maxStock) * 100));

            return (
              <div
                key={item.id}
                className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  locked
                    ? 'bg-slate-950/35 border-slate-800/50 opacity-55'
                    : 'bg-slate-950/65 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                    <ProductionSvg item={item.id} className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold text-slate-100 truncate">{item.name}</span>
                      <span className="font-mono-num text-xs text-emerald-400">
                        +{daily.toFixed(1)}/gün
                      </span>
                    </div>

                    {/* Stock bar */}
                    <div className="flex items-center gap-2 mt-1">
                      <span className="font-mono-num text-[11px] text-slate-400 whitespace-nowrap">
                        Stok: {item.maxStock > 10000 ? `${formatCompact(stock)}/∞` : `${Math.round(stock)}/${item.maxStock}`}
                      </span>
                      <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 transition-all duration-150"
                          style={{ width: `${stockPct}%` }}
                        />
                      </div>
                    </div>

                    {/* Slider */}
                    {!locked && (
                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() =>
                            onAction({
                              type: 'SET_PRODUCTION_ALLOCATION',
                              item: item.id,
                              factories: Math.max(0, weight - 1),
                            })
                          }
                          className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-200"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <input
                          type="range"
                          min={0}
                          max={20}
                          value={weight}
                          onChange={(e) =>
                            onAction({
                              type: 'SET_PRODUCTION_ALLOCATION',
                              item: item.id,
                              factories: Number(e.target.value),
                            })
                          }
                          className="ec-slider flex-1"
                        />
                        <button
                          onClick={() =>
                            onAction({
                              type: 'SET_PRODUCTION_ALLOCATION',
                              item: item.id,
                              factories: Math.min(20, weight + 1),
                            })
                          }
                          className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-200"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Factory Assignment Counter */}
                <div className="flex items-center gap-2 shrink-0 justify-end">
                  {locked ? (
                    <span className="text-[11px] text-amber-300 flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5" /> Araştırma Gerekli
                    </span>
                  ) : (
                    <div className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 flex items-center gap-1.5">
                      <Factory className="w-3.5 h-3.5 text-amber-400" />
                      <span className="font-mono-num text-xs font-bold text-amber-300">
                        x {effectiveFactories}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Gelir Dengesi & Üretim İstatistikleri */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-4 rounded-xl bg-slate-950/75 border border-slate-800 space-y-3">
            <h3 className="font-display text-xl font-bold text-white border-b border-slate-800 pb-2">
              Gelir Dengesi
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-amber-300 font-medium">Vergiler:</span>
                <span className="font-mono-num font-bold text-emerald-400">
                  +{formatCompact(country.economy.taxIncome)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sky-300 font-medium">Tüketim Malları:</span>
                <span className="font-mono-num font-bold text-emerald-400">
                  +{formatCompact(country.economy.consumerGoodsIncome)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lime-300 font-medium">Askerî Giderler:</span>
                <span className="font-mono-num font-bold text-rose-400">
                  -{formatCompact(country.economy.armyUpkeep)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-indigo-300 font-medium">Deniz Kuvvetleri:</span>
                <span className="font-mono-num font-bold text-rose-400">
                  -{formatCompact(country.economy.navyUpkeep)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-medium">Hava & Altyapı:</span>
                <span className="font-mono-num font-bold text-rose-400">
                  -{formatCompact(country.economy.airUpkeep + country.economy.otherUpkeep)}
                </span>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-sm">
                <span className="font-bold text-white">Net Kazanç:</span>
                <span
                  className={`font-mono-num font-bold ${
                    country.economy.netIncome >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {country.economy.netIncome >= 0
                    ? `+${formatCompact(country.economy.netIncome)}`
                    : formatCompact(country.economy.netIncome)}
                  /gün
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/75 border border-slate-800 space-y-2.5">
            <h3 className="font-display text-xl font-bold text-white border-b border-slate-800 pb-2">
              Üretim İstatistikleri
            </h3>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Toplam Fabrika Kapasitesi:</span>
              <span className="font-mono-num font-bold text-amber-300">
                {country.totalFactories} Fabrika
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Fabrika Verimliliği:</span>
              <span className="font-mono-num font-bold text-emerald-400">
                %{country.economy.factoryEfficiency}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Vergi / Tüketim Birimi:</span>
              <span className="font-mono-num font-bold text-amber-300">+115 Para</span>
            </div>
            <p className="text-[11px] text-slate-400 pt-1 leading-relaxed">
              Yeni fabrikaları haritada istediğiniz kendi şehrinize tıklayarak inşa edebilirsiniz.
            </p>
          </div>
        </div>
      </div>
    </PanelShell>
  );
};
