import React, { useMemo, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Lock, Plus, X } from 'lucide-react';
import type { ClientAction, GameState, TechNode } from '../../../shared/types.ts';
import { TECH_TREE } from '../../../shared/data/techTree.ts';
import { formatCompact } from '../../../shared/utils/gameHelpers.ts';

interface ResearchPanelProps {
  state: GameState;
  playerCountryId: string;
  onAction: (action: ClientAction) => void;
  onClose: () => void;
}

const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V'];

function TechFlaskIcon({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} fill="none">
      <path
        d="M12 4H20M13.5 4V11L7.5 23.5C6.8 25 7.9 27 9.6 27H22.4C24.1 27 25.2 25 24.5 23.5L18.5 11V4"
        stroke="#090d16"
        strokeWidth="3.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13.5 4V11L7.5 23.5C6.8 25 7.9 27 9.6 27H22.4C24.1 27 25.2 25 24.5 23.5L18.5 11V4H13.5Z"
        fill="#cbd5e1"
      />
      <path d="M10.2 19H21.8L23.9 23.5C24.4 24.5 23.7 26 22.4 26H9.6C8.3 26 7.6 24.5 8.1 23.5L10.2 19Z" fill="#0ea5e9" />
      <circle cx="14" cy="22.5" r="1.3" fill="#bae6fd" />
      <circle cx="18" cy="21" r="1" fill="#bae6fd" />
      <rect x="11" y="3" width="10" height="2.4" rx="1.2" fill="#e2e8f0" stroke="#090d16" strokeWidth="1.5" />
    </svg>
  );
}

function TechArtwork({ techId, className = 'w-11 h-11' }: { techId: string; className?: string }) {
  switch (techId) {
    // Sayfa 1: Topçu / Anti-Tank
    case 'art_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <circle cx="14" cy="27" r="6" fill="#57534e" stroke="#090d16" strokeWidth="2.2" />
          <circle cx="14" cy="27" r="2.2" fill="#cbd5e1" />
          <path d="M18 28L33 32" stroke="#94a3b8" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M12 22L31 10" stroke="#a3e635" strokeWidth="4.5" strokeLinecap="round" />
          <path d="M12 22L31 10" stroke="#090d16" strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      );
    case 'art_aa':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="8" y="27" width="24" height="6" rx="2" fill="#475569" stroke="#090d16" strokeWidth="2" />
          <path d="M15 27L24 9" stroke="#84cc16" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M21 27L30 11" stroke="#38bdf8" strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="20" cy="25" r="4" fill="#65a30d" stroke="#090d16" strokeWidth="1.8" />
        </svg>
      );
    case 'art_2':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <circle cx="15" cy="28" r="5.5" fill="#44403c" stroke="#090d16" strokeWidth="2" />
          <path d="M19 29L35 32" stroke="#cbd5e1" strokeWidth="3" strokeLinecap="round" />
          <path d="M10 21L34 14" stroke="#f59e0b" strokeWidth="4.2" strokeLinecap="round" />
          <path d="M28 15.5L35 13.5" stroke="#ef4444" strokeWidth="4.2" strokeLinecap="round" />
        </svg>
      );

    // Sayfa 1: Piyade
    case 'inf_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M8 29L27 10L31 14L12 33L8 29Z" fill="#a16207" stroke="#090d16" strokeWidth="2" />
          <path d="M25 12L33 7" stroke="#cbd5e1" strokeWidth="2.8" strokeLinecap="round" />
        </svg>
      );
    case 'inf_motorized':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="5" y="15" width="19" height="12" rx="2" fill="#65a30d" stroke="#090d16" strokeWidth="2" />
          <path d="M24 18H31L35 23V27H24V18Z" fill="#84cc16" stroke="#090d16" strokeWidth="2" />
          <circle cx="12" cy="29" r="3.5" fill="#334155" stroke="#090d16" strokeWidth="2" />
          <circle cx="29" cy="29" r="3.5" fill="#334155" stroke="#090d16" strokeWidth="2" />
        </svg>
      );
    case 'inf_2':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M8 23C8 14 13 9 20 9C27 9 32 14 32 23H8Z" fill="#65a30d" stroke="#090d16" strokeWidth="2.2" />
          <path d="M6 23H34" stroke="#ecfccb" strokeWidth="2" strokeLinecap="round" />
          <path d="M13 23L15 31H25L27 23" stroke="#d97706" strokeWidth="2.2" />
        </svg>
      );
    case 'inf_3':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M13 11H27L30 18L26 20V31H14V20L10 18L13 11Z" fill="#84cc16" stroke="#090d16" strokeWidth="2.2" />
          <rect x="16" y="18" width="8" height="4" rx="1" fill="#4d7c0f" stroke="#090d16" strokeWidth="1.4" />
          <rect x="15" y="25" width="10" height="4" rx="1" fill="#4d7c0f" stroke="#090d16" strokeWidth="1.4" />
        </svg>
      );

    // Sayfa 1: Tanklar
    case 'tank_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="6" y="22" width="28" height="8" rx="4" fill="#4d7c0f" stroke="#090d16" strokeWidth="2" />
          <path d="M12 22L15 14H25L28 22" fill="#84cc16" stroke="#090d16" strokeWidth="2" />
          <line x1="25" y1="17" x2="36" y2="17" stroke="#e2e8f0" strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="12" cy="26" r="1.7" fill="#cbd5e1" />
          <circle cx="20" cy="26" r="1.7" fill="#cbd5e1" />
          <circle cx="28" cy="26" r="1.7" fill="#cbd5e1" />
        </svg>
      );
    case 'tank_2':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="5" y="22" width="29" height="8.5" rx="4" fill="#3f6212" stroke="#090d16" strokeWidth="2" />
          <path d="M10 22L14 13H26L29 22" fill="#65a30d" stroke="#090d16" strokeWidth="2" />
          <line x1="25" y1="16.5" x2="37" y2="15" stroke="#facc15" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="11" cy="26.5" r="1.8" fill="#e2e8f0" />
          <circle cx="17" cy="26.5" r="1.8" fill="#e2e8f0" />
          <circle cx="23" cy="26.5" r="1.8" fill="#e2e8f0" />
          <circle cx="29" cy="26.5" r="1.8" fill="#e2e8f0" />
        </svg>
      );
    case 'tank_3':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="4" y="21" width="31" height="9.5" rx="4.5" fill="#475569" stroke="#090d16" strokeWidth="2" />
          <path d="M9 21L13 12H27L30 21" fill="#d97706" stroke="#090d16" strokeWidth="2" />
          <line x1="26" y1="15.5" x2="38" y2="15.5" stroke="#fef08a" strokeWidth="4" strokeLinecap="round" />
          <circle cx="10" cy="26" r="2" fill="#94a3b8" />
          <circle cx="17" cy="26" r="2" fill="#94a3b8" />
          <circle cx="24" cy="26" r="2" fill="#94a3b8" />
          <circle cx="30" cy="26" r="2" fill="#94a3b8" />
        </svg>
      );

    // Sayfa 2: Altyapı & Ekonomi
    case 'eco_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M7 22L20 11L33 22V32H7V22Z" fill="#e2c69c" stroke="#090d16" strokeWidth="2" />
          <path d="M5 22L20 9L35 22" stroke="#b45309" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
          <rect x="17" y="24" width="6" height="8" fill="#78350f" />
        </svg>
      );
    case 'eco_slots':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M6 31V19L15 24V19L24 24V11H34V31H6Z" fill="#f59e0b" stroke="#090d16" strokeWidth="2" strokeLinejoin="round" />
          <circle cx="29" cy="7" r="2.2" fill="#cbd5e1" />
          <circle cx="33" cy="5" r="1.5" fill="#94a3b8" />
        </svg>
      );
    case 'eco_2':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M6 32V18L14 23V18L22 23V10H34V32H6Z" fill="#fbbf24" stroke="#090d16" strokeWidth="2" strokeLinejoin="round" />
          <rect x="10" y="26" width="4" height="3" fill="#090d16" />
          <rect x="18" y="26" width="4" height="3" fill="#090d16" />
          <rect x="26" y="16" width="4" height="4" fill="#38bdf8" />
        </svg>
      );
    case 'infra_logistics':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <line x1="12" y1="9" x2="12" y2="32" stroke="#94a3b8" strokeWidth="3" strokeLinecap="round" />
          <line x1="28" y1="9" x2="28" y2="32" stroke="#94a3b8" strokeWidth="3" strokeLinecap="round" />
          <line x1="8" y1="14" x2="32" y2="14" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <line x1="8" y1="21" x2="32" y2="21" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <line x1="8" y1="28" x2="32" y2="28" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );
    case 'infra_forts':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M7 22H33L30 32H10L7 22Z" fill="#78716c" stroke="#090d16" strokeWidth="2" />
          <path d="M10 15H30L33 22H7L10 15Z" fill="#a8a29e" stroke="#090d16" strokeWidth="2" />
          <rect x="14" y="18" width="12" height="3.5" rx="1" fill="#090d16" />
        </svg>
      );

    // Sayfa 2: Deniz Kuvvetleri
    case 'navy_destroyer':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M5 24H35L31 30H9L5 24Z" fill="#cbd5e1" stroke="#090d16" strokeWidth="2" />
          <rect x="14" y="17" width="12" height="7" fill="#94a3b8" stroke="#090d16" strokeWidth="1.8" />
          <path d="M12 30H28" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );
    case 'navy_submarine':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="5" y="22" width="30" height="8" rx="4" fill="#64748b" stroke="#090d16" strokeWidth="2" />
          <rect x="16" y="15" width="7" height="7" fill="#94a3b8" stroke="#090d16" strokeWidth="1.8" />
          <line x1="19" y1="15" x2="19" y2="10" stroke="#e2e8f0" strokeWidth="2" />
        </svg>
      );
    case 'navy_cruiser':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M4 24H36L32 31H8L4 24Z" fill="#94a3b8" stroke="#090d16" strokeWidth="2" />
          <rect x="11" y="17" width="16" height="7" fill="#cbd5e1" stroke="#090d16" strokeWidth="1.8" />
          <rect x="16" y="12" width="6" height="5" fill="#64748b" stroke="#090d16" strokeWidth="1.6" />
          <line x1="27" y1="19" x2="34" y2="17" stroke="#facc15" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );
    case 'navy_battleship':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M3 24H37L32 32H8L3 24Z" fill="#475569" stroke="#090d16" strokeWidth="2" />
          <rect x="10" y="16" width="18" height="8" fill="#94a3b8" stroke="#090d16" strokeWidth="2" />
          <rect x="15" y="10" width="8" height="6" fill="#cbd5e1" stroke="#090d16" strokeWidth="1.8" />
          <line x1="28" y1="18" x2="37" y2="15" stroke="#fbbf24" strokeWidth="3" strokeLinecap="round" />
          <line x1="10" y1="18" x2="4" y2="16" stroke="#fbbf24" strokeWidth="2.6" strokeLinecap="round" />
        </svg>
      );
    case 'navy_carrier':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M4 22H36L31 31H9L4 22Z" fill="#334155" stroke="#090d16" strokeWidth="2" />
          <rect x="3" y="18" width="34" height="4" rx="1" fill="#64748b" stroke="#090d16" strokeWidth="1.8" />
          <rect x="24" y="12" width="7" height="6" fill="#cbd5e1" stroke="#090d16" strokeWidth="1.6" />
          <path d="M9 17L16 14L14 17H9Z" fill="#38bdf8" />
        </svg>
      );

    // Sayfa 3: Radar & Roket
    case 'radar_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M10 14C14 10 22 10 26 14L18 22L10 14Z" fill="#38bdf8" stroke="#090d16" strokeWidth="2" />
          <line x1="18" y1="22" x2="18" y2="33" stroke="#cbd5e1" strokeWidth="3" />
          <line x1="12" y1="33" x2="24" y2="33" stroke="#94a3b8" strokeWidth="3" strokeLinecap="round" />
          <path d="M24 10C28 11 30 14 30 18" stroke="#bae6fd" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'radar_2':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="11" y="13" width="18" height="20" rx="3" fill="#4d7c0f" stroke="#090d16" strokeWidth="2" />
          <line x1="26" y1="13" x2="26" y2="6" stroke="#facc15" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="20" cy="21" r="3.5" fill="#38bdf8" stroke="#090d16" strokeWidth="1.6" />
          <line x1="15" y1="28" x2="25" y2="28" stroke="#cbd5e1" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'rocket_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M20 7C25 11 26 20 24 27H16C14 20 15 11 20 7Z" fill="#e2e8f0" stroke="#090d16" strokeWidth="2" />
          <path d="M20 7C22 9 23 11 23 13H17C17 11 18 9 20 7Z" fill="#ef4444" />
          <path d="M15 24L11 31L16 28M25 24L29 31L24 28" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="20" cy="31" r="2.2" fill="#facc15" />
        </svg>
      );
    case 'rocket_2':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="10" y="25" width="20" height="7" rx="2" fill="#475569" stroke="#090d16" strokeWidth="2" />
          <path d="M20 6C24 11 25 18 23 25H17C15 18 16 11 20 6Z" fill="#38bdf8" stroke="#090d16" strokeWidth="2" />
          <path d="M20 6L22 11H18L20 6Z" fill="#ef4444" />
          <circle cx="20" cy="18" r="2.2" fill="#fef08a" />
        </svg>
      );

    // Sayfa 3: Hava Kuvvetleri
    case 'air_fighter_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M20 6L23 17L35 21L23 24L22 33L20 31L18 33L17 24L5 21L17 17L20 6Z" fill="#94a3b8" stroke="#090d16" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );
    case 'air_cas_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M20 6L23.5 16L36 20L23.5 23.5L22.5 33L20 31L17.5 33L16.5 23.5L4 20L16.5 16L20 6Z" fill="#65a30d" stroke="#090d16" strokeWidth="2" strokeLinejoin="round" />
          <circle cx="14" cy="20" r="2" fill="#ef4444" />
          <circle cx="26" cy="20" r="2" fill="#ef4444" />
        </svg>
      );
    case 'air_bomber_1':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M20 5L24 15L37 19L37 22L24 24L23 34L20 31L17 34L16 24L3 22L3 19L16 15L20 5Z" fill="#d97706" stroke="#090d16" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );
    case 'air_jet':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M20 5L23 16L35 25L23 27L21.5 34L20 31L18.5 34L17 27L5 25L17 16L20 5Z" fill="#38bdf8" stroke="#090d16" strokeWidth="2" strokeLinejoin="round" />
          <circle cx="20" cy="35" r="2" fill="#f97316" />
        </svg>
      );

    // Sayfa 3: Nükleer Bombalar
    case 'nuke_physics':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <ellipse cx="20" cy="20" rx="13" ry="5.5" transform="rotate(30 20 20)" stroke="#facc15" strokeWidth="2.2" />
          <ellipse cx="20" cy="20" rx="13" ry="5.5" transform="rotate(-30 20 20)" stroke="#38bdf8" strokeWidth="2.2" />
          <circle cx="20" cy="20" r="3.5" fill="#84cc16" stroke="#090d16" strokeWidth="1.5" />
        </svg>
      );
    case 'nuke_uranium':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="8" y="16" width="24" height="14" rx="2" fill="#64748b" stroke="#090d16" strokeWidth="2" />
          <path d="M10 16C12 10 17 10 20 12C24 9 29 11 30 16H10Z" fill="#a3e635" stroke="#090d16" strokeWidth="1.8" />
          <circle cx="14" cy="31" r="3" fill="#1e293b" stroke="#090d16" strokeWidth="1.8" />
          <circle cx="26" cy="31" r="3" fill="#1e293b" stroke="#090d16" strokeWidth="1.8" />
        </svg>
      );
    case 'nuke_facility':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <rect x="11" y="10" width="18" height="22" rx="3" fill="#22c55e" stroke="#090d16" strokeWidth="2.2" />
          <line x1="10" y1="16" x2="30" y2="16" stroke="#090d16" strokeWidth="2" />
          <line x1="10" y1="26" x2="30" y2="26" stroke="#090d16" strokeWidth="2" />
          <circle cx="20" cy="21" r="3.2" fill="#facc15" stroke="#090d16" strokeWidth="1.5" />
        </svg>
      );
    case 'nuke_advanced':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M9 32L12 13H19L22 32H9Z" fill="#cbd5e1" stroke="#090d16" strokeWidth="2" />
          <path d="M21 32L23 18H30L32 32H21Z" fill="#94a3b8" stroke="#090d16" strokeWidth="2" />
          <circle cx="15" cy="9" r="2.2" fill="#e2e8f0" />
          <circle cx="26" cy="12" r="2.5" fill="#facc15" />
        </svg>
      );
    case 'nuke_weapon':
      return (
        <svg viewBox="0 0 40 40" className={className} fill="none">
          <path d="M9 12L17 15L29 27C32 30 30 33 27 30L15 18L12 10L9 12Z" fill="#65a30d" stroke="#090d16" strokeWidth="2" />
          <circle cx="23" cy="24" r="3.2" fill="#facc15" stroke="#090d16" strokeWidth="1.5" />
          <path d="M8 15L14 9" stroke="#f59e0b" strokeWidth="2.4" strokeLinecap="round" />
        </svg>
      );
    default:
      return <TechFlaskIcon className={className} />;
  }
}

export const ResearchPanel: React.FC<ResearchPanelProps> = ({
  state,
  playerCountryId,
  onAction,
  onClose,
}) => {
  const [page, setPage] = useState<0 | 1 | 2>(0);
  const [showHelp, setShowHelp] = useState(false);
  const [selectedTechId, setSelectedTechId] = useState<string>('inf_1');

  const country = state.countries[playerCountryId];
  const techMap = useMemo(() => new Map(TECH_TREE.map((t) => [t.id, t])), []);

  if (!country) return null;

  const slotsFull = country.activeResearch.length >= country.maxResearchSlots;
  const selectedTech = techMap.get(selectedTechId) || TECH_TREE[0];

  const handleNodeClick = (tech: TechNode) => {
    setSelectedTechId(tech.id);
  };

  const handleNodeDoubleClick = (tech: TechNode) => {
    const isDone = country.researchedTechs.includes(tech.id);
    const activeItem = country.activeResearch.find((r) => r.techId === tech.id);
    const prereqsMet = tech.prerequisites.every((p) => country.researchedTechs.includes(p));
    if (!isDone && !activeItem && prereqsMet && !slotsFull && country.money >= tech.cost) {
      onAction({ type: 'START_RESEARCH', techId: tech.id });
    }
  };

  const renderNodeCard = (techId: string) => {
    const tech = techMap.get(techId);
    if (!tech) return null;

    const isDone = country.researchedTechs.includes(tech.id);
    const activeItem = country.activeResearch.find((r) => r.techId === tech.id);
    const prereqsMet = tech.prerequisites.every((p) => country.researchedTechs.includes(p));
    const isSelected = selectedTechId === tech.id;
    const pct = activeItem
      ? Math.max(5, Math.min(100, Math.round(((activeItem.totalDays - activeItem.daysRemaining) / activeItem.totalDays) * 100)))
      : 0;

    return (
      <div key={tech.id} className="flex flex-col items-center relative z-10 select-none">
        <button
          type="button"
          onClick={() => handleNodeClick(tech)}
          onDoubleClick={() => handleNodeDoubleClick(tech)}
          title={`${tech.name} — ${tech.description}`}
          className={`relative w-[78px] h-[74px] sm:w-[86px] sm:h-[80px] rounded-xl flex flex-col items-center justify-center transition-all cursor-pointer ${
            isDone
              ? 'bg-emerald-900/75 border-2 border-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.4)]'
              : activeItem
              ? 'bg-sky-900/80 border-2 border-sky-400 shadow-[0_0_14px_rgba(56,189,248,0.5)]'
              : prereqsMet
              ? 'bg-[#485266]/95 border-2 border-[#090d16] hover:border-slate-300 shadow-[inset_0_1px_0_rgba(255,255,255,0.18)]'
              : 'bg-[#343c4d]/80 border-2 border-[#090d16] opacity-60'
          } ${isSelected ? 'ring-2 ring-amber-400 ring-offset-1 ring-offset-slate-900 scale-[1.03]' : ''}`}
        >
          <span className="font-serif font-bold text-sm text-white hud-text-shadow leading-none mb-0.5">
            {ROMAN[tech.tier] || tech.tier}
          </span>
          <TechArtwork techId={tech.id} className="w-10 h-10 sm:w-11 sm:h-11" />

          {isDone && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-emerald-500 border border-slate-950 flex items-center justify-center">
              <Check className="w-2.5 h-2.5 text-slate-950 stroke-[3]" />
            </span>
          )}
          {!isDone && !activeItem && !prereqsMet && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-slate-900/90 border border-slate-700 flex items-center justify-center">
              <Lock className="w-2.5 h-2.5 text-slate-400" />
            </span>
          )}

          {activeItem && (
            <div className="absolute inset-x-1 bottom-1 h-1.5 rounded-full bg-slate-950 overflow-hidden border border-slate-700">
              <div className="h-full bg-sky-400 transition-all" style={{ width: `${pct}%` }} />
            </div>
          )}
        </button>

        {/* Bottom Price / Status Capsule matching screenshot */}
        <div
          className={`-mt-1.5 px-2.5 py-0.5 rounded-md border-2 border-[#090d16] text-[11px] font-mono-num font-bold shadow ${
            isDone
              ? 'bg-emerald-950 text-emerald-300'
              : activeItem
              ? 'bg-sky-950 text-sky-300'
              : 'bg-[#2a3140] text-amber-300'
          }`}
        >
          {isDone ? 'Açık' : activeItem ? `%${pct}` : formatCompact(tech.cost)}
        </div>
      </div>
    );
  };

  const renderArrowControls = (side: 'left' | 'right') => (
    <div className="flex flex-col items-center gap-2 shrink-0 z-20">
      <button
        type="button"
        onClick={() => setPage((p) => ((side === 'left' ? p + 2 : p + 1) % 3) as 0 | 1 | 2)}
        className="w-11 h-14 rounded-xl hud-tile hover:brightness-110 active:scale-95 flex items-center justify-center text-white transition-all"
        title={side === 'left' ? 'Önceki Sayfa' : 'Sonraki Sayfa'}
      >
        {side === 'left' ? <ChevronLeft className="w-7 h-7 stroke-[3]" /> : <ChevronRight className="w-7 h-7 stroke-[3]" />}
      </button>
      <div className="flex items-center gap-1.5">
        {[0, 1, 2].map((idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => setPage(idx as 0 | 1 | 2)}
            className={`w-2.5 h-2.5 rounded-[3px] border border-[#090d16] transition-colors ${
              page === idx ? 'bg-white' : 'bg-slate-600/80 hover:bg-slate-400'
            }`}
            aria-label={`Sayfa ${idx + 1}`}
          />
        ))}
      </div>
    </div>
  );

  const selectedDone = country.researchedTechs.includes(selectedTech.id);
  const selectedActive = country.activeResearch.find((r) => r.techId === selectedTech.id);
  const selectedPrereqs = selectedTech.prerequisites.every((p) => country.researchedTechs.includes(p));
  const selectedCanStart =
    !selectedDone && !selectedActive && selectedPrereqs && !slotsFull && country.money >= selectedTech.cost;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 bg-slate-950/55 backdrop-blur-[2px]">
      <div className="animate-panel-in relative w-full max-w-[1040px] max-h-[94vh] flex flex-col bg-[#222a38]/92 backdrop-blur-md border-[3px] border-[#090d16] rounded-3xl shadow-2xl overflow-hidden text-slate-100">
        {/* Top Bar matching screenshot */}
        <div className="flex items-center justify-between px-4 sm:px-6 pt-3.5 pb-2">
          <button
            type="button"
            onClick={() => setShowHelp((v) => !v)}
            className="w-10 h-10 rounded-xl hud-tile hover:brightness-110 flex items-center justify-center font-display text-2xl font-bold text-amber-400 hud-text-shadow"
            title="Araştırma Yardımı"
          >
            ?
          </button>

          <div className="flex items-center gap-2.5">
            <TechFlaskIcon className="w-7 h-7 sm:w-8 sm:h-8" />
            <h2 className="font-serif text-2xl sm:text-3xl font-black tracking-wide text-white hud-text-shadow">
              Araştırma
            </h2>
            <TechFlaskIcon className="w-7 h-7 sm:w-8 sm:h-8" />
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-xl hud-tile hover:bg-rose-700/80 flex items-center justify-center text-white font-bold transition-colors"
            title="Kapat"
          >
            <X className="w-5 h-5 stroke-[2.6]" />
          </button>
        </div>

        {showHelp && (
          <div className="mx-6 mb-2 px-4 py-2 rounded-xl bg-slate-950/85 border border-amber-400/50 text-xs text-slate-200">
            Üç sayfa arasında oklarla geçiş yapın: <strong className="text-amber-300">Sayfa 1</strong> Kara Ordusu,{' '}
            <strong className="text-amber-300">Sayfa 2</strong> Altyapı & Deniz,{' '}
            <strong className="text-amber-300">Sayfa 3</strong> Savunma, Hava & Nükleer Bombalar. Bir düğüme tıklayıp
            inceleyin veya çift tıklayarak araştırmayı hemen başlatın.
          </div>
        )}

        {/* Tree Body + Side Carousel Arrows */}
        <div className="flex-1 flex items-center justify-between gap-2 sm:gap-4 px-3 sm:px-5 py-2 overflow-y-auto">
          {renderArrowControls('left')}

          {/* Page Content */}
          <div className="flex-1 min-w-0">
            {page === 0 && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-4 items-start">
                {/* Col 1: Tanklara karşı savunma */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3 text-center">
                    Tanklara karşı savunma
                  </h3>
                  <div className="relative flex flex-col items-center gap-4">
                    <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                    {renderNodeCard('art_1')}
                    {renderNodeCard('art_aa')}
                    {renderNodeCard('art_2')}
                  </div>
                </div>

                {/* Col 2: Piyade */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3 text-center">
                    Piyade
                  </h3>
                  <div className="relative flex flex-col items-center gap-3.5">
                    <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                    {renderNodeCard('inf_1')}
                    {renderNodeCard('inf_motorized')}
                    {renderNodeCard('inf_2')}
                    {renderNodeCard('inf_3')}
                  </div>
                </div>

                {/* Col 3: Tanklar */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3 text-center">
                    Tanklar
                  </h3>
                  <div className="relative flex flex-col items-center gap-4">
                    <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                    {renderNodeCard('tank_1')}
                    {renderNodeCard('tank_2')}
                    {renderNodeCard('tank_3')}
                  </div>
                </div>
              </div>
            )}

            {page === 1 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                {/* Left Group: Altyapı ve Ekonomi */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3">
                    Altyapı & Ekonomi
                  </h3>
                  <div className="flex items-start justify-center gap-6 sm:gap-10">
                    <div className="relative flex flex-col items-center gap-4">
                      <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                      {renderNodeCard('eco_1')}
                      {renderNodeCard('eco_slots')}
                      {renderNodeCard('eco_2')}
                    </div>
                    <div className="relative flex flex-col items-center gap-4">
                      <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                      {renderNodeCard('infra_logistics')}
                      {renderNodeCard('infra_forts')}
                    </div>
                  </div>
                </div>

                {/* Right Group: Deniz Kuvvetleri */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3">
                    Deniz Kuvvetleri
                  </h3>
                  <div className="flex flex-col items-center gap-4">
                    {renderNodeCard('navy_destroyer')}

                    {/* Branch connector line */}
                    <div className="w-[180px] h-[3px] bg-[#090d16] -my-1 rounded-full" />

                    <div className="flex items-start justify-center gap-6 sm:gap-8">
                      <div className="flex flex-col items-center">{renderNodeCard('navy_submarine')}</div>
                      <div className="relative flex flex-col items-center gap-3.5">
                        <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                        {renderNodeCard('navy_cruiser')}
                        {renderNodeCard('navy_battleship')}
                        {renderNodeCard('navy_carrier')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {page === 2 && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-4 items-start">
                {/* Col 1: Savunma (Radar & Roket) */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3">
                    Savunma
                  </h3>
                  <div className="flex items-start justify-center gap-5">
                    <div className="relative flex flex-col items-center gap-4">
                      <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                      {renderNodeCard('radar_1')}
                      {renderNodeCard('radar_2')}
                    </div>
                    <div className="relative flex flex-col items-center gap-4">
                      <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                      {renderNodeCard('rocket_1')}
                      {renderNodeCard('rocket_2')}
                    </div>
                  </div>
                </div>

                {/* Col 2: Hava Kuvvetleri */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3">
                    Hava Kuvvetleri
                  </h3>
                  <div className="relative flex flex-col items-center gap-3.5">
                    <div className="absolute top-8 bottom-8 w-[3px] bg-[#090d16]" />
                    {renderNodeCard('air_fighter_1')}
                    {renderNodeCard('air_cas_1')}
                    {renderNodeCard('air_bomber_1')}
                    {renderNodeCard('air_jet')}
                  </div>
                </div>

                {/* Col 3: Nükleer Bombalar */}
                <div className="flex flex-col items-center">
                  <h3 className="font-serif font-bold text-base sm:text-lg text-white hud-text-shadow mb-3">
                    Nükleer Bombalar
                  </h3>
                  <div className="relative grid grid-cols-2 gap-x-5 gap-y-3.5 items-start">
                    <div className="flex flex-col items-center gap-3.5">
                      {renderNodeCard('nuke_physics')}
                      {renderNodeCard('nuke_uranium')}
                      {renderNodeCard('nuke_facility')}
                    </div>
                    <div className="flex flex-col items-center gap-3.5 pt-8">
                      {renderNodeCard('nuke_advanced')}
                      {renderNodeCard('nuke_weapon')}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {renderArrowControls('right')}
        </div>

        {/* Bottom Research Slots & Selected Tech Inspector */}
        <div className="px-4 sm:px-6 py-3 bg-[#171d29]/90 border-t-2 border-[#090d16] flex flex-wrap items-center justify-between gap-4">
          {/* Left: Araştırma Alanları */}
          <div className="flex items-center gap-3">
            <div className="font-serif font-bold text-xs sm:text-sm leading-tight text-white hud-text-shadow">
              Araştırma
              <br />
              Alanları
            </div>

            <div className="flex items-center gap-2">
              {Array.from({ length: country.maxResearchSlots }).map((_, idx) => {
                const ar = country.activeResearch[idx];
                const tech = ar ? techMap.get(ar.techId) : null;
                const pct = ar
                  ? Math.max(4, Math.min(100, Math.round(((ar.totalDays - ar.daysRemaining) / ar.totalDays) * 100)))
                  : 0;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => tech && setSelectedTechId(tech.id)}
                    title={tech ? `${tech.name} (%${pct})` : 'Boş Araştırma Yuvası'}
                    className={`relative w-14 h-14 rounded-xl border-2 border-[#090d16] flex flex-col items-center justify-center transition-colors ${
                      ar ? 'bg-sky-950/90 border-sky-400' : 'bg-[#363f52]/90'
                    }`}
                  >
                    {tech ? (
                      <>
                        <TechArtwork techId={tech.id} className="w-8 h-8" />
                        <span className="text-[9px] font-mono-num font-bold text-sky-300">
                          %{pct} · {Math.ceil(ar!.daysRemaining)}g
                        </span>
                      </>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-semibold">Boş</span>
                    )}
                  </button>
                );
              })}

              {/* + Slot Button -> Jumps to Science Academy / War Industry slot upgrades */}
              <button
                type="button"
                onClick={() => {
                  setPage(1);
                  const nextSlotTech = !country.researchedTechs.includes('eco_slots')
                    ? 'eco_slots'
                    : 'eco_2';
                  setSelectedTechId(nextSlotTech);
                }}
                title="Yeni araştırma yuvası açmak için Bilim Akademileri teknolojisine git"
                className="w-14 h-14 rounded-xl bg-[#3c465c] hover:bg-[#4c5873] border-2 border-[#090d16] flex items-center justify-center text-white transition-colors"
              >
                <Plus className="w-7 h-7 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* Right: Compact Selected Technology Inspector & Start Button */}
          <div className="flex-1 min-w-[260px] flex items-center justify-between gap-3 px-3.5 py-2 rounded-xl bg-slate-950/75 border border-slate-700/80">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white truncate">{selectedTech.name}</span>
                <span className="text-[10px] font-mono-num text-amber-300 shrink-0">
                  {formatCompact(selectedTech.cost)} Para · {selectedTech.days} Gün
                </span>
              </div>
              <div className="text-[11px] text-slate-300 truncate">{selectedTech.description}</div>
              {selectedTech.prerequisites.length > 0 && !selectedPrereqs && (
                <div className="text-[10px] text-rose-300 truncate">
                  Gereken:{' '}
                  {selectedTech.prerequisites
                    .map((pid) => techMap.get(pid)?.name || pid)
                    .join(', ')}
                </div>
              )}
            </div>

            {selectedDone ? (
              <span className="px-3 py-1.5 rounded-lg bg-emerald-900/70 border border-emerald-500/60 text-emerald-300 text-xs font-bold shrink-0">
                Tamamlandı
              </span>
            ) : selectedActive ? (
              <span className="px-3 py-1.5 rounded-lg bg-sky-900/70 border border-sky-500/60 text-sky-200 font-mono-num text-xs font-bold shrink-0">
                {Math.ceil(selectedActive.daysRemaining)}g kaldı
              </span>
            ) : (
              <button
                type="button"
                disabled={!selectedCanStart}
                onClick={() => onAction({ type: 'START_RESEARCH', techId: selectedTech.id })}
                className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-bold shrink-0 transition-colors"
              >
                {!selectedPrereqs
                  ? 'Kilitli'
                  : slotsFull
                  ? 'Yuva Dolu'
                  : country.money < selectedTech.cost
                  ? 'Yetersiz Para'
                  : 'Araştır'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
