import React, { useState } from 'react';
import { Search, Swords, Handshake, ShieldCheck, Gift, Flag, Crown } from 'lucide-react';
import type { ClientAction, GameState } from '../../../shared/types.ts';
import { COUNTRIES, COUNTRY_LIST } from '../../../shared/data/countries.ts';
import { IDEOLOGY_DETAILS } from '../../../shared/data/focusTree.ts';
import { formatCompact, getArmyTotal, getRelation } from '../../../shared/utils/gameHelpers.ts';
import { CountryFlag } from '../CountryFlag.tsx';
import { PanelShell } from './PanelShell.tsx';

interface DiplomacyPanelProps {
  state: GameState;
  playerCountryId: string;
  onAction: (action: ClientAction) => void;
  onOpenPeaceModal: (targetCountryId: string) => void;
  onClose: () => void;
}

export const DiplomacyPanel: React.FC<DiplomacyPanelProps> = ({
  state,
  playerCountryId,
  onAction,
  onOpenPeaceModal,
  onClose,
}) => {
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string>(() => {
    const firstOther = COUNTRY_LIST.find((c) => c.id !== playerCountryId && !state.countries[c.id]?.eliminated);
    return firstOther?.id || 'GER';
  });

  const myCountry = state.countries[playerCountryId];
  const targetState = state.countries[selectedId];
  const targetStatic = COUNTRIES[selectedId];

  const list = COUNTRY_LIST.filter((c) => {
    if (c.id === playerCountryId) return false;
    const cs = state.countries[c.id];
    if (!cs || cs.eliminated) return false;
    return !search.trim() || c.name.toLowerCase().includes(search.toLowerCase());
  });

  const rel = targetState ? getRelation(state.relations, playerCountryId, selectedId) : null;

  const targetStrength = Object.values(state.armies)
    .filter((a) => a.countryId === selectedId)
    .reduce((s, a) => s + getArmyTotal(a.units), 0);
  const targetProvinces = Object.values(state.provinces).filter(
    (p) => p.controllerId === selectedId
  ).length;

  const targetAllies = COUNTRY_LIST.filter(
    (c) =>
      c.id !== selectedId &&
      !state.countries[c.id]?.eliminated &&
      getRelation(state.relations, selectedId, c.id).allied
  );
  const targetEnemies = COUNTRY_LIST.filter(
    (c) =>
      c.id !== selectedId &&
      !state.countries[c.id]?.eliminated &&
      getRelation(state.relations, selectedId, c.id).atWar
  );

  return (
    <PanelShell
      title="Diplomasi"
      helpText="Diğer ülkelerin liderlerini, yönetim biçimlerini ve güçlerini inceleyebilirsiniz. Savaş ilanı, ittifak kurma, saldırmazlık paktı ve barış anlaşması (bölge talebiyle) buradan yönetilir."
      onClose={onClose}
      widthClass="max-w-[960px]"
    >
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        {/* Left Country List */}
        <div className="md:col-span-5 flex flex-col gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Ülkeleri ara..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-sky-500"
            />
          </div>

          <div className="space-y-1.5 max-h-[54vh] overflow-y-auto pr-1">
            {list.map((c) => {
              const r = getRelation(state.relations, playerCountryId, c.id);
              const active = c.id === selectedId;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedId(c.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl border text-left transition-colors ${
                    active
                      ? 'bg-sky-600/25 border-sky-400 text-white'
                      : 'bg-slate-950/60 border-slate-800 text-slate-200 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <CountryFlag countryId={c.id} className="w-7 h-4.5" />
                    <span className="text-xs font-semibold truncate">{c.name}</span>
                  </div>
                  <div className="text-[11px] font-medium shrink-0">
                    {state.countries[c.id]?.vassalOfId === playerCountryId ? (
                      <span className="text-amber-300">Vasalımız</span>
                    ) : myCountry?.vassalOfId === c.id ? (
                      <span className="text-indigo-300">Efendimiz</span>
                    ) : r.atWar ? (
                      <span className="text-rose-400">Savaşta</span>
                    ) : r.allied ? (
                      <span className="text-emerald-400">Müttefik</span>
                    ) : r.nonAggression ? (
                      <span className="text-sky-400">Pakt</span>
                    ) : (
                      <span className="text-slate-400">Barış</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Country Dossier */}
        {targetState && targetStatic && rel && myCountry && (
          <div className="md:col-span-7 bg-slate-950/65 border border-slate-800 rounded-xl p-5 flex flex-col justify-between gap-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <CountryFlag countryId={targetStatic.id} className="w-12 h-8" />
                  <div>
                    <h3 className="font-display text-2xl font-bold text-white leading-none">
                      {targetStatic.name}
                    </h3>
                    <div className="text-xs text-slate-400 mt-1">
                      Lider: <span className="text-slate-200">{targetStatic.leader}</span> ·{' '}
                      <span>{IDEOLOGY_DETAILS[targetState.ideology].name}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right text-xs">
                  <div className="font-semibold text-slate-200">
                    {rel.atWar ? 'Savaş Durumu' : rel.allied ? 'Resmî Müttefik' : 'Barış'}
                  </div>
                  <div className="font-mono-num text-slate-400">İlişki: {rel.opinion}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-slate-400 text-[10px]">Bölge / Fabrika</div>
                  <div className="font-mono-num font-bold text-slate-100">
                    {targetProvinces} · {targetState.totalFactories} Fab.
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-slate-400 text-[10px]">Askerî Güç</div>
                  <div className="font-mono-num font-bold text-emerald-300">{targetStrength}K</div>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-slate-400 text-[10px]">Tahmini Hazine</div>
                  <div className="font-mono-num font-bold text-amber-300">
                    {formatCompact(targetState.money)}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-slate-400 text-[10px]">Nükleer</div>
                  <div className="font-mono-num font-bold text-lime-300">{targetState.nukes}</div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800">
                  <div className="text-emerald-400 font-semibold mb-1">Müttefikler</div>
                  <div className="text-slate-300">
                    {targetAllies.length > 0 ? targetAllies.map((a) => a.name).join(', ') : 'Hiç'}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800">
                  <div className="text-rose-400 font-semibold mb-1">Düşmanlar</div>
                  <div className="text-slate-300">
                    {targetEnemies.length > 0 ? targetEnemies.map((e) => e.name).join(', ') : 'Hiç'}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-900/70 border border-slate-800">
                  <div className="text-amber-300 font-semibold mb-1">Kukla / Efendi</div>
                  <div className="text-slate-300">
                    {targetState.vassalOfId
                      ? `Efendi: ${COUNTRIES[targetState.vassalOfId]?.name || targetState.vassalOfId}`
                      : COUNTRY_LIST.filter(
                          (c) => !state.countries[c.id]?.eliminated && state.countries[c.id]?.vassalOfId === selectedId
                        )
                          .map((c) => c.name)
                          .join(', ') || 'Bağımsız'}
                  </div>
                </div>
              </div>
            </div>

            {/* Diplomatic Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-3 border-t border-slate-800">
              {!rel.atWar ? (
                <>
                  {!rel.allied ? (
                    <button
                      disabled={myCountry.diplomacyPoints < 15}
                      onClick={() =>
                        onAction({
                          type: 'DIPLOMACY_ACTION',
                          targetCountryId: selectedId,
                          action: 'form_alliance',
                        })
                      }
                      className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                    >
                      <Handshake className="w-4 h-4" />
                      İttifak Kur (15 DP)
                    </button>
                  ) : (
                    <button
                      onClick={() =>
                        onAction({
                          type: 'DIPLOMACY_ACTION',
                          targetCountryId: selectedId,
                          action: 'break_alliance',
                        })
                      }
                      className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-rose-900 text-slate-200 text-xs font-semibold"
                    >
                      İttifakı Bozmaya Karar Ver
                    </button>
                  )}

                  <button
                    disabled={rel.nonAggression || myCountry.diplomacyPoints < 10}
                    onClick={() =>
                      onAction({
                        type: 'DIPLOMACY_ACTION',
                        targetCountryId: selectedId,
                        action: 'non_aggression',
                      })
                    }
                    className="py-2.5 px-3 rounded-xl bg-sky-700 hover:bg-sky-600 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    {rel.nonAggression ? 'Pakt Aktif' : 'Saldırmazlık Paktı (10 DP)'}
                  </button>

                  <button
                    disabled={myCountry.money < 5000}
                    onClick={() =>
                      onAction({
                        type: 'DIPLOMACY_ACTION',
                        targetCountryId: selectedId,
                        action: 'send_aid',
                      })
                    }
                    className="py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-600 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                  >
                    <Gift className="w-4 h-4" />
                    Yardım Gönder (5K Para)
                  </button>

                  {targetState.vassalOfId === playerCountryId ? (
                    <button
                      onClick={() =>
                        onAction({
                          type: 'DIPLOMACY_ACTION',
                          targetCountryId: selectedId,
                          action: 'release_vassal',
                        })
                      }
                      className="py-2.5 px-3 rounded-xl bg-amber-700 hover:bg-amber-600 text-white text-xs font-semibold flex items-center justify-center gap-2"
                    >
                      <Crown className="w-4 h-4" />
                      Vasal’ı Özgür Bırak
                    </button>
                  ) : myCountry.vassalOfId === selectedId ? (
                    <button
                      onClick={() =>
                        onAction({
                          type: 'DIPLOMACY_ACTION',
                          targetCountryId: selectedId,
                          action: 'declare_independence',
                        })
                      }
                      className="py-2.5 px-3 rounded-xl bg-rose-700 hover:bg-rose-600 text-white text-xs font-semibold flex items-center justify-center gap-2"
                    >
                      <Swords className="w-4 h-4" />
                      Bağımsızlık İlan Et (Savaş)
                    </button>
                  ) : (
                    <button
                      disabled={myCountry.diplomacyPoints < 20}
                      onClick={() =>
                        onAction({
                          type: 'DIPLOMACY_ACTION',
                          targetCountryId: selectedId,
                          action: 'declare_war',
                        })
                      }
                      className="py-2.5 px-3 rounded-xl bg-rose-700 hover:bg-rose-600 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                    >
                      <Swords className="w-4 h-4" />
                      Savaş İlan Et (20 DP)
                    </button>
                  )}
                </>
              ) : (
                <>
                  <button
                    onClick={() => onOpenPeaceModal(selectedId)}
                    className="sm:col-span-2 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg"
                  >
                    <Flag className="w-4 h-4" />
                    Barış Masasını Aç (Toprak / Vasal / Para / İnsangücü)
                  </button>
                  <button
                    disabled={myCountry.diplomacyPoints < 15}
                    onClick={() =>
                      onAction({
                        type: 'DIPLOMACY_ACTION',
                        targetCountryId: selectedId,
                        action: 'propose_peace',
                        demandProvinces: false,
                      })
                    }
                    className="sm:col-span-2 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2"
                  >
                    Hızlı Beyaz Barış Öner (15 DP)
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </PanelShell>
  );
};
