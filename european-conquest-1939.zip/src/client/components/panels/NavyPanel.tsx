import React, { useState } from 'react';
import { Anchor, Lock, Navigation } from 'lucide-react';
import type { ClientAction, GameState, MapDataStatic, NavalUnitType } from '../../../shared/types.ts';
import { NAVAL_UNITS } from '../../../shared/data/units.ts';
import { formatCompact } from '../../../shared/utils/gameHelpers.ts';
import { NavalUnitSvg } from '../UnitIcons.tsx';
import { PanelShell } from './PanelShell.tsx';

interface NavyPanelProps {
  state: GameState;
  mapData: MapDataStatic;
  playerCountryId: string;
  onAction: (action: ClientAction) => void;
  onClose: () => void;
}

const SHIP_TYPES: NavalUnitType[] = [
  'transport',
  'destroyer',
  'cruiser',
  'battleship',
  'carrier',
  'submarine',
];

export const NavyPanel: React.FC<NavyPanelProps> = ({
  state,
  mapData,
  playerCountryId,
  onAction,
  onClose,
}) => {
  const country = state.countries[playerCountryId];
  const ownedPorts = Object.values(state.provinces).filter(
    (p) => p.controllerId === playerCountryId && p.buildings.port > 0
  );
  const [selectedPortId, setSelectedPortId] = useState<string>(ownedPorts[0]?.id || '');
  const [targetSeaId, setTargetSeaId] = useState<string>(mapData.seaZones[0]?.id || '');

  if (!country) return null;

  const activePort = ownedPorts.find((p) => p.id === selectedPortId) || ownedPorts[0];
  const activePortName = activePort
    ? mapData.provinces.find((p) => p.id === activePort.id)?.name
    : null;
  const myFleets = Object.values(state.fleets).filter((f) => f.countryId === playerCountryId);
  const portQueue = activePort
    ? country.shipQueue.filter((q) => q.provinceId === activePort.id)
    : [];

  return (
    <PanelShell
      title="Limanlar ve Deniz Kuvvetleri"
      helpText="Kıyı limanlarınızdan Nakliye, Muhrip, Kruvazör, Zırhlı, Uçak Gemisi ve Denizaltı inşa edebilirsiniz. Nakliye gemileri deniz aşırı asker taşımacılığı sağlar; savaş filoları deniz bölgelerini kontrol eder."
      onClose={onClose}
      widthClass="max-w-[1040px]"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Ports List */}
        <div className="lg:col-span-3 bg-slate-950/70 border border-slate-800 rounded-xl p-3 space-y-1.5 max-h-[56vh] overflow-y-auto">
          <div className="text-xs font-semibold text-slate-300 px-1 mb-1">Kıyı Limanları</div>
          {ownedPorts.length === 0 ? (
            <div className="text-xs text-slate-400 p-2">
              Kontrolünüzde liman bulunmuyor. Kıyı bölgenize Liman inşa edebilirsiniz.
            </div>
          ) : (
            ownedPorts.map((port) => {
              const mp = mapData.provinces.find((p) => p.id === port.id);
              const qCount = country.shipQueue.filter((q) => q.provinceId === port.id).length;
              return (
                <button
                  key={port.id}
                  onClick={() => setSelectedPortId(port.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border text-xs transition-colors ${
                    activePort?.id === port.id
                      ? 'bg-sky-600/25 border-sky-400 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-200 hover:border-slate-600'
                  }`}
                >
                  <span>
                    {mp?.name} - {port.buildings.port}
                  </span>
                  {qCount > 0 && <span className="font-mono-num text-amber-300">{qCount}x</span>}
                </button>
              );
            })
          )}
        </div>

        {/* Middle: Ship Projects & Build Queue */}
        <div className="lg:col-span-5 space-y-3">
          {activePort && (
            <div className="px-3.5 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
              <span className="text-sm font-bold text-white">
                {activePortName} — Sv.{activePort.buildings.port} Liman
              </span>
              <span className="font-mono-num text-xs text-sky-300">
                Kapasite: {activePort.buildings.port * 4} Gemi
              </span>
            </div>
          )}

          <div className="space-y-2 max-h-[42vh] overflow-y-auto pr-1">
            {SHIP_TYPES.map((st) => {
              const spec = NAVAL_UNITS[st];
              const unlocked = !spec.requiredTech || country.researchedTechs.includes(spec.requiredTech);
              const canBuild = unlocked && activePort && country.money >= spec.moneyCost;

              return (
                <div
                  key={st}
                  className={`p-3 rounded-xl border flex items-center justify-between gap-2 ${
                    unlocked ? 'bg-slate-950/65 border-slate-800' : 'bg-slate-950/30 border-slate-800/50 opacity-55'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                      <NavalUnitSvg type={st} className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">{spec.name}</div>
                      <div className="text-[10px] text-slate-400">
                        Can: {spec.maxHp} · Saldırı: {spec.attack} · {spec.buildDays}g
                      </div>
                    </div>
                  </div>

                  {unlocked ? (
                    <button
                      disabled={!canBuild}
                      onClick={() =>
                        activePort &&
                        onAction({
                          type: 'BUILD_SHIP',
                          provinceId: activePort.id,
                          shipType: st,
                        })
                      }
                      className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold font-mono-num whitespace-nowrap"
                    >
                      İnşa ({formatCompact(spec.moneyCost)})
                    </button>
                  ) : (
                    <span className="text-[11px] text-amber-300 flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Kilitli
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {portQueue.length > 0 && (
            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs">
              <div className="font-semibold text-amber-300 mb-1">Yapım Sırası</div>
              {portQueue.map((q) => (
                <div key={q.id} className="flex justify-between text-slate-300 font-mono-num">
                  <span>{NAVAL_UNITS[q.shipType].name}</span>
                  <span>{Math.ceil(q.daysRemaining)} gün</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right: Active & Docked Fleets */}
        <div className="lg:col-span-4 bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 flex flex-col gap-3">
          <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
            <Anchor className="w-4 h-4 text-sky-400" />
            Filolar ve Deniz Devriyesi
          </div>

          <div className="space-y-2.5 flex-1 max-h-[44vh] overflow-y-auto pr-1">
            {myFleets.length === 0 ? (
              <div className="text-xs text-slate-400">Henüz aktif filonuz yok.</div>
            ) : (
              myFleets.map((fleet) => {
                const locName = fleet.isAtSea
                  ? mapData.seaZones.find((s) => s.id === fleet.locationId)?.name
                  : mapData.provinces.find((p) => p.id === fleet.locationId)?.name;

                return (
                  <div key={fleet.id} className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">{fleet.name}</span>
                      <span className="text-sky-300">{locName}</span>
                    </div>

                    <div className="space-y-1.5 max-h-32 overflow-y-auto">
                      {fleet.ships.map((sh) => (
                        <div key={sh.id} className="text-[11px]">
                          <div className="flex justify-between text-slate-300">
                            <span>{sh.name}</span>
                            <span className="font-mono-num">
                              {sh.hp}/{sh.maxHp}
                            </span>
                          </div>
                          <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden mt-0.5">
                            <div
                              className="h-full bg-emerald-500"
                              style={{ width: `${Math.round((sh.hp / sh.maxHp) * 100)}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex items-center gap-1.5">
                      <select
                        value={targetSeaId}
                        onChange={(e) => setTargetSeaId(e.target.value)}
                        className="flex-1 px-2 py-1 rounded bg-slate-800 border border-slate-700 text-[11px] text-slate-100"
                      >
                        {mapData.seaZones.map((sz) => (
                          <option key={sz.id} value={sz.id}>
                            {sz.name}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={() =>
                          onAction({
                            type: 'MOVE_FLEET',
                            fleetId: fleet.id,
                            targetSeaZoneId: targetSeaId,
                            mission: 'patrol',
                          })
                        }
                        className="px-2.5 py-1 rounded bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-semibold flex items-center gap-1 whitespace-nowrap"
                      >
                        <Navigation className="w-3 h-3" />
                        Çıkış
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </PanelShell>
  );
};
