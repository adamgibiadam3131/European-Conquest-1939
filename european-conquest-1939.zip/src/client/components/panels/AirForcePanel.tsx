import React, { useState } from 'react';
import { Lock, ArrowUpCircle, Plane } from 'lucide-react';
import type { AirMissionType, AirUnitType, ClientAction, GameState, MapDataStatic } from '../../../shared/types.ts';
import { AIR_UNITS } from '../../../shared/data/units.ts';
import { formatCompact } from '../../../shared/utils/gameHelpers.ts';
import { AirUnitSvg } from '../UnitIcons.tsx';
import { PanelShell } from './PanelShell.tsx';

interface AirForcePanelProps {
  state: GameState;
  mapData: MapDataStatic;
  playerCountryId: string;
  onAction: (action: ClientAction) => void;
  onClose: () => void;
}

const AIR_TYPES: AirUnitType[] = ['fighter', 'cas', 'bomber', 'recon'];

export const AirForcePanel: React.FC<AirForcePanelProps> = ({
  state,
  mapData,
  playerCountryId,
  onAction,
  onClose,
}) => {
  const country = state.countries[playerCountryId];
  const ownedAirbases = Object.values(state.provinces).filter(
    (p) => p.controllerId === playerCountryId && p.buildings.airbase > 0
  );
  const [selectedBaseId, setSelectedBaseId] = useState<string>(ownedAirbases[0]?.id || '');
  if (!country) return null;

  const activeBase = ownedAirbases.find((b) => b.id === selectedBaseId) || ownedAirbases[0];
  const baseWings = activeBase
    ? Object.values(state.airWings).filter((w) => w.provinceId === activeBase.id)
    : [];
  const basePlanes = baseWings.reduce((s, w) => s + w.count, 0);
  const baseCap = activeBase ? activeBase.buildings.airbase * 30 : 0;

  // Potential targets (all active war enemy provinces + own provinces)
  const targetOptions = mapData.provinces.filter((mp) => {
    const ps = state.provinces[mp.id];
    return ps && (ps.controllerId === playerCountryId || Object.values(state.battles).some((b) => b.provinceId === mp.id));
  });

  return (
    <PanelShell
      title="Hava Kuvvetleri"
      helpText="Önce Araştırma menüsünden uçak teknolojilerini açın. Hava üssü bulunan şehirlerinize Avcı, CAS, Bombardıman ve Keşif filoları konuşlandırıp kara savaşlarına hava desteği sağlayabilirsiniz."
      onClose={onClose}
      widthClass="max-w-[980px]"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Air Wings Deployment & Mission Controls */}
        <div className="lg:col-span-7 space-y-3">
          {AIR_TYPES.map((at) => {
            const spec = AIR_UNITS[at];
            const unlocked = !spec.requiredTech || country.researchedTechs.includes(spec.requiredTech);
            const totalOwned = Object.values(state.airWings)
              .filter((w) => w.countryId === playerCountryId && w.type === at)
              .reduce((s, w) => s + w.count, 0);
            const canDeploy =
              unlocked && activeBase && basePlanes + 10 <= baseCap && country.money >= spec.moneyCost;

            return (
              <div
                key={at}
                className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 ${
                  unlocked ? 'bg-slate-950/65 border-slate-800' : 'bg-slate-950/30 border-slate-800/50 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                    <AirUnitSvg type={at} className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">
                      {spec.name} <span className="font-mono-num text-sky-400">({totalOwned})</span>
                    </div>
                    <div className="text-[11px] text-slate-400">{spec.description}</div>
                  </div>
                </div>

                {unlocked ? (
                  <button
                    disabled={!canDeploy}
                    onClick={() =>
                      activeBase &&
                      onAction({
                        type: 'BUILD_AIR_WING',
                        provinceId: activeBase.id,
                        airType: at,
                      })
                    }
                    className="px-3.5 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold whitespace-nowrap font-mono-num"
                  >
                    +10 Uçak ({formatCompact(spec.moneyCost)})
                  </button>
                ) : (
                  <span className="text-xs text-amber-300 flex items-center gap-1 whitespace-nowrap">
                    <Lock className="w-3.5 h-3.5" /> Araştırma Gerekli
                  </span>
                )}
              </div>
            );
          })}

          {/* Stationed Wings & Mission Selector */}
          <div className="p-4 rounded-xl bg-slate-950/75 border border-slate-800 space-y-2.5">
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <Plane className="w-4 h-4 text-sky-400" />
              Üsteki Filolar ve Görev Ataması
            </div>
            {baseWings.length === 0 ? (
              <div className="text-xs text-slate-400">Seçili havaalanında henüz filo bulunmuyor.</div>
            ) : (
              baseWings.map((w) => (
                <div
                  key={w.id}
                  className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs"
                >
                  <div className="font-semibold text-slate-100">
                    {AIR_UNITS[w.type].name} ({w.count}x)
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={w.mission}
                      onChange={(e) =>
                        onAction({
                          type: 'SET_AIR_MISSION',
                          wingId: w.id,
                          mission: e.target.value as AirMissionType,
                          targetProvinceId: w.targetProvinceId || activeBase?.id || null,
                        })
                      }
                      className="px-2 py-1 rounded bg-slate-800 border border-slate-700 text-slate-200 text-xs"
                    >
                      <option value="air_superiority">Hava Üstünlüğü</option>
                      <option value="cas">Kara Desteği (CAS)</option>
                      <option value="bombing">Bombardıman</option>
                      <option value="recon">Keşif</option>
                      <option value="idle">Beklemede</option>
                    </select>
                    <select
                      value={w.targetProvinceId || ''}
                      onChange={(e) =>
                        onAction({
                          type: 'SET_AIR_MISSION',
                          wingId: w.id,
                          mission: w.mission,
                          targetProvinceId: e.target.value || null,
                        })
                      }
                      className="px-2 py-1 rounded bg-slate-800 border border-slate-700 text-slate-200 text-xs max-w-[140px]"
                    >
                      {targetOptions.map((tp) => (
                        <option key={tp.id} value={tp.id}>
                          {tp.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: Airbases List & Upgrade */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-slate-950/75 border border-slate-800 rounded-xl p-4 space-y-2 max-h-60 overflow-y-auto">
            <div className="text-xs font-semibold text-slate-300 mb-1">Hava Üsleriniz</div>
            {ownedAirbases.length === 0 ? (
              <div className="text-xs text-slate-400">
                Hava üssünüz yok. Haritadan bir bölgenize tıklayarak Hava Üssü inşa edin.
              </div>
            ) : (
              ownedAirbases.map((ab) => {
                const mp = mapData.provinces.find((p) => p.id === ab.id);
                const planes = Object.values(state.airWings)
                  .filter((w) => w.provinceId === ab.id)
                  .reduce((s, w) => s + w.count, 0);
                const isSel = activeBase?.id === ab.id;
                return (
                  <button
                    key={ab.id}
                    onClick={() => setSelectedBaseId(ab.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border text-xs transition-colors ${
                      isSel
                        ? 'bg-sky-600/25 border-sky-400 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-200 hover:border-slate-600'
                    }`}
                  >
                    <span className="font-medium">
                      {mp?.name} - Sv.{ab.buildings.airbase}
                    </span>
                    <span className="font-mono-num text-sky-300">{planes}x</span>
                  </button>
                );
              })
            )}
          </div>

          {activeBase && (
            <div className="p-4 rounded-xl bg-slate-950/75 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-bold text-white">
                  Seviye {activeBase.buildings.airbase} Havaalanı
                </h3>
                <span className="font-mono-num text-xs text-sky-300">
                  Kapasite: {basePlanes}/{baseCap}
                </span>
              </div>

              <div className="flex gap-1">
                {[1, 2, 3, 4, 5, 6].map((lvl) => (
                  <div
                    key={lvl}
                    className={`h-2.5 flex-1 rounded-sm ${
                      lvl <= activeBase.buildings.airbase ? 'bg-amber-400' : 'bg-slate-800'
                    }`}
                  />
                ))}
              </div>

              <button
                disabled={activeBase.buildings.airbase >= 6 || country.money < 10000}
                onClick={() =>
                  onAction({
                    type: 'BUILD_STRUCTURE',
                    provinceId: activeBase.id,
                    buildingType: 'airbase',
                  })
                }
                className="w-full py-2 rounded-lg bg-amber-600 hover:bg-amber-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <ArrowUpCircle className="w-4 h-4" />
                Havaalanını Yükselt (10K Para)
              </button>
            </div>
          )}
        </div>
      </div>
    </PanelShell>
  );
};
