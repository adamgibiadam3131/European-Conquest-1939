import React, { useState } from 'react';
import { HelpCircle, X } from 'lucide-react';

interface PanelShellProps {
  title: string;
  helpText: string;
  onClose: () => void;
  widthClass?: string;
  children: React.ReactNode;
}

export const PanelShell: React.FC<PanelShellProps> = ({
  title,
  helpText,
  onClose,
  widthClass = 'max-w-[940px]',
  children,
}) => {
  const [showHelp, setShowHelp] = useState(false);

  return (
    <div className="fixed inset-0 z-30 pointer-events-none flex items-center justify-center p-4 pt-16">
      <div
        className={`animate-panel-in pointer-events-auto relative w-full ${widthClass} max-h-[82vh] flex flex-col bg-slate-900/95 backdrop-blur-lg border-2 border-slate-950 ring-1 ring-slate-600/50 rounded-2xl shadow-2xl overflow-hidden`}
      >
        <div className="px-5 py-3.5 border-b border-slate-700/70 bg-slate-950/60 flex items-center justify-between gap-3">
          <button
            onClick={() => setShowHelp((v) => !v)}
            title="Yardım"
            className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-colors ${
              showHelp
                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                : 'bg-slate-800 border-slate-700 text-amber-300 hover:bg-slate-700'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          <h2 className="font-display text-2xl font-bold tracking-wide text-slate-100 text-center">
            {title}
          </h2>

          <button
            onClick={onClose}
            title="Paneli Kapat"
            className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:bg-rose-900/60 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {showHelp && (
          <div className="px-5 py-3 bg-amber-950/40 border-b border-amber-700/40 text-xs text-amber-100 leading-relaxed">
            {helpText}
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-5">{children}</div>
      </div>
    </div>
  );
};
