import React from 'react';
import { Check, Lock } from 'lucide-react';
import type { ClientAction, GameState, IdeologyType } from '../../../shared/types.ts';
import { FOCUS_TREE, IDEOLOGY_DETAILS } from '../../../shared/data/focusTree.ts';
import { formatCompact } from '../../../shared/utils/gameHelpers.ts';
import { PanelShell } from './PanelShell.tsx';

interface GovernmentPanelProps {
  state: GameState;
  playerCountryId: string;
  onAction: (action: ClientAction) => void;
  onClose: () => void;
}

const IDEOLOGY_ORDER: IdeologyType[] = ['communism', 'democracy', 'fascism', 'monarchy'];

export const GovernmentPanel: React.FC<GovernmentPanelProps> = ({
  state,
  playerCountryId,
  onAction,
  onClose,
}) => {
  const country = state.countries[playerCountryId];
  if (!country) return null;

  return (
    <PanelShell
      title="Hükümet ve İdeoloji Odakları"
      helpText="Ülkenizin yönetim biçimini değiştirebilir ve diplomasi puanı harcayarak ulusal odak ağacındaki reformları açabilirsiniz. Her ideolojinin kendine özgü ekonomi, insan gücü ve askerî avantajları vardır."
      onClose={onClose}
      widthClass="max-w-[1020px]"
    >
      {/* Top 4 Ideology Selector Row matching reference layout */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {IDEOLOGY_ORDER.map((id) => {
          const spec = IDEOLOGY_DETAILS[id];
          const isCurrent = country.ideology === id;
          const hasDiscount = country.completedFocuses.some(
            (fid) => FOCUS_TREE.find((f) => f.id === fid)?.effects.ideologyDiscount === id
          );
          const moneyCost = hasDiscount ? Math.round(spec.switchCostMoney * 0.5) : spec.switchCostMoney;
          const dipCost = hasDiscount ? Math.round(spec.switchCostDiplomacy * 0.5) : spec.switchCostDiplomacy;
          const canSwitch = !isCurrent && country.money >= moneyCost && country.diplomacyPoints >= dipCost;

          return (
            <div
              key={id}
              className={`p-3.5 rounded-xl border flex flex-col justify-between gap-2.5 ${
                isCurrent
                  ? 'bg-sky-950/45 border-sky-400 shadow-md'
                  : 'bg-slate-950/65 border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-lg font-bold text-white">{spec.name}</span>
                  {isCurrent && (
                    <span className="text-[11px] font-semibold text-emerald-400">Aktif</span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400 mt-1">{spec.description}</p>
                <ul className="mt-2 space-y-0.5 text-[11px] text-sky-300">
                  {spec.bonusesText.map((b) => (
                    <li key={b}>• {b}</li>
                  ))}
                </ul>
              </div>

              {!isCurrent && (
                <button
                  disabled={!canSwitch}
                  onClick={() => onAction({ type: 'SWITCH_IDEOLOGY', ideology: id })}
                  className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-sky-600 disabled:opacity-40 text-xs font-semibold text-slate-100 transition-colors font-mono-num"
                >
                  Geçiş: {formatCompact(moneyCost)} · {dipCost} DP
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Interconnected Focus Tree Grid (Rows 1-3, Cols 1-5) */}
      <div className="space-y-3">
        {[1, 2, 3].map((rowNum) => {
          const rowNodes = FOCUS_TREE.filter((f) => f.row === rowNum).sort((a, b) => a.col - b.col);
          return (
            <div key={rowNum} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              {rowNodes.map((node) => {
                const completed = country.completedFocuses.includes(node.id);
                const prereqsMet = node.prerequisites.every((p) => country.completedFocuses.includes(p));
                const canComplete = !completed && prereqsMet && country.diplomacyPoints >= node.costDiplomacy;

                return (
                  <div
                    key={node.id}
                    className={`p-3 rounded-xl border flex flex-col justify-between gap-2 ${
                      completed
                        ? 'bg-emerald-950/40 border-emerald-500/60'
                        : prereqsMet
                        ? 'bg-slate-950/75 border-slate-700'
                        : 'bg-slate-950/30 border-slate-800/50 opacity-60'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-100 leading-snug">{node.name}</div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-snug">{node.description}</p>
                    </div>

                    {completed ? (
                      <div className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1 pt-1">
                        <Check className="w-3.5 h-3.5" /> Tamamlandı
                      </div>
                    ) : !prereqsMet ? (
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 pt-1">
                        <Lock className="w-3 h-3" /> Ön odak gerekli
                      </div>
                    ) : (
                      <button
                        disabled={!canComplete}
                        onClick={() => onAction({ type: 'COMPLETE_FOCUS', focusId: node.id })}
                        className="w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-[11px] font-semibold font-mono-num transition-colors"
                      >
                        Uygula ({node.costDiplomacy} DP)
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </PanelShell>
  );
};
