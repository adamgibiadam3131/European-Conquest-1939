import React from 'react';
import { Swords, Trophy } from 'lucide-react';
import type { GameState, MapDataStatic } from '../../../shared/types.ts';
import { COUNTRIES } from '../../../shared/data/countries.ts';
import { CountryFlag } from '../CountryFlag.tsx';
import { PanelShell } from './PanelShell.tsx';

export const BattlesPanel: React.FC<{
  state: GameState;
  mapData: MapDataStatic;
  onSelectBattle: (battleId: string) => void;
  onClose: () => void;
}> = ({ state, mapData, onSelectBattle, onClose }) => {
  const activeBattles = Object.values(state.battles);

  return (
    <PanelShell
      title="Aktif Muharebeler ve Savaş Geçmişi"
      helpText="Cephelerde devam eden aktif çatışmaları ve tamamlanan muharebe kayıtlarını buradan takip edebilirsiniz."
      onClose={onClose}
      widthClass="max-w-[760px]"
    >
      <div className="space-y-5">
        <div>
          <h3 className="text-xs font-semibold text-rose-400 mb-2 flex items-center gap-1.5">
            <Swords className="w-4 h-4" /> Aktif Cepheler ({activeBattles.length})
          </h3>
          {activeBattles.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800 text-xs text-slate-400">
              Şu anda aktif bir kara muharebesi yok.
            </div>
          ) : (
            <div className="space-y-2">
              {activeBattles.map((b) => {
                const provName = mapData.provinces.find((p) => p.id === b.provinceId)?.name || b.provinceId;
                return (
                  <button
                    key={b.id}
                    onClick={() => onSelectBattle(b.id)}
                    className="w-full p-3.5 rounded-xl bg-slate-950/75 border border-rose-800/50 hover:border-rose-500 flex items-center justify-between gap-3 text-left transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <CountryFlag countryId={b.attackerCountryId} className="w-7 h-4.5" />
                      <span className="text-xs font-bold text-white">
                        {COUNTRIES[b.attackerCountryId]?.name} ({b.attacker.currentStrength}K)
                      </span>
                      <span className="text-rose-400 text-xs">vs</span>
                      <CountryFlag countryId={b.defenderCountryId} className="w-7 h-4.5" />
                      <span className="text-xs font-bold text-white">
                        {COUNTRIES[b.defenderCountryId]?.name} ({b.defender.currentStrength}K)
                      </span>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-semibold text-amber-300">{provName}</div>
                      <div className="font-mono-num text-[11px] text-slate-400">
                        İlerleme: %{Math.round(b.progress)}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div>
          <h3 className="text-xs font-semibold text-slate-300 mb-2">Savaş Geçmişi</h3>
          {state.battleHistory.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800 text-xs text-slate-400">
              Henüz tamamlanmış muharebe kaydı yok.
            </div>
          ) : (
            <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
              {state.battleHistory.map((h) => (
                <div
                  key={h.id}
                  className="px-3.5 py-2.5 rounded-lg bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-semibold text-white">{h.provinceName}</span> ·{' '}
                    <span className="text-emerald-400">
                      Kazanan: {COUNTRIES[h.winnerCountryId]?.name}
                    </span>
                  </div>
                  <div className="font-mono-num text-slate-400">
                    Kayıp: {h.attackerLosses}K / {h.defenderLosses}K · Gün {h.day}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </PanelShell>
  );
};

export const LeaderboardPanel: React.FC<{
  state: GameState;
  mapData: MapDataStatic;
  onClose: () => void;
}> = ({ state, mapData, onClose }) => {
  const totalLand = mapData.provinces.length;
  const counts: Record<string, number> = {};
  for (const p of Object.values(state.provinces)) {
    counts[p.controllerId] = (counts[p.controllerId] || 0) + 1;
  }

  const rows = Object.values(state.countries)
    .filter((c) => !c.eliminated)
    .map((c) => {
      const provs = counts[c.id] || 0;
      return {
        id: c.id,
        name: COUNTRIES[c.id]?.name || c.id,
        provs,
        pct: +((provs / totalLand) * 100).toFixed(1),
        isHuman: c.isHuman,
        casualtiesInflicted: c.totalCasualtiesInflicted,
      };
    })
    .sort((a, b) => b.provs - a.provs)
    .slice(0, 15);

  return (
    <PanelShell
      title={`Zafer Sıralaması (Hedef: %${state.victoryThreshold} Kara Kontrolü)`}
      helpText="Haritadaki toplam kara bölgelerinin belirlenen yüzdesini tek başınıza veya resmî müttefiklerinizle birlikte kontrol ettiğinizde zafer kazanırsınız. Deniz bölgeleri hesaba katılmaz."
      onClose={onClose}
      widthClass="max-w-[740px]"
    >
      <div className="space-y-2">
        {rows.map((r, idx) => (
          <div
            key={r.id}
            className="px-4 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between gap-3 text-xs"
          >
            <div className="flex items-center gap-3">
              <span className="font-mono-num w-6 text-slate-400 font-bold">#{idx + 1}</span>
              <CountryFlag countryId={r.id} className="w-7 h-4.5" />
              <span className="font-semibold text-white">
                {r.name} {r.isHuman && <span className="text-sky-400">· Oyuncu</span>}
              </span>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-28 h-2 bg-slate-800 rounded-full overflow-hidden hidden sm:block">
                <div
                  className="h-full bg-amber-400"
                  style={{ width: `${Math.min(100, (r.pct / state.victoryThreshold) * 100)}%` }}
                />
              </div>
              <div className="font-mono-num text-right min-w-[90px]">
                <span className="font-bold text-amber-300">%{r.pct}</span>{' '}
                <span className="text-slate-400">({r.provs})</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 p-3 rounded-xl bg-amber-950/30 border border-amber-700/40 text-xs text-amber-200 flex items-center gap-2">
        <Trophy className="w-4 h-4 text-amber-400 shrink-0" />
        Resmî müttefik ülkelerin toprak yüzdeleri zafer hesaplamasında toplanır.
      </div>
    </PanelShell>
  );
};
