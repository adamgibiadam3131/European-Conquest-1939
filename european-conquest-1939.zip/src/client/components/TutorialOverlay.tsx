import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, X, HelpCircle } from 'lucide-react';

interface TutorialOverlayProps {
  onClose: () => void;
}

const STEPS = [
  {
    title: '1. Ülkeni ve Başkentini İncele',
    body: 'Haritada kendi ülkenin şehirlerinden birine tıkla. Açılan bölge penceresinden şehirdeki fabrikaları, insan gücünü, savunma seviyesini ve ikmal durumunu görebilirsin.',
  },
  {
    title: '2. Fabrika ve Konut İnşa Et',
    body: 'Ekonomini büyütmek için şehirlerine “Fabrika” inşa et. Asker yetiştirmek için insan gücüne ihtiyacın olacak; “Evler” inşa ederek insan gücü kapasiteni artırabilirsin.',
  },
  {
    title: '3. Üretimi Düzenle',
    body: 'Sol menüdeki Üretim (dişli ikonu) sekmesinden fabrikalarını Piyade Donanımı, Tank Parçaları, Topçu ve Tüketim Malları arasında paylaştır. Tüketim malları günlük vergi gelirini artırır.',
  },
  {
    title: '4. Asker Yetiştir (1K Gruplar)',
    body: 'Ordu (miğfer ikonu) menüsünden +1K butonuna basarak Piyade, Tank, Anti-Tank ve Topçu birlikleri eğit. Her tıklama haritadaki orduna 1.000 asker ekler.',
  },
  {
    title: '5. Araştırma Başlat',
    body: 'Araştırma (beher ikonu) menüsünden 10 farklı kategoride teknoloji geliştir. İleri silah ve tank teknolojileri sayesinde sayıca az olsan bile daha güçlü düşmanları yenebilirsin.',
  },
  {
    title: '6. Tarihsel Komutan Aç ve Ata',
    body: 'Ordu menüsündeki “Komutanlar” sekmesinden diplomasi puanıyla komutanların kilidini aç ve bir orduna ata. Her komutan aynı anda yalnızca bir orduya komuta edebilir.',
  },
  {
    title: '7. Diplomasi ve Savaş İlanı',
    body: 'Diplomasi (el sıkışma ikonu) menüsünden komşu ülkelerle ittifak kurabilir veya savaş ilan edebilirsin. Müttefiklerin zafer yüzdesini seninle paylaşır.',
  },
  {
    title: '8. Ordunu Hareket Ettir ve Saldır',
    body: 'Haritadaki asker simgesine (ör. 30K) tıkla, “Hedef Bölge Seç” butonuna bas ve gitmek veya saldırmak istediğin bölgeye tıkla. Savaşlar sunucuda otomatik hesaplanır!',
  },
];

export const TutorialOverlay: React.FC<TutorialOverlayProps> = ({ onClose }) => {
  const [step, setStep] = useState(0);
  const current = STEPS[step];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-[520px] bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden">
        <div className="px-5 py-3.5 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-300 font-display text-xl font-bold">
            <HelpCircle className="w-5 h-5" />
            Hızlı Başlangıç Rehberi ({step + 1}/{STEPS.length})
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <h3 className="text-base font-bold text-white">{current.title}</h3>
          <p className="text-sm text-slate-300 leading-relaxed">{current.body}</p>

          <div className="flex gap-1 pt-2">
            {STEPS.map((_, i) => (
              <div
                key={i}
                className={`h-1.5 flex-1 rounded-full transition-colors ${
                  i <= step ? 'bg-sky-500' : 'bg-slate-800'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              disabled={step === 0}
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-semibold text-slate-200 flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4" />
              Geri
            </button>

            {step < STEPS.length - 1 ? (
              <button
                onClick={() => setStep((s) => s + 1)}
                className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-xs font-semibold text-white flex items-center gap-1"
              >
                İleri
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white"
              >
                Anladım, Oyuna Dön
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
