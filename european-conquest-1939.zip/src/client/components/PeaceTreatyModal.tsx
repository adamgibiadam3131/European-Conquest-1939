import React, { useMemo, useState } from 'react';
import { X, Crown, Flag, Coins, Users, MapPin, Check, AlertTriangle } from 'lucide-react';
import type { GameState, MapDataStatic, PeaceTreatyTerms } from '../../shared/types.ts';
import { COUNTRIES } from '../../shared/data/countries.ts';
import { calculatePeaceEvaluation, formatCompact } from '../../shared/utils/gameHelpers.ts';
import { CountryFlag } from './CountryFlag.tsx';

interface PeaceTreatyModalProps {
  state: GameState;
  mapData: MapDataStatic;
  playerCountryId: string;
  targetCountryId: string;
  onSubmit: (terms: PeaceTreatyTerms) => void;
  onClose: () => void;
}

export const PeaceTreatyModal: React.FC<PeaceTreatyModalProps> = ({
  state,
  mapData,
  playerCountryId,
  targetCountryId,
  onSubmit,
  onClose,
}) => {
  const [provTab, setProvTab] = useState<'demand' | 'cede'>('demand');
  const [demandProvinceIds, setDemandProvinceIds] = useState<string[]>([]);
  const [cedeProvinceIds, setCedeProvinceIds] = useState<string[]>([]);
  const [vassalizeTarget, setVassalizeTarget] = useState(false);
  const [becomeVassal, setBecomeVassal] = useState(false);
  const [demandMoney, setDemandMoney] = useState(0);
  const [demandManpower, setDemandManpower] = useState(0);

  const myCountry = state.countries[playerCountryId];
  const targetCountry = state.countries[targetCountryId];
  const targetStatic = COUNTRIES[targetCountryId];
  const myStatic = COUNTRIES[playerCountryId];

  const staticById = useMemo(() => new Map(mapData.provinces.map((p) => [p.id, p])), [mapData]);

  if (!myCountry || !targetCountry) return null;

  const targetProvinces = Object.values(state.provinces)
    .filter((p) => p.controllerId === targetCountryId)
    .sort((a, b) => {
      const sa = staticById.get(a.id);
      const sb = staticById.get(b.id);
      if (sa?.isCapital !== sb?.isCapital) return sa?.isCapital ? 1 : -1;
      return (sa?.name || a.id).localeCompare(sb?.name || b.id, 'tr');
    });

  const myProvinces = Object.values(state.provinces)
    .filter((p) => p.controllerId === playerCountryId)
    .sort((a, b) => (staticById.get(a.id)?.name || a.id).localeCompare(staticById.get(b.id)?.name || b.id, 'tr'));

  const terms: PeaceTreatyTerms = {
    demandProvinceIds,
    cedeProvinceIds,
    vassalizeTarget,
    becomeVassal,
    demandMoney,
    demandManpower,
  };

  const evalRes = calculatePeaceEvaluation(state, playerCountryId, targetCountryId, terms);
  const maxMoneyDemand = Math.max(0, Math.min(120000, Math.floor(targetCountry.money / 1000) * 1000));
  const maxManpowerDemand = Math.max(0, Math.min(35000, Math.floor(targetCountry.manpower / 1000) * 1000));

  const toggleDemandProv = (pid: string) => {
    setDemandProvinceIds((prev) => {
      if (prev.includes(pid)) return prev.filter((id) => id !== pid);
      // If vassalizing target, must leave at least 1 province on target
      if (vassalizeTarget && prev.length + 1 >= targetProvinces.length) return prev;
      return [...prev, pid];
    });
  };

  const toggleCedeProv = (pid: string) => {
    setCedeProvinceIds((prev) => {
      if (prev.includes(pid)) return prev.filter((id) => id !== pid);
      if (prev.length + 1 >= myProvinces.length) return prev;
      return [...prev, pid];
    });
  };

  const selectAllBorderTargetProvs = () => {
    const borders = targetProvinces
      .filter((tp) => {
        const sp = staticById.get(tp.id);
        return sp?.neighbors.some((nb) => state.provinces[nb]?.controllerId === playerCountryId);
      })
      .map((p) => p.id);
    if (vassalizeTarget && borders.length >= targetProvinces.length) {
      setDemandProvinceIds(borders.slice(0, Math.max(0, targetProvinces.length - 1)));
    } else {
      setDemandProvinceIds(borders);
    }
  };

  const canAffordDip = myCountry.diplomacyPoints >= 15;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/65 backdrop-blur-[3px]">
      <div className="animate-panel-in w-full max-w-[820px] max-h-[92vh] flex flex-col bg-[#1e2636]/96 border-[3px] border-[#090d16] rounded-3xl shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#141a26] border-b-2 border-[#090d16] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <CountryFlag countryId={playerCountryId} className="w-8 h-5" />
            <span className="text-amber-400 font-bold text-sm">⚔️ Barış Masası</span>
            <CountryFlag countryId={targetCountryId} className="w-8 h-5" />
            <div>
              <h3 className="font-display text-xl sm:text-2xl font-bold text-white leading-none">
                {myStatic?.name} – {targetStatic?.name} Antlaşması
              </h3>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Toprak devri, vasallaştırma, para ve insan gücü tazminatı talep edin
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl hud-tile hover:bg-rose-700/80 text-white flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Warscore vs Cost Gauge */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border-2 border-[#090d16] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-4">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Savaş Skoru</div>
                <div
                  className={`font-mono-num text-xl font-black ${
                    evalRes.warScore >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {evalRes.warScore > 0 ? `+${evalRes.warScore}` : evalRes.warScore}
                </div>
              </div>
              <div className="text-slate-600 text-lg font-bold">/</div>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Talep Maliyeti</div>
                <div className="font-mono-num text-xl font-black text-amber-300">{evalRes.treatyCost}</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs font-semibold">
              {targetCountry.isHuman ? (
                <span className="px-3 py-1.5 rounded-xl bg-sky-950 border border-sky-500/60 text-sky-200">
                  İnsan Oyuncu: Teklif karşı tarafa iletilecek
                </span>
              ) : evalRes.willAiAccept ? (
                <span className="px-3 py-1.5 rounded-xl bg-emerald-950/90 border border-emerald-500/70 text-emerald-300 flex items-center gap-1.5">
                  <Check className="w-4 h-4" />
                  Yapay Zeka Kabul Edecek
                </span>
              ) : (
                <span className="px-3 py-1.5 rounded-xl bg-rose-950/90 border border-rose-500/70 text-rose-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  Reddedilebilir (Skor Yetersiz)
                </span>
              )}
            </div>
          </div>

          {/* Vassal Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                const next = !vassalizeTarget;
                setVassalizeTarget(next);
                if (next) {
                  setBecomeVassal(false);
                  if (demandProvinceIds.length >= targetProvinces.length) {
                    setDemandProvinceIds((prev) => prev.slice(0, Math.max(0, targetProvinces.length - 1)));
                  }
                }
              }}
              className={`p-3 rounded-2xl border-2 text-left transition-all flex items-center justify-between gap-2 ${
                vassalizeTarget
                  ? 'bg-amber-950/75 border-amber-400 shadow-[0_0_12px_rgba(250,204,21,0.3)]'
                  : 'bg-slate-950/65 border-[#090d16] hover:border-slate-500'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Crown className={`w-5 h-5 ${vassalizeTarget ? 'text-amber-300' : 'text-slate-400'}`} />
                <div>
                  <div className="text-xs font-bold text-white">Hedefi Vasallaştır</div>
                  <div className="text-[10px] text-slate-300">
                    {targetStatic?.name} kukla devletiniz olur (+%20 vergi & askerî geçiş)
                  </div>
                </div>
              </div>
              <span className="font-mono-num text-[11px] font-bold text-amber-300 shrink-0">+35 Skor</span>
            </button>

            <button
              type="button"
              onClick={() => {
                const next = !becomeVassal;
                setBecomeVassal(next);
                if (next) setVassalizeTarget(false);
              }}
              className={`p-3 rounded-2xl border-2 text-left transition-all flex items-center justify-between gap-2 ${
                becomeVassal
                  ? 'bg-sky-950/75 border-sky-400 shadow-[0_0_12px_rgba(56,189,248,0.3)]'
                  : 'bg-slate-950/65 border-[#090d16] hover:border-slate-500'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Flag className={`w-5 h-5 ${becomeVassal ? 'text-sky-300' : 'text-slate-400'}`} />
                <div>
                  <div className="text-xs font-bold text-white">Vasal Olmayı Kabul Et</div>
                  <div className="text-[10px] text-slate-300">
                    Zor durumdan kurtulmak için {targetStatic?.name} himayesine girin
                  </div>
                </div>
              </div>
              <span className="font-mono-num text-[11px] font-bold text-emerald-300 shrink-0">-55 Skor</span>
            </button>
          </div>

          {/* Money & Manpower Reparations */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border-2 border-[#090d16] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200 flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400" />
                  Para Tazminatı İste
                </span>
                <span className="font-mono-num font-bold text-amber-300">
                  {formatCompact(demandMoney)} / {formatCompact(maxMoneyDemand)}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={maxMoneyDemand}
                step={1000}
                value={demandMoney}
                onChange={(e) => setDemandMoney(Number(e.target.value))}
                className="w-full ec-slider"
              />
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/70 border-2 border-[#090d16] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-400" />
                  İnsangücü (Manpower) İste
                </span>
                <span className="font-mono-num font-bold text-emerald-300">
                  {formatCompact(demandManpower)} / {formatCompact(maxManpowerDemand)}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={maxManpowerDemand}
                step={1000}
                value={demandManpower}
                onChange={(e) => setDemandManpower(Number(e.target.value))}
                className="w-full ec-slider"
              />
            </div>
          </div>

          {/* Province Selector */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border-2 border-[#090d16] space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setProvTab('demand')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                    provTab === 'demand'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Toprak İste ({demandProvinceIds.length}/{targetProvinces.length})
                </button>
                <button
                  type="button"
                  onClick={() => setProvTab('cede')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                    provTab === 'cede'
                      ? 'bg-sky-600 text-white'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Toprak Ver ({cedeProvinceIds.length}/{myProvinces.length})
                </button>
              </div>

              {provTab === 'demand' ? (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={selectAllBorderTargetProvs}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-semibold text-sky-300"
                  >
                    Sınırları Seç
                  </button>
                  <button
                    type="button"
                    onClick={() => setDemandProvinceIds([])}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-semibold text-slate-300"
                  >
                    Temizle
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setCedeProvinceIds([])}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-semibold text-slate-300"
                >
                  Temizle
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-[190px] overflow-y-auto pr-1">
              {(provTab === 'demand' ? targetProvinces : myProvinces).map((prov) => {
                const sp = staticById.get(prov.id);
                const selected =
                  provTab === 'demand'
                    ? demandProvinceIds.includes(prov.id)
                    : cedeProvinceIds.includes(prov.id);
                return (
                  <button
                    key={prov.id}
                    type="button"
                    onClick={() =>
                      provTab === 'demand' ? toggleDemandProv(prov.id) : toggleCedeProv(prov.id)
                    }
                    className={`px-2.5 py-2 rounded-xl border text-left transition-all text-xs ${
                      selected
                        ? provTab === 'demand'
                          ? 'bg-emerald-900/75 border-emerald-400 text-white'
                          : 'bg-sky-900/75 border-sky-400 text-white'
                        : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:border-slate-500'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-semibold truncate flex items-center gap-1">
                        <MapPin className="w-3 h-3 shrink-0 text-amber-400" />
                        {sp?.name || prov.id}
                      </span>
                      {sp?.isCapital && <span className="text-[10px]">★</span>}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5 font-mono-num">
                      {prov.buildings.factory} Fabrika
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-[#141a26] border-t-2 border-[#090d16] flex items-center justify-between gap-3">
          <div className="text-xs text-slate-300">
            Mevcut Diplomasi Puanı:{' '}
            <span className="font-mono-num font-bold text-amber-300">
              {Math.floor(myCountry.diplomacyPoints)} DP
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200"
            >
              Vazgeç
            </button>
            <button
              type="button"
              disabled={!canAffordDip}
              onClick={() => {
                onSubmit(terms);
                onClose();
              }}
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 border-2 border-[#090d16] text-xs font-bold text-white shadow-lg"
            >
              Barış Teklifi Gönder (15 DP)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
