import React from 'react';
import { COUNTRIES } from '../../shared/data/countries.ts';

interface CountryFlagProps {
  countryId: string;
  className?: string;
}

export const CountryFlag: React.FC<CountryFlagProps> = ({ countryId, className = 'w-8 h-5' }) => {
  const c = COUNTRIES[countryId];
  if (!c) {
    return (
      <div className={`${className} rounded-sm bg-slate-700 border border-slate-500/40 shrink-0`} />
    );
  }

  const [c1 = '#334155', c2 = '#FFFFFF', c3 = '#DC2626'] = c.flagColors;

  return (
    <svg
      viewBox="0 0 36 24"
      className={`${className} rounded-[3px] border border-white/20 shadow-sm shrink-0`}
      aria-label={c.name}
    >
      {c.flagLayout === 'horizontal' && (
        <>
          <rect x="0" y="0" width="36" height={c.flagColors.length === 2 ? 12 : 8} fill={c1} />
          <rect
            x="0"
            y={c.flagColors.length === 2 ? 12 : 8}
            width="36"
            height={c.flagColors.length === 2 ? 12 : 8}
            fill={c2}
          />
          {c.flagColors.length >= 3 && <rect x="0" y="16" width="36" height="8" fill={c3} />}
        </>
      )}

      {c.flagLayout === 'vertical' && (
        <>
          <rect x="0" y="0" width="12" height="24" fill={c1} />
          <rect x="12" y="0" width="12" height="24" fill={c2} />
          <rect x="24" y="0" width="12" height="24" fill={c3} />
        </>
      )}

      {c.flagLayout === 'bicolor' && (
        <>
          <rect x="0" y="0" width="13" height="24" fill={c1} />
          <rect x="13" y="0" width="23" height="24" fill={c2} />
          <circle cx="13" cy="12" r="4" fill={c3 || '#FACC15'} opacity="0.9" />
        </>
      )}

      {c.flagLayout === 'cross' && (
        <>
          <rect x="0" y="0" width="36" height="24" fill={c1} />
          {c.id === 'UK' ? (
            <>
              <line x1="0" y1="0" x2="36" y2="24" stroke="#FFFFFF" strokeWidth="4.5" />
              <line x1="36" y1="0" x2="0" y2="24" stroke="#FFFFFF" strokeWidth="4.5" />
              <line x1="0" y1="0" x2="36" y2="24" stroke="#DC2626" strokeWidth="2" />
              <line x1="36" y1="0" x2="0" y2="24" stroke="#DC2626" strokeWidth="2" />
              <rect x="14.5" y="0" width="7" height="24" fill="#FFFFFF" />
              <rect x="0" y="8.5" width="36" height="7" fill="#FFFFFF" />
              <rect x="16" y="0" width="4" height="24" fill="#DC2626" />
              <rect x="0" y="10" width="36" height="4" fill="#DC2626" />
            </>
          ) : c.id === 'SWI' ? (
            <>
              <rect x="15" y="5" width="6" height="14" fill={c2} />
              <rect x="11" y="9" width="14" height="6" fill={c2} />
            </>
          ) : (
            <>
              <rect x="15" y="0" width="6" height="24" fill={c2} />
              <rect x="0" y="9" width="36" height="6" fill={c2} />
            </>
          )}
        </>
      )}

      {c.flagLayout === 'nordic' && (
        <>
          <rect x="0" y="0" width="36" height="24" fill={c1} />
          <rect x="10" y="0" width="6" height="24" fill={c2} />
          <rect x="0" y="9" width="36" height="6" fill={c2} />
          {c.flagColors.length >= 3 && (
            <>
              <rect x="11.5" y="0" width="3" height="24" fill={c3} />
              <rect x="0" y="10.5" width="36" height="3" fill={c3} />
            </>
          )}
        </>
      )}

      {c.flagLayout === 'crescent' && (
        <>
          <rect x="0" y="0" width="36" height="24" fill={c1} />
          <circle cx="15.5" cy="12" r="5.5" fill={c2} />
          <circle cx="17.2" cy="12" r="4.3" fill={c1} />
          <polygon points="22.5,12 24.1,10.6 23.6,12.5 25.1,13.6 23.2,13.6" fill={c2} />
        </>
      )}

      {c.flagLayout === 'canton' && (
        <>
          <rect x="0" y="0" width="36" height="24" fill={c1} />
          {c.id === 'CZE' ? (
            <polygon points="0,0 16,12 0,24" fill={c3} />
          ) : (
            <circle cx="10" cy="8" r="3.4" fill={c2} />
          )}
        </>
      )}

      {c.flagLayout === 'eagle' && (
        <>
          <rect x="0" y="0" width="36" height="24" fill={c1} />
          <circle cx="18" cy="12" r="6.5" fill={c2} />
          <path d="M18 7.5 L21 12 L18 16.5 L15 12 Z" fill={c3 || '#111827'} />
        </>
      )}
    </svg>
  );
};
