import React from 'react';
import type { CommanderStatic } from '../../shared/types.ts';

interface CommanderPortraitProps {
  commander: CommanderStatic;
  className?: string;
}

export const CommanderPortrait: React.FC<CommanderPortraitProps> = ({
  commander,
  className = 'w-14 h-14',
}) => {
  const s = commander.portraitStyle;
  return (
    <svg
      viewBox="0 0 64 64"
      className={`${className} rounded-lg border border-slate-600/60 bg-slate-800 shrink-0 shadow-inner`}
      aria-label={commander.name}
    >
      <defs>
        <linearGradient id={`bg_${commander.id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#334155" />
          <stop offset="100%" stopColor="#1e293b" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" fill={`url(#bg_${commander.id})`} />

      {/* Shoulders / Uniform */}
      <path d="M10 64 C10 49, 20 45, 32 45 C44 45, 54 49, 54 64 Z" fill={s.uniform} />
      {/* Collar & Tie */}
      <polygon points="27,45 32,56 37,45" fill="#e2e8f0" opacity="0.9" />
      <polygon points="30.5,47 32,58 33.5,47" fill="#0f172a" />
      {/* Epaulettes */}
      <rect x="13" y="48" width="9" height="3.5" rx="1" fill="#eab308" opacity="0.85" />
      <rect x="42" y="48" width="9" height="3.5" rx="1" fill="#eab308" opacity="0.85" />

      {/* Neck & Head */}
      <rect x="27" y="38" width="10" height="9" rx="3" fill={s.skin} />
      <ellipse cx="32" cy="29" rx="12" ry="14" fill={s.skin} />

      {/* Hair */}
      {s.hat === 'none' && (
        <path d="M20 26 C20 15, 44 15, 44 26 C40 20, 24 20, 20 26 Z" fill={s.hair} />
      )}

      {/* Hat styles */}
      {s.hat === 'peak' && (
        <>
          <path d="M17 20 L47 20 L44 11 L20 11 Z" fill={s.uniform} stroke="#111827" strokeWidth="1" />
          <rect x="19" y="18.5" width="26" height="3" fill="#111827" />
          <circle cx="32" cy="14.5" r="2.2" fill="#eab308" />
          <path d="M19 21 Q32 24 45 21" stroke="#0f172a" strokeWidth="2.5" fill="none" />
        </>
      )}
      {s.hat === 'beret' && (
        <path d="M18 22 C18 12, 46 10, 46 20 C38 22, 24 22, 18 22 Z" fill="#1e293b" />
      )}
      {s.hat === 'fez' && (
        <>
          <path d="M22 20 L42 20 L39 9 L25 9 Z" fill="#991b1b" />
          <line x1="39" y1="11" x2="43" y2="18" stroke="#111827" strokeWidth="1.5" />
        </>
      )}

      {/* Eyes & Brows */}
      <circle cx="27" cy="28" r="1.4" fill="#1e293b" />
      <circle cx="37" cy="28" r="1.4" fill="#1e293b" />
      <line x1="24" y1="25" x2="29.5" y2="25.5" stroke={s.hair} strokeWidth="1.4" strokeLinecap="round" />
      <line x1="34.5" y1="25.5" x2="40" y2="25" stroke={s.hair} strokeWidth="1.4" strokeLinecap="round" />

      {/* Glasses */}
      {s.glasses && (
        <g stroke="#cbd5e1" strokeWidth="1.2" fill="none">
          <circle cx="27" cy="28" r="3.6" />
          <circle cx="37" cy="28" r="3.6" />
          <line x1="30.6" y1="28" x2="33.4" y2="28" />
        </g>
      )}

      {/* Nose & Mustache */}
      <path d="M32 28 L31 33 L33 33.5" stroke="#000000" strokeOpacity="0.22" fill="none" />
      {s.mustache === 'handlebar' && (
        <path d="M25 35 Q29 33 32 34.5 Q35 33 39 35 Q36 37 32 35.5 Q28 37 25 35 Z" fill={s.hair} />
      )}
      {s.mustache === 'trimmed' && (
        <rect x="28" y="34" width="8" height="2" rx="1" fill={s.hair} />
      )}
      <path d="M28.5 37.5 Q32 38.5 35.5 37.5" stroke="#7c2d12" strokeOpacity="0.45" strokeWidth="1.3" fill="none" />
    </svg>
  );
};
