import React from 'react';

export const IconCoins: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 32 32" className={className}>
    <ellipse cx="13" cy="21" rx="8" ry="5" fill="#d97706" stroke="#0f172a" strokeWidth="2" />
    <ellipse cx="13" cy="17" rx="8" ry="5" fill="#f59e0b" stroke="#0f172a" strokeWidth="2" />
    <ellipse cx="19" cy="14" rx="8" ry="5" fill="#fbbf24" stroke="#0f172a" strokeWidth="2" />
    <ellipse cx="19" cy="11" rx="8" ry="4.5" fill="#fde047" stroke="#0f172a" strokeWidth="2" />
  </svg>
);

export const IconFactoryBadge: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 32 32" className={className}>
    <path d="M5 27V15l7 4v-4l7 4v-4l8 4v8H5z" fill="#ea580c" stroke="#0f172a" strokeWidth="2" strokeLinejoin="round" />
    <rect x="7" y="6" width="4" height="9" fill="#cbd5e1" stroke="#0f172a" strokeWidth="1.8" />
    <rect x="14" y="6" width="4" height="9" fill="#94a3b8" stroke="#0f172a" strokeWidth="1.8" />
    <circle cx="9" cy="4" r="2" fill="#e2e8f0" opacity="0.8" />
    <circle cx="16" cy="3.5" r="2.2" fill="#e2e8f0" opacity="0.8" />
  </svg>
);

export const IconManpowerBadge: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 32 32" className={className}>
    <circle cx="11" cy="10" r="4" fill="#93c5fd" stroke="#0f172a" strokeWidth="2" />
    <path d="M4 25c0-4 3-7 7-7s7 3 7 7" fill="#3b82f6" stroke="#0f172a" strokeWidth="2" strokeLinejoin="round" />
    <circle cx="21" cy="11" r="3.6" fill="#fde68a" stroke="#0f172a" strokeWidth="2" />
    <path d="M15 25c0-3.6 2.6-6.2 6-6.2s6 2.6 6 6.2" fill="#f59e0b" stroke="#0f172a" strokeWidth="2" strokeLinejoin="round" />
  </svg>
);

export const IconDiplomacyTemple: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 32 32" className={className}>
    <polygon points="16,4 4,11 28,11" fill="#e2e8f0" stroke="#0f172a" strokeWidth="2" strokeLinejoin="round" />
    <rect x="7" y="11" width="3.5" height="12" fill="#cbd5e1" stroke="#0f172a" strokeWidth="1.6" />
    <rect x="14.2" y="11" width="3.5" height="12" fill="#cbd5e1" stroke="#0f172a" strokeWidth="1.6" />
    <rect x="21.5" y="11" width="3.5" height="12" fill="#cbd5e1" stroke="#0f172a" strokeWidth="1.6" />
    <rect x="4" y="23" width="24" height="4" rx="1" fill="#94a3b8" stroke="#0f172a" strokeWidth="2" />
  </svg>
);

export const IconUraniumAtom: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 32 32" className={className}>
    <circle cx="16" cy="16" r="12" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
    <ellipse cx="16" cy="16" rx="9" ry="3.8" transform="rotate(35 16 16)" fill="none" stroke="#84cc16" strokeWidth="2" />
    <ellipse cx="16" cy="16" rx="9" ry="3.8" transform="rotate(-35 16 16)" fill="none" stroke="#a3e635" strokeWidth="2" />
    <circle cx="16" cy="16" r="3" fill="#bef264" stroke="#0f172a" strokeWidth="1.5" />
  </svg>
);

export const IconCrown: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg viewBox="0 0 32 32" className={className}>
    <path d="M5 23L4 10l7 5 5-8 5 8 7-5-1 13H5z" fill="#fbbf24" stroke="#0f172a" strokeWidth="2.2" strokeLinejoin="round" />
    <rect x="5" y="23" width="22" height="4" rx="1" fill="#d97706" stroke="#0f172a" strokeWidth="2" />
  </svg>
);

export const IconHandshake: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" className={className}>
    <path d="M4 17l7-7 7 5-5 7-9-5z" fill="#fb7185" stroke="#0f172a" strokeWidth="2" strokeLinejoin="round" />
    <path d="M32 17l-7-7-7 5 5 7 9-5z" fill="#60a5fa" stroke="#0f172a" strokeWidth="2" strokeLinejoin="round" />
    <path d="M11 16l6 7c1.5 1.5 4 1.5 5.5 0L26 19l-6-5-9 2z" fill="#fde68a" stroke="#0f172a" strokeWidth="2" strokeLinejoin="round" />
    <path d="M15 21l2.5 2.5M18 19l2.5 2.5" stroke="#0f172a" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const IconResearchFlask: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" className={className}>
    <path d="M14 6h8v7l7 14c.8 1.5-.3 3-2 3H9c-1.7 0-2.8-1.5-2-3l7-14V6z" fill="#e0f2fe" stroke="#0f172a" strokeWidth="2.2" strokeLinejoin="round" />
    <path d="M10.5 21h15l2.5 5.2c.4.8-.2 1.8-1.1 1.8H9.1c-.9 0-1.5-1-1.1-1.8L10.5 21z" fill="#0ea5e9" stroke="#0f172a" strokeWidth="1.6" />
    <rect x="12" y="4" width="12" height="3.5" rx="1.5" fill="#94a3b8" stroke="#0f172a" strokeWidth="1.8" />
    <circle cx="15" cy="24" r="1.4" fill="#bae6fd" />
    <circle cx="20" cy="25.5" r="1.1" fill="#bae6fd" />
  </svg>
);

export const IconGear: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" className={className}>
    <path
      d="M15.5 4h5l1 3.7a10.5 10.5 0 0 1 2.7 1.1l3.3-1.9 3.5 3.5-1.9 3.3c.5.9.8 1.8 1.1 2.7l3.7 1v5l-3.7 1a10.5 10.5 0 0 1-1.1 2.7l1.9 3.3-3.5 3.5-3.3-1.9a10.5 10.5 0 0 1-2.7 1.1l-1 3.7h-5l-1-3.7a10.5 10.5 0 0 1-2.7-1.1l-3.3 1.9-3.5-3.5 1.9-3.3a10.5 10.5 0 0 1-1.1-2.7l-3.7-1v-5l3.7-1a10.5 10.5 0 0 1 1.1-2.7l-1.9-3.3 3.5-3.5 3.3 1.9a10.5 10.5 0 0 1 2.7-1.1L15.5 4z"
      fill="#fbbf24"
      stroke="#0f172a"
      strokeWidth="2.2"
      strokeLinejoin="round"
    />
    <circle cx="18" cy="18" r="5" fill="#334155" stroke="#0f172a" strokeWidth="2.2" />
  </svg>
);

export const IconArmyHelmet: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" className={className}>
    <path d="M6 21c0-7.5 5.4-13 12-13s12 5.5 12 13l2 2.5H4L6 21z" fill="#65a30d" stroke="#0f172a" strokeWidth="2.2" strokeLinejoin="round" />
    <path d="M10 17c2-4 5-6 8-6" stroke="#bef264" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.7" />
    <path d="M11 23.5l4 6h6l4-6" fill="none" stroke="#d97706" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const IconNavyAnchor: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" className={className}>
    <circle cx="18" cy="8" r="3.5" fill="none" stroke="#0f172a" strokeWidth="4" />
    <circle cx="18" cy="8" r="3.5" fill="none" stroke="#38bdf8" strokeWidth="2.2" />
    <path d="M18 11.5v17M12 15h12M8 22c0 5.5 4.5 9 10 9s10-3.5 10-9" fill="none" stroke="#0f172a" strokeWidth="5.2" strokeLinecap="round" />
    <path d="M18 11.5v17M12 15h12M8 22c0 5.5 4.5 9 10 9s10-3.5 10-9" fill="none" stroke="#38bdf8" strokeWidth="2.8" strokeLinecap="round" />
  </svg>
);

export const IconAirWing: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" className={className}>
    <path
      d="M7 10c8 0 18 2 23 6-4 1.5-8 2-12 2 5 1.5 8 3 10 4.5-4.5 1-8.5 1-12.5.8 3.5 1.4 6 2.8 7.5 4.2-6 .2-11-1.2-15-4.5-2.5-2-3-5.5-1-13z"
      fill="#f8fafc"
      stroke="#0f172a"
      strokeWidth="2.2"
      strokeLinejoin="round"
    />
  </svg>
);

export const IconBattlesTarget: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" className={className}>
    <circle cx="18" cy="18" r="12" fill="#ef4444" stroke="#0f172a" strokeWidth="2.2" />
    <circle cx="18" cy="18" r="7.5" fill="#f8fafc" stroke="#0f172a" strokeWidth="1.6" />
    <circle cx="18" cy="18" r="3.5" fill="#ef4444" stroke="#0f172a" strokeWidth="1.6" />
  </svg>
);
