import React from 'react';
import { Plus, Swords, Navigation } from 'lucide-react';
import type { GameState, MapDataStatic } from '../../shared/types.ts';
import { getArmyTotal } from '../../shared/utils/gameHelpers.ts';
import { IconArmyHelmet } from './GameIcons.tsx';

interface ArmyHotbarProps {
  state: GameState;
  mapData: MapDataStatic;
  playerCountryId: string;
  selectedArmyId: string | null;
  onSelectArmy: (armyId: string, provinceId: string) => void;
  onOpenArmyPanel: () => void;
}

const CARD_TINTS = [
  'from-amber-500/80 to-yellow-600/85',
  'from-rose-500/80 to-red-600/85',
  'from-emerald-500/80 to-green-600/85',
  'from-sky-500/80 to-blue-600/85',
  'from-indigo-500/80 to-violet-600/85',
];

export const ArmyHotbar: React.FC<ArmyHotbarProps> = ({
  state,
  mapData,
  playerCountryId,
  selectedArmyId,
  onSelectArmy,
  onOpenArmyPanel,
}) => {
  const myArmies = Object.values(state.armies)
    .filter((a) => a.countryId === playerCountryId && getArmyTotal(a.units) > 0)
    .sort((a, b) => getArmyTotal(b.units) - getArmyTotal(a.units))
    .slice(0, 6);

  return (
    <div className="fixed bottom-3 left-1/2 -translate-x-1/2 z-20 flex items-end gap-2 pointer-events-auto">
      {myArmies.map((army, idx) => {
        const total = getArmyTotal(army.units);
        const selected = selectedArmyId === army.id;
        const provName = mapData.provinces.find((p) => p.id === army.provinceId)?.name || army.provinceId;
        const tint = CARD_TINTS[idx % CARD_TINTS.length];

        return (
          <button
            key={army.id}
            onClick={() => onSelectArmy(army.id, army.provinceId)}
            title={`${army.name} (${total}K) · ${provName} — Seç ve hedef toprağa tıkla`}
            className={`group relative w-16 h-20 rounded-2xl border-2 transition-all duration-150 flex flex-col items-center justify-between p-1.5 shadow-xl overflow-hidden hover:-translate-y-1 active:scale-95 ${
              selected
                ? 'border-amber-300 ring-2 ring-amber-400/60 -translate-y-1.5 bg-slate-800'
                : 'border-slate-950 bg-slate-900/90 hover:border-sky-400'
            }`}
          >
            <div className={`w-full flex-1 rounded-xl bg-gradient-to-b ${tint} flex items-center justify-center relative`}>
              <IconArmyHelmet className="w-8 h-8 drop-shadow" />
              {army.inBattleId && (
                <span className="absolute top-0.5 right-0.5 bg-rose-600 rounded-full p-0.5 border border-slate-950">
                  <Swords className="w-2.5 h-2.5 text-white" />
                </span>
              )}
              {!army.inBattleId && army.path.length > 0 && (
                <span className="absolute top-0.5 right-0.5 bg-sky-500 rounded-full p-0.5 border border-slate-950">
                  <Navigation className="w-2.5 h-2.5 text-slate-950" />
                </span>
              )}
            </div>
            <div className="w-full pt-1 flex items-center justify-between gap-1 text-[10px] leading-none">
              <span className="font-mono-num font-extrabold text-white hud-text-shadow">{total}K</span>
              <span className="text-slate-300 truncate max-w-[32px]">{provName}</span>
            </div>
          </button>
        );
      })}

      {/* Quick Recruit / Add Army Card */}
      <button
        onClick={onOpenArmyPanel}
        title="Yeni Ordu / Asker Yetiştir"
        className="w-16 h-20 rounded-2xl hud-tile hover:brightness-110 hover:-translate-y-1 active:scale-95 transition-all flex flex-col items-center justify-center gap-1"
      >
        <div className="w-9 h-9 rounded-full bg-slate-800 border-2 border-slate-950 flex items-center justify-center text-slate-200">
          <Plus className="w-5 h-5" />
        </div>
        <span className="text-[10px] font-bold text-slate-200">Ordu Ekle</span>
      </button>
    </div>
  );
};
