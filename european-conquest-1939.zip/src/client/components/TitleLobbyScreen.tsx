import React, { useEffect, useState } from 'react';
import {
  Play,
  Users,
  Search,
  Copy,
  Check,
  FolderOpen,
  Trash2,
  Shield,
  ArrowLeft,
} from 'lucide-react';
import type {
  DifficultyLevel,
  RegionGroup,
  RoomLobbyState,
} from '../../shared/types.ts';
import { COUNTRIES, COUNTRY_LIST } from '../../shared/data/countries.ts';
import { SCENARIOS } from '../../shared/data/scenarios.ts';
import { CountryFlag } from './CountryFlag.tsx';
import { deleteSaveApi, listSavesApi, type SaveMetaItem } from '../network/GameClient.ts';

interface TitleLobbyScreenProps {
  lobby: RoomLobbyState | null;
  playerId: string;
  playerName: string;
  onChangePlayerName: (name: string) => void;
  selectedLobbyCountryId: string;
  onSelectLobbyCountryId: (cid: string) => void;
  lobbyScenarioId: '1939_alt' | '1939_hist';
  onChangeScenarioId: (sid: '1939_alt' | '1939_hist') => void;
  onStartSingleplayer: (opts: {
    countryId: string;
    scenarioId: '1939_alt' | '1939_hist';
    difficulty: DifficultyLevel;
    victoryThreshold: 75 | 80;
  }) => void;
  onCreateMultiplayerRoom: (opts: {
    scenarioId: '1939_alt' | '1939_hist';
    difficulty: DifficultyLevel;
    victoryThreshold: 75 | 80;
    maxHumanPlayers: number;
  }) => void;
  onJoinMultiplayerRoom: (code: string) => void;
  onLoadSavedGame: (slotId: string) => void;
  onLobbySelectCountry: (countryId: string) => void;
  onLobbyToggleReady: () => void;
  onLobbyStartGame: () => void;
  onLeaveLobby: () => void;
  errorMessage: string | null;
}

const REGIONS: ('Tümü' | RegionGroup)[] = [
  'Tümü',
  'Avrupa',
  'Türkiye ve Kafkasya',
  'Orta Doğu',
  'Arap Yarımadası',
  'Kuzey Afrika',
];

export const TitleLobbyScreen: React.FC<TitleLobbyScreenProps> = ({
  lobby,
  playerId,
  playerName,
  onChangePlayerName,
  selectedLobbyCountryId,
  onSelectLobbyCountryId,
  lobbyScenarioId,
  onChangeScenarioId,
  onStartSingleplayer,
  onCreateMultiplayerRoom,
  onJoinMultiplayerRoom,
  onLoadSavedGame,
  onLobbySelectCountry,
  onLobbyToggleReady,
  onLobbyStartGame,
  onLeaveLobby,
  errorMessage,
}) => {
  const [tab, setTab] = useState<'single' | 'multi' | 'saves'>('single');
  const [search, setSearch] = useState('');
  const [regionFilter, setRegionFilter] = useState<'Tümü' | RegionGroup>('Tümü');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('normal');
  const [victoryThreshold, setVictoryThreshold] = useState<75 | 80>(75);
  const [maxHumanPlayers, setMaxHumanPlayers] = useState<number>(5);
  const [joinCode, setJoinCode] = useState('');
  const [saves, setSaves] = useState<SaveMetaItem[]>([]);
  const [copiedCode, setCopiedCode] = useState(false);

  useEffect(() => {
    if (tab === 'saves') {
      listSavesApi().then(setSaves);
    }
  }, [tab]);

  // Pre-fill room code from URL query if invited
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('room');
    if (code) {
      setTab('multi');
      setJoinCode(code.toUpperCase());
    }
  }, []);

  const filteredCountries = COUNTRY_LIST.filter((c) => {
    const matchRegion = regionFilter === 'Tümü' || c.region === regionFilter;
    const matchSearch =
      !search.trim() ||
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.leader.toLowerCase().includes(search.toLowerCase());
    return matchRegion && matchSearch;
  });

  const activeCountry = COUNTRIES[selectedLobbyCountryId] || COUNTRIES.TUR;
  const meInLobby = lobby?.players.find((p) => p.playerId === playerId);

  const handleCopyInvite = () => {
    if (!lobby) return;
    const url = `${window.location.origin}?room=${lobby.roomCode}`;
    navigator.clipboard?.writeText(url);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-between p-6 lg:p-10 pointer-events-none">
      {/* Subtle contrast scrim on left while leaving 40%+ live map visible on right */}
      <div className="absolute inset-0 bg-gradient-to-r from-slate-950/92 via-slate-950/65 to-slate-950/25 pointer-events-none" />

      <div className="relative z-10 w-full max-w-[780px] max-h-[90vh] flex flex-col bg-slate-900/92 backdrop-blur-lg border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden pointer-events-auto">
        {/* Title Lockup Header */}
        <div className="px-6 py-5 border-b border-slate-700/70 flex items-center justify-between gap-4 bg-slate-950/50">
          <div className="flex items-center gap-3.5">
            <svg viewBox="0 0 44 44" className="w-11 h-11 shrink-0" aria-hidden="true">
              <circle cx="22" cy="22" r="20" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.8" />
              <path d="M22 6L26.5 16.5L38 18L29.5 25.5L31.5 37L22 31.5L12.5 37L14.5 25.5L6 18L17.5 16.5Z" fill="#facc15" fillOpacity="0.9" />
            </svg>
            <div>
              <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-wide text-white leading-none">
                EUROPEAN CONQUEST 1939
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Avrupa, Türkiye, Kafkasya, Orta Doğu ve Kuzey Afrika Büyük Strateji
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={playerName}
              onChange={(e) => onChangePlayerName(e.target.value)}
              placeholder="Komutan Adı"
              maxLength={20}
              className="w-36 px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-sky-500"
            />
          </div>
        </div>

        {errorMessage && (
          <div className="mx-6 mt-3 px-4 py-2 rounded-lg bg-rose-950/80 border border-rose-600/60 text-xs text-rose-200">
            {errorMessage}
          </div>
        )}

        {/* Active Multiplayer Lobby View */}
        {lobby ? (
          <div className="p-6 flex flex-col gap-4 overflow-y-auto">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <button
                  onClick={onLeaveLobby}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Ayrıl
                </button>
                <div>
                  <div className="text-xs text-slate-400">Çok Oyunculu Oda Kodu</div>
                  <div className="font-mono-num text-xl font-bold text-amber-400 tracking-widest">
                    {lobby.roomCode}
                  </div>
                </div>
              </div>

              <button
                onClick={handleCopyInvite}
                className="px-3.5 py-2 rounded-lg bg-sky-600/20 border border-sky-500/50 text-sky-200 hover:bg-sky-600/30 text-xs font-medium flex items-center gap-1.5"
              >
                {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                {copiedCode ? 'Davet Bağlantısı Kopyalandı' : 'Arkadaş Davet Bağlantısı Kopyala'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Players List */}
              <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-4 flex flex-col gap-2.5">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-sky-400" />
                    Oyuncular ({lobby.players.length}/{lobby.maxHumanPlayers})
                  </span>
                  <span>Zafer: %{lobby.victoryThreshold}</span>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {lobby.players.map((p) => (
                    <div
                      key={p.playerId}
                      className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-900 border border-slate-800"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {p.countryId ? (
                          <CountryFlag countryId={p.countryId} className="w-7 h-4" />
                        ) : (
                          <div className="w-7 h-4 rounded-sm bg-slate-800 border border-slate-700" />
                        )}
                        <div className="truncate">
                          <div className="text-xs font-semibold text-slate-100 truncate">
                            {p.name} {p.isHost && '· Kurucu'}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {p.countryId ? COUNTRIES[p.countryId]?.name : 'Ülke seçilmedi'}
                          </div>
                        </div>
                      </div>
                      <span
                        className={`text-[11px] font-medium ${
                          p.ready ? 'text-emerald-400' : 'text-amber-400'
                        }`}
                      >
                        {p.ready ? 'Hazır' : 'Bekliyor'}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    onClick={onLobbyToggleReady}
                    className={`flex-1 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
                      meInLobby?.ready
                        ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                        : 'bg-slate-800 border border-slate-600 text-slate-200 hover:bg-slate-700'
                    }`}
                  >
                    {meInLobby?.ready ? 'Hazırım ✓' : 'Hazır Ol'}
                  </button>

                  {meInLobby?.isHost && (
                    <button
                      onClick={onLobbyStartGame}
                      className="flex-1 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                    >
                      <Play className="w-4 h-4" />
                      Oyunu Başlat
                    </button>
                  )}
                </div>
              </div>

              {/* Country Pick for MP */}
              <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-4 flex flex-col gap-2.5">
                <div className="text-xs font-semibold text-slate-200">Ülkenizi Seçin (Diğerlerini AI yönetir)</div>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Ülke ara..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div className="grid grid-cols-1 gap-1.5 max-h-56 overflow-y-auto pr-1">
                  {filteredCountries.map((c) => {
                    const takenBy = lobby.players.find(
                      (p) => p.countryId === c.id && p.playerId !== playerId
                    );
                    const isMine = meInLobby?.countryId === c.id;
                    return (
                      <button
                        key={c.id}
                        disabled={Boolean(takenBy)}
                        onClick={() => onLobbySelectCountry(c.id)}
                        className={`flex items-center justify-between px-2.5 py-2 rounded-lg border text-left text-xs transition-colors ${
                          isMine
                            ? 'bg-sky-600/25 border-sky-400 text-white'
                            : takenBy
                            ? 'bg-slate-900/40 border-slate-800 text-slate-500 cursor-not-allowed'
                            : 'bg-slate-900 border-slate-800 text-slate-200 hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <CountryFlag countryId={c.id} className="w-6 h-4" />
                          <span className="font-medium">{c.name}</span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {takenBy ? takenBy.name : c.region}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Mode Tabs: Singleplayer / Multiplayer / Saved Games */
          <div className="flex flex-col flex-1 min-h-0">
            <div className="px-6 pt-4 flex items-center gap-2 border-b border-slate-800 pb-3">
              <button
                onClick={() => setTab('single')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  tab === 'single'
                    ? 'bg-sky-600 text-white'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                }`}
              >
                Tek Oyunculu
              </button>
              <button
                onClick={() => setTab('multi')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  tab === 'multi'
                    ? 'bg-sky-600 text-white'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                }`}
              >
                Çok Oyunculu (Multiplayer)
              </button>
              <button
                onClick={() => setTab('saves')}
                className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  tab === 'saves'
                    ? 'bg-sky-600 text-white'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <FolderOpen className="w-3.5 h-3.5" />
                Kayıtlı Oyunlar
              </button>
            </div>

            {tab === 'single' && (
              <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-5 overflow-y-auto">
                {/* Left: Searchable Country Picker */}
                <div className="md:col-span-7 flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder="Ülke veya lider ara (ör. Türkiye, Almanya)..."
                        className="w-full pl-8 pr-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {REGIONS.map((reg) => (
                      <button
                        key={reg}
                        onClick={() => setRegionFilter(reg)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                          regionFilter === reg
                            ? 'bg-sky-600/30 border border-sky-400/70 text-sky-200'
                            : 'bg-slate-800/70 border border-slate-700/60 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {reg}
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-1.5 max-h-64 overflow-y-auto pr-1">
                    {filteredCountries.map((c) => {
                      const active = c.id === selectedLobbyCountryId;
                      return (
                        <button
                          key={c.id}
                          onClick={() => onSelectLobbyCountryId(c.id)}
                          className={`flex items-center gap-2.5 px-3 py-2 rounded-lg border text-left transition-colors ${
                            active
                              ? 'bg-sky-600/25 border-sky-400 text-white'
                              : 'bg-slate-950/60 border-slate-800 text-slate-200 hover:border-slate-600'
                          }`}
                        >
                          <CountryFlag countryId={c.id} className="w-7 h-4.5" />
                          <div className="min-w-0">
                            <div className="text-xs font-semibold truncate">{c.name}</div>
                            <div className="text-[10px] text-slate-400 truncate">{c.leader}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Right: Selected Country Brief & Settings */}
                <div className="md:col-span-5 flex flex-col justify-between gap-4 bg-slate-950/60 border border-slate-800 rounded-xl p-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                      <CountryFlag countryId={activeCountry.id} className="w-12 h-8" />
                      <div>
                        <div className="font-display text-xl font-bold text-white leading-tight">
                          {activeCountry.name}
                        </div>
                        <div className="text-xs text-slate-400">
                          {activeCountry.leader} · {activeCountry.region}
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-400 mb-1">
                        Senaryo (1 Eylül 1939)
                      </label>
                      <select
                        value={lobbyScenarioId}
                        onChange={(e) => onChangeScenarioId(e.target.value as '1939_alt' | '1939_hist')}
                        className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                      >
                        <option value="1939_alt">{SCENARIOS['1939_alt'].name}</option>
                        <option value="1939_hist">{SCENARIOS['1939_hist'].name}</option>
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-medium text-slate-400 mb-1">
                          Zorluk
                        </label>
                        <select
                          value={difficulty}
                          onChange={(e) => setDifficulty(e.target.value as DifficultyLevel)}
                          className="w-full px-2.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                        >
                          <option value="easy">Kolay</option>
                          <option value="normal">Normal</option>
                          <option value="hard">Zor</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[11px] font-medium text-slate-400 mb-1">
                          Zafer Sınırı
                        </label>
                        <select
                          value={victoryThreshold}
                          onChange={(e) => setVictoryThreshold(Number(e.target.value) as 75 | 80)}
                          className="w-full px-2.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                        >
                          <option value={75}>%75 Kara</option>
                          <option value={80}>%80 Kara</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      onStartSingleplayer({
                        countryId: activeCountry.id,
                        scenarioId: lobbyScenarioId,
                        difficulty,
                        victoryThreshold,
                      })
                    }
                    className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg transition-colors"
                  >
                    <Play className="w-4 h-4" />
                    Seferberliği Başlat
                  </button>
                </div>
              </div>
            )}

            {tab === 'multi' && (
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between gap-4">
                  <div className="space-y-3">
                    <h2 className="font-display text-xl font-bold text-white flex items-center gap-2">
                      <Shield className="w-5 h-5 text-sky-400" />
                      Yeni Çok Oyunculu Oda Kur
                    </h2>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Arkadaşlarınızla aynı haritada gerçek zamanlı oynayın. Seçilmeyen ülkeleri yapay zekâ yönetir.
                    </p>

                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Oyuncu Kapasitesi</label>
                        <select
                          value={maxHumanPlayers}
                          onChange={(e) => setMaxHumanPlayers(Number(e.target.value))}
                          className="w-full px-2.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                        >
                          <option value={5}>5 Oyuncu (Varsayılan)</option>
                          <option value={2}>2 Oyuncu</option>
                          <option value={8}>8 Oyuncu</option>
                          <option value={12}>12 Oyuncu</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Zafer Sınırı</label>
                        <select
                          value={victoryThreshold}
                          onChange={(e) => setVictoryThreshold(Number(e.target.value) as 75 | 80)}
                          className="w-full px-2.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                        >
                          <option value={75}>%75 Kontrol</option>
                          <option value={80}>%80 Kontrol</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Senaryo & Zorluk</label>
                      <div className="grid grid-cols-2 gap-2">
                        <select
                          value={lobbyScenarioId}
                          onChange={(e) => onChangeScenarioId(e.target.value as '1939_alt' | '1939_hist')}
                          className="px-2.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                        >
                          <option value="1939_alt">1939 Alternatif</option>
                          <option value="1939_hist">1939 Tarihsel</option>
                        </select>
                        <select
                          value={difficulty}
                          onChange={(e) => setDifficulty(e.target.value as DifficultyLevel)}
                          className="px-2.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-100"
                        >
                          <option value="easy">Kolay AI</option>
                          <option value="normal">Normal AI</option>
                          <option value="hard">Zor AI</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      onCreateMultiplayerRoom({
                        scenarioId: lobbyScenarioId,
                        difficulty,
                        victoryThreshold,
                        maxHumanPlayers,
                      })
                    }
                    className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm transition-colors"
                  >
                    Oda Oluştur ve Kod Al
                  </button>
                </div>

                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between gap-4">
                  <div className="space-y-3">
                    <h2 className="font-display text-xl font-bold text-white flex items-center gap-2">
                      <Users className="w-5 h-5 text-emerald-400" />
                      Oda Koduyla Katıl
                    </h2>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Arkadaşınızın paylaştığı 6 haneli oda kodunu girerek lobiye bağlanın.
                    </p>
                    <input
                      type="text"
                      value={joinCode}
                      onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                      placeholder="ÖRN: A7K9M2"
                      maxLength={8}
                      className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 font-mono-num text-lg tracking-widest text-center text-amber-300 uppercase focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <button
                    disabled={!joinCode.trim()}
                    onClick={() => onJoinMultiplayerRoom(joinCode)}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-semibold text-sm transition-colors"
                  >
                    Odaya Bağlan
                  </button>
                </div>
              </div>
            )}

            {tab === 'saves' && (
              <div className="p-6 max-h-80 overflow-y-auto space-y-2">
                {saves.length === 0 ? (
                  <div className="text-center py-10 text-xs text-slate-400">
                    Henüz kaydedilmiş bir oyun bulunmuyor. Oyun içindeki “Kaydet” butonundan kayıt oluşturabilirsiniz.
                  </div>
                ) : (
                  saves.map((s) => (
                    <div
                      key={s.slotId}
                      className="flex items-center justify-between px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-800"
                    >
                      <div className="flex items-center gap-3">
                        {s.humanCountryIds[0] && (
                          <CountryFlag countryId={s.humanCountryIds[0]} className="w-8 h-5" />
                        )}
                        <div>
                          <div className="text-sm font-semibold text-slate-100">{s.slotName}</div>
                          <div className="text-[11px] text-slate-400">
                            Gün {s.day} · {s.mode === 'multiplayer' ? 'Çok Oyunculu' : 'Tek Oyunculu'} ·{' '}
                            {new Date(s.savedAt).toLocaleString('tr-TR')}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onLoadSavedGame(s.slotId)}
                          className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold"
                        >
                          Yükle
                        </button>
                        <button
                          onClick={async () => {
                            await deleteSaveApi(s.slotId);
                            setSaves((prev) => prev.filter((x) => x.slotId !== s.slotId));
                          }}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900 text-slate-400 hover:text-rose-200"
                          title="Kaydı Sil"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        )}

        {/* Single flat control-hint line at bottom of launcher */}
        <div className="px-6 py-2.5 bg-slate-950/70 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
          <span>Haritayı Sürükle: Gez · Tekerlek: Yakınlaştır · Tıkla: Bölge veya Ordu Seç</span>
          <span>1 Saniye = 1 Oyun Günü (1x)</span>
        </div>
      </div>
    </div>
  );
};
