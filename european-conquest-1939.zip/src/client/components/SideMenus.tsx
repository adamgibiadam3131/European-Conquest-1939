import React from 'react';
import {
  Trophy,
  Globe,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  LogOut,
  HelpCircle,
} from 'lucide-react';
import type { MapMode } from '../../shared/types.ts';
import {
  IconHandshake,
  IconDiplomacyTemple,
  IconResearchFlask,
  IconGear,
  IconArmyHelmet,
  IconNavyAnchor,
  IconAirWing,
  IconBattlesTarget,
} from './GameIcons.tsx';

export type ActivePanelId =
  | 'army'
  | 'research'
  | 'government'
  | 'diplomacy'
  | 'production'
  | 'air'
  | 'navy'
  | 'battles'
  | 'leaderboard'
  | null;

interface SideMenusProps {
  activePanel: ActivePanelId;
  onSelectPanel: (panel: ActivePanelId) => void;
  mapMode: MapMode;
  onChangeMapMode: (mode: MapMode) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetCam: () => void;
  onOpenTutorial: () => void;
  onExitGame: () => void;
  activeBattleCount: number;
  hasAvailableResearch: boolean;
}

const RIGHT_STRATEGY_ITEMS: {
  id: Exclude<ActivePanelId, 'battles' | 'leaderboard' | null>;
  label: string;
  Icon: React.FC<{ className?: string }>;
}[] = [
  { id: 'diplomacy', label: 'Diplomasi', Icon: IconHandshake },
  { id: 'government', label: 'Hükümet', Icon: IconDiplomacyTemple },
  { id: 'research', label: 'Araştırma', Icon: IconResearchFlask },
  { id: 'production', label: 'Üretim', Icon: IconGear },
  { id: 'army', label: 'Ordu', Icon: IconArmyHelmet },
  { id: 'navy', label: 'Deniz Kuvvetleri', Icon: IconNavyAnchor },
  { id: 'air', label: 'Hava Kuvvetleri', Icon: IconAirWing },
];

export const SideMenus: React.FC<SideMenusProps> = ({
  activePanel,
  onSelectPanel,
  mapMode,
  onChangeMapMode,
  onZoomIn,
  onZoomOut,
  onResetCam,
  onOpenTutorial,
  onExitGame,
  activeBattleCount,
  hasAvailableResearch,
}) => {
  const nextMapMode = (): MapMode => {
    const order: MapMode[] = ['political', 'diplomacy', 'supply', 'terrain'];
    return order[(order.indexOf(mapMode) + 1) % order.length];
  };

  const mapModeLabels: Record<MapMode, string> = {
    political: 'Siyasi',
    diplomacy: 'Diplomasi',
    supply: 'İkmal',
    terrain: 'Arazi',
  };

  return (
    <>
      {/* Right Primary Strategy Rail (Exact Screenshot Order & Vibrant Vector Icons) */}
      <aside className="fixed right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2">
        {RIGHT_STRATEGY_ITEMS.map(({ id, label, Icon }) => {
          const active = activePanel === id;
          return (
            <button
              key={id}
              onClick={() => onSelectPanel(active ? null : id)}
              title={label}
              className={`group relative w-13 h-13 rounded-2xl flex items-center justify-center transition-all duration-150 hover:scale-105 active:scale-95 ${
                active ? 'hud-tile-active scale-105' : 'hud-tile hover:brightness-110'
              }`}
            >
              <Icon className="w-8 h-8 drop-shadow" />
              {id === 'research' && hasAvailableResearch && (
                <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-rose-500 border-2 border-slate-950 shadow" />
              )}
              <span className="pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity absolute right-16 px-3 py-1.5 rounded-lg hud-pill text-xs font-bold text-white whitespace-nowrap">
                {label}
              </span>
            </button>
          );
        })}
      </aside>

      {/* Left Utility, Battles & Map Mode Rail (Screenshot Left Dock) */}
      <aside className="fixed left-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2">
        <button
          onClick={() => onSelectPanel(activePanel === 'battles' ? null : 'battles')}
          title="Aktif Muharebeler ve Savaş Geçmişi"
          className={`group relative w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-150 hover:scale-105 active:scale-95 ${
            activePanel === 'battles' ? 'hud-tile-active' : 'hud-tile hover:brightness-110'
          }`}
        >
          <IconBattlesTarget className="w-7 h-7" />
          {activeBattleCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 min-w-[20px] h-[20px] px-1 rounded-full bg-rose-500 text-white font-mono-num text-[11px] font-extrabold flex items-center justify-center border-2 border-slate-950">
              {activeBattleCount}
            </span>
          )}
          <span className="pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity absolute left-15 px-3 py-1 rounded-lg hud-pill text-xs font-bold text-white whitespace-nowrap">
            Muharebeler ({activeBattleCount})
          </span>
        </button>

        <button
          onClick={() => onSelectPanel(activePanel === 'leaderboard' ? null : 'leaderboard')}
          title="Zafer İlerlemesi ve Sıralama"
          className={`group relative w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-150 hover:scale-105 active:scale-95 ${
            activePanel === 'leaderboard' ? 'hud-tile-active' : 'hud-tile hover:brightness-110'
          }`}
        >
          <Trophy className="w-6 h-6 text-amber-400" />
          <span className="pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity absolute left-15 px-3 py-1 rounded-lg hud-pill text-xs font-bold text-white whitespace-nowrap">
            Zafer Sıralaması
          </span>
        </button>

        <button
          onClick={() => onChangeMapMode(nextMapMode())}
          title={`Harita Modu: ${mapModeLabels[mapMode]} (Değiştirmek için tıkla)`}
          className="group relative w-12 h-12 rounded-2xl hud-tile flex flex-col items-center justify-center text-emerald-300 hover:brightness-110 hover:scale-105 active:scale-95 transition-all"
        >
          <Globe className="w-5 h-5" />
          <span className="text-[9px] font-bold text-slate-100 leading-none mt-0.5">{mapModeLabels[mapMode]}</span>
          <span className="pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity absolute left-15 px-3 py-1 rounded-lg hud-pill text-xs font-bold text-white whitespace-nowrap">
            Harita Modu: {mapModeLabels[mapMode]}
          </span>
        </button>

        <div className="flex flex-col hud-tile rounded-2xl overflow-hidden">
          <button
            onClick={onZoomIn}
            title="Yakınlaştır"
            className="w-12 h-9 flex items-center justify-center text-slate-200 hover:bg-slate-700/60 hover:text-white border-b border-slate-950"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={onZoomOut}
            title="Uzaklaştır"
            className="w-12 h-9 flex items-center justify-center text-slate-200 hover:bg-slate-700/60 hover:text-white border-b border-slate-950"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={onResetCam}
            title="Haritayı Ortala"
            className="w-12 h-9 flex items-center justify-center text-slate-200 hover:bg-slate-700/60 hover:text-white"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={onOpenTutorial}
          title="Öğretici / Yardım"
          className="w-12 h-11 rounded-2xl hud-tile text-amber-300 hover:brightness-110 active:scale-95 flex items-center justify-center transition-all"
        >
          <HelpCircle className="w-5 h-5" />
        </button>

        <button
          onClick={onExitGame}
          title="Ana Menüye Dön"
          className="w-12 h-11 rounded-2xl hud-tile text-rose-300 hover:bg-rose-900/70 active:scale-95 flex items-center justify-center transition-all"
        >
          <LogOut className="w-5 h-5" />
        </button>
      </aside>
    </>
  );
};
