import React from 'react';
import { Trophy, RotateCcw } from 'lucide-react';
import type { VictorySummary } from '../../shared/types.ts';
import { formatCompact, formatGameDate } from '../../shared/utils/gameHelpers.ts';
import { CountryFlag } from './CountryFlag.tsx';

interface VictoryModalProps {
  victory: VictorySummary;
  onReturnToMenu: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({ victory, onReturnToMenu }) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-[680px] bg-slate-900 border border-amber-500/60 rounded-2xl shadow-2xl overflow-hidden">
        <div className="px-6 py-5 bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/60 border-b border-amber-700/40 text-center">
          <Trophy className="w-12 h-12 text-amber-400 mx-auto mb-2" />
          <h2 className="font-display text-3xl font-bold text-white">
            {victory.winnerType === 'coalition' ? 'MÜTTEFİK KOALİSYON ZAFERİ' : 'MUTLAK ZAFER'}
          </h2>
          <p className="text-sm text-amber-200 mt-1">
            {victory.winnerNames.join(' & ')} — Kara Bölgelerinin %{victory.controlPercent}’ini Kontrol Etti!
          </p>
          <p className="text-xs text-slate-400 mt-1">
            Tarih: {formatGameDate(victory.day)} (Gün {victory.day}) · Hedef: %{victory.thresholdPercent}
          </p>
        </div>

        <div className="p-6 space-y-4">
          <div className="text-xs font-semibold text-slate-300">Savaş İstatistikleri ve Sıralama</div>
          <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
            {victory.rankings.map((r, i) => (
              <div
                key={r.countryId}
                className="px-3.5 py-2.5 rounded-xl bg-slate-950/75 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <span className="font-mono-num w-5 text-slate-400 font-bold">#{i + 1}</span>
                  <CountryFlag countryId={r.countryId} className="w-6 h-4" />
                  <span className="font-semibold text-white">
                    {r.name} {r.isHuman && <span className="text-sky-400">· Oyuncu</span>}
                  </span>
                </div>
                <div className="font-mono-num text-right text-slate-300">
                  <span className="text-amber-300 font-bold">%{r.controlPercent}</span> ·{' '}
                  <span className="text-emerald-400">+{r.provinces} Bölge</span> ·{' '}
                  <span className="text-rose-400">Kayıp: {formatCompact(r.casualtiesTaken * 1000)}</span>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={onReturnToMenu}
            className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Ana Menüye Dön ve Yeni Oyun Başlat
          </button>
        </div>
      </div>
    </div>
  );
};
