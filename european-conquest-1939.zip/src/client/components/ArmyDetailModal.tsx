import React, { useState } from 'react';
import { X, Navigation, GitFork, Combine, Star, Lock, Shield, Swords, MapPin } from 'lucide-react';
import type { ClientAction, GameState, LandUnitType, MapDataStatic } from '../../shared/types.ts';
import { COUNTRIES } from '../../shared/data/countries.ts';
import { LAND_UNITS } from '../../shared/data/units.ts';
import { getCommandersForCountry } from '../../shared/data/commanders.ts';
import { getArmyTotal } from '../../shared/utils/gameHelpers.ts';
import { CountryFlag } from './CountryFlag.tsx';
import { CommanderPortrait } from './CommanderPortrait.tsx';
import { LandUnitSvg } from './UnitIcons.tsx';

interface ArmyDetailModalProps {
  armyId: string;
  state: GameState;
  mapData: MapDataStatic;
  playerCountryId: string | null;
  isTargeting: boolean;
  onStartTargeting: (armyId: string) => void;
  onCancelTargeting: () => void;
  onAction: (action: ClientAction) => void;
  onClose: () => void;
}

const UNIT_ORDER: LandUnitType[] = [
  'infantry',
  'tank',
  'antitank',
  'artillery',
  'motorized',
  'antiair',
];

export const ArmyDetailModal: React.FC<ArmyDetailModalProps> = ({
  armyId,
  state,
  mapData,
  playerCountryId,
  isTargeting,
  onStartTargeting,
  onCancelTargeting,
  onAction,
  onClose,
}) => {
  const [tab, setTab] = useState<'info' | 'commanders'>('info');
  const army = state.armies[armyId];
  if (!army) return null;

  const isMine = army.countryId === playerCountryId;
  const provStatic = mapData.provinces.find((p) => p.id === army.provinceId);
  const provName = provStatic?.name || army.provinceId;
  const destName =
    army.path.length > 0
      ? mapData.provinces.find((p) => p.id === army.path[army.path.length - 1])?.name ||
        army.path[army.path.length - 1]
      : null;

  const total = getArmyTotal(army.units);
  const country = state.countries[army.countryId];
  const cmdPool = getCommandersForCountry(army.countryId, COUNTRIES[army.countryId]?.region);
  const currentCmd = army.commanderId ? cmdPool.find((c) => c.id === army.commanderId) : null;
  const currentCmdState = army.commanderId ? country?.commanders[army.commanderId] : null;

  const sameProvOwnArmies = Object.values(state.armies).filter(
    (a) => a.countryId === army.countryId && a.provinceId === army.provinceId && !a.inBattleId
  ).length;

  return (
    <div className="animate-panel-in fixed right-3 sm:right-18 top-16 z-35 w-[390px] sm:w-[430px] max-w-[calc(100vw-1.5rem)] max-h-[calc(100vh-11rem)] flex flex-col bg-[#1e2636]/95 backdrop-blur-md border-[3px] border-[#090d16] rounded-3xl shadow-2xl overflow-hidden text-slate-100">
      {/* Header Bar */}
      <div className="px-4 py-3 bg-[#151b26] border-b-2 border-[#090d16] flex items-center justify-between gap-2.5 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <CountryFlag countryId={army.countryId} className="w-8 h-5 shrink-0" />
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-display text-xl font-bold text-white hud-text-shadow leading-none truncate">
                {army.name}
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-sky-900/80 border border-sky-400/60 font-mono-num text-[11px] font-bold text-sky-200">
                {total}K Asker
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1 truncate">
              <span className="flex items-center gap-1 text-slate-300">
                <MapPin className="w-3 h-3 text-amber-400" />
                {provName}
              </span>
              {destName && <span className="text-sky-300 font-medium truncate">➜ {destName}</span>}
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-8 h-8 rounded-xl hud-tile hover:bg-rose-700/80 text-white flex items-center justify-center transition-colors shrink-0"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Mode Tabs for Own Armies */}
      {isMine && (
        <div className="px-4 py-2 bg-[#171e2b] border-b border-slate-800/80 grid grid-cols-2 gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setTab('info')}
            className={`py-1.5 rounded-xl text-xs font-bold border transition-all ${
              tab === 'info'
                ? 'bg-sky-600/90 border-sky-400 text-white shadow'
                : 'bg-slate-900/70 border-[#090d16] text-slate-300 hover:text-white'
            }`}
          >
            Ordu & Emirler
          </button>
          <button
            type="button"
            onClick={() => setTab('commanders')}
            className={`py-1.5 rounded-xl text-xs font-bold border flex items-center justify-center gap-1.5 transition-all ${
              tab === 'commanders'
                ? 'bg-amber-600/90 border-amber-400 text-white shadow'
                : 'bg-slate-900/70 border-[#090d16] text-slate-300 hover:text-white'
            }`}
          >
            <Star className="w-3.5 h-3.5" />
            Komutan Kadrosu
          </button>
        </div>
      )}

      {/* Body */}
      <div className="p-4 overflow-y-auto space-y-3.5">
        {(!isMine || tab === 'info') && (
          <>
            {isMine && !army.inBattleId && (
              <div className="px-3 py-2 rounded-xl bg-sky-950/60 border border-sky-500/40 text-[11px] text-sky-200 leading-snug">
                Haritada kendi şehirlerinize, müttefiklere veya savaş topraklarına doğrudan tıklayarak orduyu yürütebilirsiniz.
              </div>
            )}

            {/* Composition Cards */}
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                Birlik Kompozisyonu
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {UNIT_ORDER.map((ut) => {
                  const cnt = army.units[ut];
                  if (cnt === 0 && ut !== 'infantry') return null;
                  return (
                    <div
                      key={ut}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-950/75 border-2 border-[#090d16] flex items-center justify-between"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <LandUnitSvg type={ut} className="w-4 h-4 shrink-0" />
                        <span className="text-[11px] font-medium text-slate-200 truncate">
                          {LAND_UNITS[ut].name.replace(' (1K)', '')}
                        </span>
                      </div>
                      <span className="font-mono-num text-[11px] font-bold text-amber-300 ml-1">
                        {cnt}K
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Readiness Bars */}
            <div className="p-3 rounded-2xl bg-slate-950/70 border-2 border-[#090d16] space-y-2 text-[11px]">
              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-slate-300">Savaş Tecrübesi</span>
                  <span className="font-mono-num font-bold text-amber-300">
                    %{Math.round(army.experience)}
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-amber-400 rounded-full transition-all"
                    style={{ width: `${Math.min(100, army.experience)}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-slate-300">Moral ve Hazırlık</span>
                  <span className="font-mono-num font-bold text-emerald-400">
                    %{Math.round(army.morale)}
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      army.morale >= 60 ? 'bg-emerald-400' : 'bg-rose-400'
                    }`}
                    style={{ width: `${Math.min(100, army.morale)}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-slate-300">İkmal Durumu</span>
                  <span className="font-mono-num font-bold text-sky-300">
                    %{Math.round(army.supply)}
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-sky-400 rounded-full transition-all"
                    style={{ width: `${Math.min(100, army.supply)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Active Assigned Commander Banner */}
            <div className="p-2.5 rounded-2xl bg-slate-950/75 border-2 border-[#090d16]">
              <div className="flex items-center justify-between mb-1.5">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-amber-400" />
                  Görevli Komutan
                </div>
                {isMine && (
                  <button
                    type="button"
                    onClick={() => setTab('commanders')}
                    className="text-[11px] font-bold text-amber-300 hover:text-amber-200"
                  >
                    Değiştir →
                  </button>
                )}
              </div>
              {currentCmd ? (
                <div className="flex items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <CommanderPortrait commander={currentCmd} className="w-10 h-10 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">
                        {currentCmd.name}{' '}
                        <span className="text-[10px] font-mono-num text-amber-300">
                          Sv.{currentCmdState?.level || 1}
                        </span>
                      </div>
                      <div className="text-[10px] text-emerald-400">
                        +{Math.round(currentCmd.attackBonus * 100)}% Saldırı · +
                        {Math.round(currentCmd.defenseBonus * 100)}% Savunma
                      </div>
                    </div>
                  </div>
                  {isMine && (
                    <button
                      type="button"
                      onClick={() =>
                        onAction({
                          type: 'ASSIGN_COMMANDER',
                          commanderId: currentCmd.id,
                          armyId: null,
                        })
                      }
                      className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-rose-800/80 border border-slate-700 text-[10px] font-semibold text-slate-200 shrink-0"
                    >
                      Çıkar
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-[11px] text-slate-400">
                  {isMine
                    ? 'Komutan Kadrosu sekmesinden komutan atayabilirsiniz.'
                    : 'Tespit edilen komutan yok.'}
                </div>
              )}
            </div>

            {/* Tactical Orders */}
            {isMine && (
              <div className="space-y-2 pt-0.5">
                {army.inBattleId ? (
                  <div className="px-3 py-2 rounded-xl bg-rose-950/80 border-2 border-rose-500 text-center text-xs text-rose-200 font-bold">
                    Bu ordu aktif muharebede çarpışıyor
                  </div>
                ) : isTargeting ? (
                  <button
                    type="button"
                    onClick={onCancelTargeting}
                    className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-500 border-2 border-[#090d16] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg"
                  >
                    Hedef Seçimi Aktif (İptal Et)
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => onStartTargeting(army.id)}
                    className="w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-500 border-2 border-[#090d16] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg"
                  >
                    <Navigation className="w-4 h-4" />
                    Hedef Bölge Seç (Şehir / Cephe)
                  </button>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={total < 2 || Boolean(army.inBattleId)}
                    onClick={() => onAction({ type: 'SPLIT_ARMY', armyId: army.id })}
                    className="py-2 rounded-xl hud-tile hover:brightness-110 disabled:opacity-40 text-xs font-bold text-slate-100 flex items-center justify-center gap-1.5"
                  >
                    <GitFork className="w-3.5 h-3.5 text-sky-300" />
                    Orduyu Böl
                  </button>
                  <button
                    type="button"
                    disabled={sameProvOwnArmies < 2 || Boolean(army.inBattleId)}
                    onClick={() => onAction({ type: 'MERGE_ARMIES', provinceId: army.provinceId })}
                    className="py-2 rounded-xl hud-tile hover:brightness-110 disabled:opacity-40 text-xs font-bold text-slate-100 flex items-center justify-center gap-1.5"
                  >
                    <Combine className="w-3.5 h-3.5 text-emerald-300" />
                    Birleştir ({sameProvOwnArmies})
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {/* Commanders Tab */}
        {isMine && country && tab === 'commanders' && (
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Komutan Seç & Aç (1-Click)
              </div>
              <div className="text-[11px] font-mono-num text-amber-300 font-bold">
                {Math.floor(country.diplomacyPoints)} DP
              </div>
            </div>

            {cmdPool.map((cmd) => {
              const cs = country.commanders[cmd.id] || {
                id: cmd.id,
                unlocked: false,
                assignedArmyId: null,
                level: 1,
                xp: 0,
              };
              const isAssignedHere = army.commanderId === cmd.id;
              const assignedElsewhere =
                cs.assignedArmyId && cs.assignedArmyId !== army.id
                  ? state.armies[cs.assignedArmyId]
                  : null;
              const canUnlock = country.diplomacyPoints >= cmd.unlockCost;

              return (
                <div
                  key={cmd.id}
                  className={`p-2.5 rounded-2xl border-2 transition-all flex items-center justify-between gap-2.5 ${
                    isAssignedHere
                      ? 'bg-emerald-950/60 border-emerald-400'
                      : cs.unlocked
                      ? 'bg-slate-950/70 border-[#090d16] hover:border-slate-500'
                      : 'bg-slate-950/40 border-[#090d16] opacity-85'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <CommanderPortrait commander={cmd} className="w-11 h-11 shrink-0" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white truncate">{cmd.name}</span>
                        {cs.unlocked && (
                          <span className="text-[10px] font-mono-num text-amber-300 shrink-0">
                            Sv.{cs.level}
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">{cmd.title}</div>
                      <div className="flex flex-wrap gap-x-2 gap-y-0.5 text-[10px] font-semibold mt-1">
                        <span className="text-emerald-400 flex items-center gap-0.5">
                          <Swords className="w-2.5 h-2.5" />+{Math.round(cmd.attackBonus * 100)}%
                        </span>
                        <span className="text-sky-400 flex items-center gap-0.5">
                          <Shield className="w-2.5 h-2.5" />+{Math.round(cmd.defenseBonus * 100)}%
                        </span>
                        <span className="text-amber-300">+{Math.round(cmd.tankBonus * 100)}% Tank</span>
                      </div>
                      {assignedElsewhere && (
                        <div className="text-[10px] text-amber-300/90 mt-0.5 truncate">
                          Görev: {assignedElsewhere.name}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="shrink-0">
                    {!cs.unlocked ? (
                      <button
                        type="button"
                        disabled={!canUnlock}
                        onClick={() => onAction({ type: 'UNLOCK_COMMANDER', commanderId: cmd.id })}
                        className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 border border-[#090d16] text-[11px] font-bold text-white flex items-center gap-1"
                      >
                        <Lock className="w-3 h-3" />
                        <span>{cmd.unlockCost} DP</span>
                      </button>
                    ) : isAssignedHere ? (
                      <button
                        type="button"
                        onClick={() =>
                          onAction({
                            type: 'ASSIGN_COMMANDER',
                            commanderId: cmd.id,
                            armyId: null,
                          })
                        }
                        className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-rose-700 border border-emerald-400 text-[11px] font-bold text-white transition-colors"
                      >
                        Atandı
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() =>
                          onAction({
                            type: 'ASSIGN_COMMANDER',
                            commanderId: cmd.id,
                            armyId: army.id,
                          })
                        }
                        className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 border border-[#090d16] text-[11px] font-bold text-white transition-colors"
                      >
                        {assignedElsewhere ? 'Aktar' : 'Ata'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
