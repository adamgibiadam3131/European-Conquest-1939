import React from 'react';
import {
  Pause,
  Play,
  Save,
  Volume2,
  VolumeX,
  HelpCircle,
  Wifi,
  WifiOff,
  Trophy,
} from 'lucide-react';
import type { GameSpeed, GameState } from '../../shared/types.ts';
import { COUNTRIES } from '../../shared/data/countries.ts';
import { formatCompact, formatGameDate } from '../../shared/utils/gameHelpers.ts';
import { CountryFlag } from './CountryFlag.tsx';
import {
  IconCoins,
  IconFactoryBadge,
  IconManpowerBadge,
  IconDiplomacyTemple,
  IconUraniumAtom,
  IconCrown,
} from './GameIcons.tsx';

interface TopBarProps {
  state: GameState;
  playerCountryId: string | null;
  isHost: boolean;
  connected: boolean;
  muted: boolean;
  onTogglePause: () => void;
  onSetSpeed: (speed: GameSpeed) => void;
  onSaveGame: () => void;
  onToggleMute: () => void;
  onOpenTutorial: () => void;
  onOpenLeaderboard: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  state,
  playerCountryId,
  isHost,
  connected,
  muted,
  onTogglePause,
  onSetSpeed,
  onSaveGame,
  onToggleMute,
  onOpenTutorial,
  onOpenLeaderboard,
}) => {
  const country = playerCountryId ? state.countries[playerCountryId] : null;
  const staticCountry = playerCountryId ? COUNTRIES[playerCountryId] : null;
  const canControlClock = state.mode === 'singleplayer' || isHost;
  const netIncome = country?.economy.netIncome ?? 0;

  return (
    <header className="fixed top-2.5 left-3 right-3 z-30 pointer-events-none flex items-center justify-between gap-2">
      {/* Left Spacer / Quick System Pills */}
      <div className="pointer-events-auto flex items-center gap-1.5 shrink-0">
        {state.mode === 'multiplayer' && (
          <div
            className={`hud-pill h-10 px-3 rounded-full flex items-center gap-1.5 text-xs font-semibold ${
              connected ? 'text-emerald-300' : 'text-rose-300'
            }`}
            title={connected ? 'Sunucu Bağlı' : 'Yeniden Bağlanıyor...'}
          >
            {connected ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
          </div>
        )}

        <button
          onClick={onSaveGame}
          title="Oyunu Kaydet"
          className="hud-pill h-10 px-3 rounded-full flex items-center gap-1.5 text-xs font-bold text-sky-200 hover:brightness-110 active:scale-95 transition-transform"
        >
          <Save className="w-4 h-4 text-sky-400" />
          <span className="hidden xl:inline hud-text-shadow">Kaydet</span>
        </button>

        <button
          onClick={onToggleMute}
          title={muted ? 'Sesi Aç' : 'Sesi Kapat'}
          className="hud-pill h-10 w-10 rounded-full flex items-center justify-center text-slate-200 hover:brightness-110 active:scale-95 transition-transform"
        >
          {muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
        </button>

        <button
          onClick={onOpenTutorial}
          title="Oyun Rehberi"
          className="hud-pill h-10 w-10 rounded-full flex items-center justify-center text-amber-300 hover:brightness-110 active:scale-95 transition-transform"
        >
          <HelpCircle className="w-4 h-4" />
        </button>
      </div>

      {/* Center Screenshot-Matched Resource & Identity Capsules */}
      <div className="pointer-events-auto flex items-center justify-center gap-2 lg:gap-2.5 overflow-x-auto no-scrollbar">
        {country && (
          <>
            {/* Money Pill */}
            <div
              className="hud-pill h-11 px-3.5 rounded-full flex items-center gap-2 shrink-0"
              title={`Hazine: ${Math.round(country.money)} · Günlük Net: ${netIncome >= 0 ? '+' : ''}${Math.round(netIncome)}`}
            >
              <IconCoins className="w-6 h-6 shrink-0" />
              <div className="flex flex-col leading-none">
                <span className="font-mono-num text-base font-extrabold text-amber-300 hud-text-shadow">
                  {formatCompact(country.money)}
                </span>
                <span
                  className={`font-mono-num text-[10px] font-bold ${
                    netIncome >= 0 ? 'text-emerald-300' : 'text-rose-300'
                  }`}
                >
                  {netIncome >= 0 ? `+${formatCompact(netIncome)}` : formatCompact(netIncome)}/g
                </span>
              </div>
            </div>

            {/* Factories Pill */}
            <div
              className="hud-pill h-11 px-3.5 rounded-full flex items-center gap-2 shrink-0"
              title={`Toplam Fabrika: ${country.totalFactories} · Verimlilik: %${Math.round(country.economy.factoryEfficiency * 100)}`}
            >
              <IconFactoryBadge className="w-6 h-6 shrink-0" />
              <span className="font-mono-num text-base font-extrabold text-orange-300 hud-text-shadow">
                {country.totalFactories}
              </span>
            </div>

            {/* Manpower Pill */}
            <div
              className="hud-pill h-11 px-3.5 rounded-full flex items-center gap-2 shrink-0"
              title={`İnsan Gücü: ${formatCompact(country.manpower)} / ${formatCompact(country.maxManpower)}`}
            >
              <IconManpowerBadge className="w-6 h-6 shrink-0" />
              <span className="font-mono-num text-base font-extrabold text-sky-200 hud-text-shadow">
                {formatCompact(country.manpower)}
              </span>
            </div>

            {/* Diplomacy Pill */}
            <div
              className="hud-pill h-11 px-3.5 rounded-full flex items-center gap-2 shrink-0"
              title="Diplomasi Puanı"
            >
              <IconDiplomacyTemple className="w-6 h-6 shrink-0" />
              <span className="font-mono-num text-base font-extrabold text-slate-100 hud-text-shadow">
                {Math.floor(country.diplomacyPoints)}
              </span>
            </div>

            {/* Uranium / Nukes Pill (Compact when 0 or show full) */}
            {(country.uranium > 0 || country.nukes > 0) && (
              <div
                className="hud-pill h-11 px-3 rounded-full flex items-center gap-2 shrink-0"
                title={`Uranyum: ${Math.floor(country.uranium)} · Nükleer Bomba: ${country.nukes}`}
              >
                <IconUraniumAtom className="w-5 h-5 shrink-0" />
                <span className="font-mono-num text-sm font-extrabold text-lime-300 hud-text-shadow">
                  {Math.floor(country.uranium)}
                  {country.nukes > 0 ? ` · ☢${country.nukes}` : ''}
                </span>
              </div>
            )}
          </>
        )}

        {/* Country Identity Capsule */}
        <div className="hud-pill h-11 px-4 rounded-full flex items-center gap-2.5 shrink-0">
          <div className="flex flex-col">
            <span className="font-display text-lg font-extrabold tracking-wide text-white hud-text-shadow whitespace-nowrap leading-none">
              {staticCountry?.name || 'Gözlemci Modu'}
            </span>
            {country && (
              <div className="mt-1 h-1.5 w-full rounded-full bg-slate-950/90 overflow-hidden flex">
                <div
                  className="h-full bg-emerald-400 transition-all duration-300"
                  style={{ width: `${Math.min(100, Math.round(country.economy.factoryEfficiency * 85))}%` }}
                />
                <div className="h-full bg-amber-400 flex-1 opacity-75" />
              </div>
            )}
          </div>
          {playerCountryId && (
            <CountryFlag countryId={playerCountryId} className="w-8 h-5 rounded border border-slate-950 shadow" />
          )}
        </div>

        {/* Date + Speed Capsule */}
        <div className="hud-pill h-11 pl-4 pr-2 rounded-full flex items-center gap-2.5 shrink-0">
          <div className="flex flex-col leading-none">
            <span className="font-display text-base font-extrabold text-white hud-text-shadow whitespace-nowrap">
              {formatGameDate(state.day)}
            </span>
            <div className="mt-1 h-1.5 w-28 rounded-full bg-slate-950 overflow-hidden">
              <div
                className={`h-full transition-all duration-200 ${
                  state.paused ? 'bg-amber-400 w-1/3' : 'bg-emerald-400'
                }`}
                style={{
                  width: state.paused ? '40%' : `${((state.day % 30) / 30) * 100}%`,
                }}
              />
            </div>
          </div>

          <button
            onClick={onTogglePause}
            disabled={!canControlClock}
            title={canControlClock ? 'Duraklat / Devam Et (Space)' : 'Sadece oda sahibi hızı yönetebilir'}
            className={`w-8 h-8 rounded-full border-2 border-slate-950 flex items-center justify-center transition-transform active:scale-95 ${
              state.paused
                ? 'bg-amber-500 text-slate-950'
                : 'bg-slate-700 text-white hover:bg-slate-600'
            } disabled:opacity-40`}
          >
            {state.paused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5 fill-current" />}
          </button>

          <div className="flex items-center bg-slate-950/80 rounded-full p-0.5 gap-0.5">
            {([1, 2, 4] as GameSpeed[]).map((spd) => (
              <button
                key={spd}
                onClick={() => onSetSpeed(spd)}
                disabled={!canControlClock}
                className={`px-2 py-0.5 text-[11px] font-mono-num font-bold rounded-full transition-colors ${
                  state.speed === spd
                    ? 'bg-sky-500 text-slate-950'
                    : 'text-slate-300 hover:text-white'
                } disabled:opacity-40`}
              >
                {spd}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Top Right Crown / Victory Button */}
      <div className="pointer-events-auto shrink-0">
        <button
          onClick={onOpenLeaderboard}
          title="Zafer İlerlemesi ve Sıralama"
          className="hud-pill h-11 w-11 rounded-full flex items-center justify-center hover:brightness-110 active:scale-95 transition-transform"
        >
          <IconCrown className="w-6 h-6" />
          <span className="sr-only">
            <Trophy />
          </span>
        </button>
      </div>
    </header>
  );
};
