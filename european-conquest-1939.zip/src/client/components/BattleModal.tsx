import React from 'react';
import { Swords, X } from 'lucide-react';
import type { GameState, LandUnitType, MapDataStatic } from '../../shared/types.ts';
import { COUNTRIES } from '../../shared/data/countries.ts';
import { LAND_UNITS } from '../../shared/data/units.ts';
import { CountryFlag } from './CountryFlag.tsx';

interface BattleModalProps {
  battleId: string;
  state: GameState;
  mapData: MapDataStatic;
  onClose: () => void;
}

const UNIT_ORDER: LandUnitType[] = [
  'infantry',
  'tank',
  'antitank',
  'artillery',
  'motorized',
  'antiair',
];

export const BattleModal: React.FC<BattleModalProps> = ({
  battleId,
  state,
  mapData,
  onClose,
}) => {
  const battle = state.battles[battleId];
  if (!battle) return null;

  const provName = mapData.provinces.find((p) => p.id === battle.provinceId)?.name || battle.provinceId;
  const atkCountry = COUNTRIES[battle.attackerCountryId];
  const defCountry = COUNTRIES[battle.defenderCountryId];

  return (
    <div className="fixed inset-x-0 top-16 z-35 flex justify-center px-4 pointer-events-none">
      <div className="pointer-events-auto w-full max-w-[660px] bg-slate-900/95 backdrop-blur-lg border border-rose-700/70 rounded-2xl shadow-2xl overflow-hidden">
        <div className="px-5 py-3 bg-rose-950/50 border-b border-rose-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Swords className="w-5 h-5 text-rose-400" />
            <h3 className="font-display text-xl font-bold text-white">
              {provName} Muharebesi
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Strength & Progress Bar */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <CountryFlag countryId={battle.attackerCountryId} className="w-9 h-6" />
              <div>
                <div className="text-xs font-bold text-white">{atkCountry?.name} (Saldıran)</div>
                <div className="font-mono-num text-sm font-bold text-sky-400">
                  {battle.attacker.currentStrength}K{' '}
                  <span className="text-[11px] text-slate-400">
                    / {battle.attacker.initialStrength}K
                  </span>
                </div>
              </div>
            </div>

            <div className="flex-1 max-w-[200px]">
              <div className="h-3 bg-rose-950 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-sky-500 transition-all duration-200"
                  style={{ width: `${Math.round(battle.progress)}%` }}
                />
              </div>
              <div className="text-center font-mono-num text-[11px] text-slate-300 mt-1">
                Cephe Dengesi: %{Math.round(battle.progress)}
              </div>
            </div>

            <div className="flex items-center gap-2.5 text-right">
              <div>
                <div className="text-xs font-bold text-white">{defCountry?.name} (Savunan)</div>
                <div className="font-mono-num text-sm font-bold text-rose-400">
                  {battle.defender.currentStrength}K{' '}
                  <span className="text-[11px] text-slate-400">
                    / {battle.defender.initialStrength}K
                  </span>
                </div>
              </div>
              <CountryFlag countryId={battle.defenderCountryId} className="w-9 h-6" />
            </div>
          </div>

          {/* Modifiers & Casualties Grid */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            {[
              { side: battle.attacker, label: 'Saldıran Etkenleri & Kayıplar' },
              { side: battle.defender, label: 'Savunan Etkenleri & Kayıplar' },
            ].map(({ side, label }, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-950/75 border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200 border-b border-slate-800 pb-1">
                  {label}
                </div>
                <div className="text-[11px] text-slate-400 space-y-0.5">
                  <div>Komutan: {side.commanderName || 'Yok'}</div>
                  <div className="flex flex-wrap gap-x-2 font-mono-num">
                    <span>Teknoloji: +{side.modifiers.techBonus}%</span>
                    <span>Komutan: +{side.modifiers.commanderBonus}%</span>
                    <span>Arazi: {side.modifiers.terrainBonus >= 0 ? `+${side.modifiers.terrainBonus}%` : `${side.modifiers.terrainBonus}%`}</span>
                    <span>Hava: +{side.modifiers.airSupport}%</span>
                  </div>
                </div>
                <div className="pt-1 border-t border-slate-800/80">
                  <div className="text-[10px] text-rose-300 font-semibold mb-1">Verilen Kayıplar</div>
                  <div className="grid grid-cols-2 gap-1 font-mono-num text-[11px]">
                    {UNIT_ORDER.map((ut) => {
                      const loss = side.casualties[ut];
                      if (loss === 0) return null;
                      return (
                        <div key={ut} className="text-slate-300">
                          {LAND_UNITS[ut].name.replace(' (1K)', '')}:{' '}
                          <span className="text-rose-400">-{loss}K</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
