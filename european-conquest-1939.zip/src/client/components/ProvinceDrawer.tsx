import React from 'react';
import {
  X,
  Factory,
  Home,
  Shield,
  Plane,
  Anchor,
  Radio,
  Atom,
  Train,
  Route,
  Users,
  Crosshair,
  Navigation,
  Swords,
  Flag,
  CheckCircle2,
} from 'lucide-react';
import type { BuildingType, ClientAction, GameState, MapDataStatic } from '../../shared/types.ts';
import { COUNTRIES } from '../../shared/data/countries.ts';
import { BUILDINGS, TERRAIN_MODIFIERS } from '../../shared/data/units.ts';
import {
  canEnterProvince,
  canPlayerSeeArmy,
  formatCompact,
  getArmyTotal,
  getRelation,
} from '../../shared/utils/gameHelpers.ts';
import { CountryFlag } from './CountryFlag.tsx';

interface ProvinceDrawerProps {
  provinceId: string;
  state: GameState;
  mapData: MapDataStatic;
  playerCountryId: string | null;
  selectedArmyId: string | null;
  onMarchSelectedArmy: (targetProvinceId: string) => void;
  onAction: (action: ClientAction) => void;
  onSelectArmy: (armyId: string) => void;
  onClose: () => void;
}

const BUILDING_LIST: { id: BuildingType; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'factory', icon: Factory },
  { id: 'housing', icon: Home },
  { id: 'road', icon: Route },
  { id: 'railway', icon: Train },
  { id: 'military_base', icon: Shield },
  { id: 'airbase', icon: Plane },
  { id: 'port', icon: Anchor },
  { id: 'radar', icon: Radio },
  { id: 'nuclear_facility', icon: Atom },
];

export const ProvinceDrawer: React.FC<ProvinceDrawerProps> = ({
  provinceId,
  state,
  mapData,
  playerCountryId,
  selectedArmyId,
  onMarchSelectedArmy,
  onAction,
  onSelectArmy,
  onClose,
}) => {
  const mp = mapData.provinces.find((p) => p.id === provinceId);
  const ps = state.provinces[provinceId];
  if (!mp || !ps) return null;

  const owner = COUNTRIES[ps.controllerId];
  const isMine = playerCountryId === ps.controllerId;
  const myCountry = playerCountryId ? state.countries[playerCountryId] : null;
  const allArmiesHere = Object.values(state.armies).filter(
    (a) => a.provinceId === provinceId && getArmyTotal(a.units) > 0
  );
  const armiesHere = allArmiesHere.filter((a) =>
    canPlayerSeeArmy(state, mapData, playerCountryId, a)
  );
  const hasHiddenArmies = allArmiesHere.length > armiesHere.length;
  const rel =
    playerCountryId && !isMine
      ? getRelation(state.relations, playerCountryId, ps.controllerId)
      : null;
  const armedArmy = selectedArmyId ? state.armies[selectedArmyId] : null;
  const effectiveRecruitId =
    myCountry?.recruitProvinceId &&
    state.provinces[myCountry.recruitProvinceId]?.controllerId === playerCountryId
      ? myCountry.recruitProvinceId
      : playerCountryId && state.provinces[COUNTRIES[playerCountryId]?.capitalProvinceId]?.controllerId === playerCountryId
      ? COUNTRIES[playerCountryId].capitalProvinceId
      : null;
  const isRecruitHub = Boolean(isMine && effectiveRecruitId === provinceId);
  const canMarchHere = Boolean(
    armedArmy &&
      armedArmy.countryId === playerCountryId &&
      armedArmy.provinceId !== provinceId &&
      playerCountryId &&
      canEnterProvince(state, playerCountryId, provinceId)
  );

  return (
    <div className="animate-drawer-in fixed left-18 bottom-4 z-25 w-[370px] max-w-[calc(100vw-6rem)] max-h-[68vh] flex flex-col bg-slate-900/95 backdrop-blur-lg border-2 border-slate-950 ring-1 ring-slate-600/50 rounded-2xl shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-700/70 bg-slate-950/60 flex items-center justify-between">
        <div className="flex items-center gap-2.5 min-w-0">
          <CountryFlag countryId={ps.controllerId} className="w-8 h-5" />
          <div className="min-w-0">
            <h3 className="font-display text-lg font-bold text-white leading-none truncate">
              {mp.name} {mp.isCapital ? '★' : ''}
            </h3>
            <div className="text-[11px] text-slate-400 mt-0.5 truncate">
              {owner?.name} · {TERRAIN_MODIFIERS[mp.terrain].label}
              {mp.isPort ? ' · Liman Şehri' : ''}
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 overflow-y-auto space-y-3.5 text-xs">
        {/* Core Province Metrics */}
        <div className="grid grid-cols-2 gap-2">
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400">Nüfus / Şehir Gücü</div>
            <div className="font-mono-num font-bold text-slate-100 flex items-center gap-1 mt-0.5">
              <Users className="w-3.5 h-3.5 text-sky-400" />
              {formatCompact(ps.population)}
            </div>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400">Fabrika Sayısı</div>
            <div className="font-mono-num font-bold text-amber-300 flex items-center gap-1 mt-0.5">
              <Factory className="w-3.5 h-3.5 text-amber-400" />
              {ps.buildings.factory} Fabrika
            </div>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400">Savunma Bonusu</div>
            <div className="font-mono-num font-bold text-emerald-400 mt-0.5">
              +{ps.defenseLevel}%
            </div>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
            <div className="text-[10px] text-slate-400">İkmal Durumu</div>
            <div className="font-mono-num font-bold text-sky-300 mt-0.5">%{ps.supplyLevel}</div>
          </div>
        </div>

        {/* Rally / Army Spawn Point Selection for Own Cities */}
        {isMine && myCountry && (
          <button
            type="button"
            disabled={isRecruitHub}
            onClick={() => onAction({ type: 'SET_RECRUIT_PROVINCE', provinceId })}
            className={`w-full px-3 py-2.5 rounded-xl border-2 text-xs font-bold flex items-center justify-center gap-2 transition-all ${
              isRecruitHub
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 cursor-default'
                : 'bg-amber-600/90 hover:bg-amber-500 border-[#090d16] text-white shadow-md active:scale-95'
            }`}
          >
            {isRecruitHub ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Seçili Ordu Çıkış Şehri (Yeni Ordular Burada Çıkar)</span>
              </>
            ) : (
              <>
                <Flag className="w-4 h-4 shrink-0" />
                <span>Ordu Oluşturma Yeri Yap (Ordular Burada Çıksın)</span>
              </>
            )}
          </button>
        )}

        {/* Armies Stationed */}
        <div>
          <div className="text-[11px] font-semibold text-slate-300 mb-1.5">
            Bölgedeki Ordular ({armiesHere.length})
          </div>
          {armiesHere.length === 0 ? (
            <div className="text-[11px] text-slate-500">
              {hasHiddenArmies
                ? 'Bu bölgedeki birlikler görüş menzili dışında (sınır komşusu değil).'
                : 'Bu bölgede konuşlu ordu yok.'}
            </div>
          ) : (
            <div className="space-y-1.5">
              {armiesHere.map((army) => (
                <button
                  key={army.id}
                  onClick={() => onSelectArmy(army.id)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950/75 border border-slate-800 hover:border-sky-500 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <CountryFlag countryId={army.countryId} className="w-5 h-3.5" />
                    <span className="font-medium text-slate-100">{army.name}</span>
                  </div>
                  <span className="font-mono-num font-bold text-sky-300">
                    {getArmyTotal(army.units)}K
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Active Constructions */}
        {ps.constructions.length > 0 && (
          <div className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-700/40 space-y-1">
            <div className="text-[11px] font-semibold text-amber-300">Devam Eden İnşaatlar</div>
            {ps.constructions.map((c) => (
              <div key={c.id} className="flex justify-between text-[11px] text-amber-100 font-mono-num">
                <span>{BUILDINGS[c.buildingType].name}</span>
                <span>{c.daysRemaining} gün</span>
              </div>
            ))}
          </div>
        )}

        {/* Construction Grid for Own Province */}
        {isMine && myCountry && (
          <div>
            <div className="text-[11px] font-semibold text-slate-300 mb-1.5">Bölge İnşaatları</div>
            <div className="grid grid-cols-3 gap-1.5">
              {BUILDING_LIST.map(({ id, icon: Icon }) => {
                const spec = BUILDINGS[id];
                if (spec.requiresPort && !mp.isPort) return null;
                const techLocked = Boolean(
                  spec.requiredTech && !myCountry.researchedTechs.includes(spec.requiredTech)
                );
                const count = ps.buildings[id];
                const queued = ps.constructions.filter((c) => c.buildingType === id).length;
                const maxed = count + queued >= spec.maxPerProvince;
                const canAfford = myCountry.money >= spec.cost;

                return (
                  <button
                    key={id}
                    disabled={techLocked || maxed || !canAfford}
                    onClick={() =>
                      onAction({
                        type: 'BUILD_STRUCTURE',
                        provinceId,
                        buildingType: id,
                      })
                    }
                    title={`${spec.name}: ${spec.description} (${formatCompact(spec.cost)} Para, ${spec.buildDays}g)`}
                    className="p-2 rounded-lg bg-slate-950/75 border border-slate-800 hover:border-sky-500 disabled:opacity-40 flex flex-col items-center text-center gap-1 transition-colors"
                  >
                    <Icon className="w-4 h-4 text-sky-300" />
                    <span className="text-[10px] font-medium text-slate-200 leading-tight truncate w-full">
                      {spec.name.split(' ')[0]}
                    </span>
                    <span className="font-mono-num text-[10px] text-amber-300">
                      {count}/{spec.maxPerProvince} · {formatCompact(spec.cost)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Direct March Shortcut if player has an armed army */}
        {canMarchHere && armedArmy && (
          <button
            onClick={() => onMarchSelectedArmy(provinceId)}
            className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-transform active:scale-95 ${
              rel?.atWar
                ? 'bg-rose-600 hover:bg-rose-500 text-white'
                : 'bg-sky-600 hover:bg-sky-500 text-white'
            }`}
          >
            <Navigation className="w-4 h-4" />
            {armedArmy.name} ({getArmyTotal(armedArmy.units)}K) Buraya Yürüt
          </button>
        )}

        {/* Quick Declare War Shortcut on Foreign Provinces */}
        {!isMine && rel && !rel.atWar && myCountry && (
          <button
            disabled={myCountry.diplomacyPoints < 20}
            onClick={() =>
              onAction({
                type: 'DIPLOMACY_ACTION',
                targetCountryId: ps.controllerId,
                action: 'declare_war',
              })
            }
            className="w-full py-2.5 rounded-xl bg-rose-700 hover:bg-rose-600 disabled:opacity-40 text-white font-bold text-xs flex items-center justify-center gap-2 transition-transform active:scale-95"
          >
            <Swords className="w-4 h-4" />
            {owner?.name} Ülkesine Savaş İlan Et (20 Diplomasi)
          </button>
        )}

        {/* Nuke Launch Button if at war & player has nukes */}
        {!isMine && rel?.atWar && myCountry && myCountry.nukes > 0 && (
          <button
            onClick={() => onAction({ type: 'LAUNCH_NUKE', targetProvinceId: provinceId })}
            className="w-full py-2.5 rounded-xl bg-lime-600 hover:bg-lime-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2"
          >
            <Crosshair className="w-4 h-4" />
            NÜKLEER SALDIRI BAŞLAT ({myCountry.nukes} Bomba Mevcut)
          </button>
        )}
      </div>
    </div>
  );
};
