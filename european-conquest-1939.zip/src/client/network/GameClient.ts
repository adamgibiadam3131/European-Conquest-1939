import type { ClientAction, DifficultyLevel, GameState, RoomLobbyState } from '../../shared/types.ts';
import {
  deleteLocalSave,
  getLocalSave,
  listLocalSaves,
} from './P2PTransport.ts';

export { getLocalSave };

export interface SaveMetaItem {
  slotId: string;
  slotName: string;
  savedAt: string;
  day: number;
  scenarioId: string;
  humanCountryIds: string[];
  mode: 'singleplayer' | 'multiplayer';
  isLocal?: boolean;
}

export function getOrCreatePlayerId(): string {
  const key = 'ec1939_player_id';
  let id = localStorage.getItem(key);
  if (!id) {
    id = `plr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem(key, id);
  }
  return id;
}

export async function createRoomApi(params: {
  mode: 'singleplayer' | 'multiplayer';
  playerId: string;
  playerName: string;
  scenarioId?: '1939_alt' | '1939_hist';
  difficulty?: DifficultyLevel;
  victoryThreshold?: 75 | 80;
  maxHumanPlayers?: number;
  countryId?: string;
  loadSlotId?: string;
}): Promise<{ lobby: RoomLobbyState }> {
  const res = await fetch('/api/rooms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Oda oluşturulamadı.');
  }
  return res.json();
}

export async function listSavesApi(): Promise<SaveMetaItem[]> {
  const localItems: SaveMetaItem[] = listLocalSaves().map((s) => ({
    slotId: s.slotId,
    slotName: s.slotName,
    savedAt: s.savedAt,
    day: s.day,
    scenarioId: s.scenarioId,
    humanCountryIds: s.humanCountryIds,
    mode: s.mode,
    isLocal: true,
  }));

  let serverItems: SaveMetaItem[] = [];
  try {
    const res = await fetch('/api/saves');
    if (res.ok) {
      const data = await res.json();
      serverItems = data.saves || [];
    }
  } catch {
    // Server unreachable in standalone/shared P2P mode
  }

  const seen = new Set<string>();
  const combined: SaveMetaItem[] = [];
  for (const item of [...localItems, ...serverItems]) {
    if (seen.has(item.slotId)) continue;
    seen.add(item.slotId);
    combined.push(item);
  }
  return combined.sort((a, b) => Date.parse(b.savedAt) - Date.parse(a.savedAt));
}

export async function deleteSaveApi(slotId: string): Promise<void> {
  deleteLocalSave(slotId);
  try {
    await fetch(`/api/saves/${encodeURIComponent(slotId)}`, { method: 'DELETE' });
  } catch {
    // ignore
  }
}

export class GameSocketClient {
  private ws: WebSocket | null = null;
  private roomCode: string | null = null;
  private playerId: string;
  private playerName: string;
  private reconnectTimer: number | null = null;
  private closedManually = false;

  onSync?: (lobby: RoomLobbyState, state: GameState | null) => void;
  onError?: (message: string) => void;
  onSaveConfirmed?: (slotName: string) => void;
  onConnectionChange?: (connected: boolean) => void;

  constructor(playerId: string, playerName: string) {
    this.playerId = playerId;
    this.playerName = playerName;
  }

  connect(roomCode: string, playerName?: string) {
    if (playerName) this.playerName = playerName;
    this.roomCode = roomCode.trim().toUpperCase();
    this.closedManually = false;
    this.openSocket();
  }

  private openSocket() {
    if (!this.roomCode) return;
    if (this.ws) {
      this.ws.onclose = null;
      this.ws.close();
    }

    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      this.onConnectionChange?.(true);
      ws.send(
        JSON.stringify({
          type: 'JOIN_ROOM',
          roomCode: this.roomCode,
          playerId: this.playerId,
          playerName: this.playerName,
        })
      );
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'ROOM_SYNC') {
          this.onSync?.(msg.lobby, msg.state);
        } else if (msg.type === 'ERROR') {
          this.onError?.(msg.message);
        } else if (msg.type === 'SAVE_CONFIRMED') {
          this.onSaveConfirmed?.(msg.slotName);
        }
      } catch {
        // ignore invalid json
      }
    };

    ws.onclose = () => {
      this.onConnectionChange?.(false);
      if (!this.closedManually && this.roomCode) {
        this.reconnectTimer = window.setTimeout(() => this.openSocket(), 2000);
      }
    };
  }

  sendAction(action: ClientAction) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'ACTION', action }));
    }
  }

  disconnect() {
    this.closedManually = true;
    this.roomCode = null;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}
