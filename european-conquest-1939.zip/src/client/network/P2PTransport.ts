import { Peer, type DataConnection } from 'peerjs';
import type {
  ClientAction,
  DifficultyLevel,
  GameState,
  MapDataStatic,
  RoomLobbyState,
  RoomPlayer,
} from '../../shared/types.ts';
import {
  applyClientAction,
  createInitialGameState,
  tickGameDay,
} from '../../../server/engine/GameEngine.ts';

const PEER_PREFIX = 'ec1939-';
const LOCAL_SAVES_KEY = 'ec1939_local_saves_v1';

const ICE_SERVERS: RTCIceServer[] = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
  { urls: 'stun:stun3.l.google.com:19302' },
  { urls: 'stun:stun4.l.google.com:19302' },
];

export interface LocalSaveRecord {
  slotId: string;
  slotName: string;
  savedAt: string;
  day: number;
  scenarioId: string;
  humanCountryIds: string[];
  mode: 'singleplayer' | 'multiplayer';
  state: GameState;
}

export function generateP2PRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function listLocalSaves(): LocalSaveRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_SAVES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveLocalSlot(slotId: string, slotName: string, state: GameState): void {
  try {
    const saves = listLocalSaves().filter((s) => s.slotId !== slotId);
    const humanCountryIds = Object.values(state.countries)
      .filter((c) => c.isHuman)
      .map((c) => c.id);
    const rec: LocalSaveRecord = {
      slotId,
      slotName,
      savedAt: new Date().toISOString(),
      day: state.day,
      scenarioId: state.scenarioId,
      humanCountryIds,
      mode: state.mode,
      state: structuredClone(state),
    };
    saves.unshift(rec);
    // Keep up to 6 browser slots cleanly within localStorage limits
    if (saves.length > 6) saves.length = 6;
    localStorage.setItem(LOCAL_SAVES_KEY, JSON.stringify(saves));
  } catch {
    // ignore quota errors
  }
}

export function deleteLocalSave(slotId: string): void {
  try {
    const filtered = listLocalSaves().filter((s) => s.slotId !== slotId);
    localStorage.setItem(LOCAL_SAVES_KEY, JSON.stringify(filtered));
  } catch {
    // ignore
  }
}

export function getLocalSave(slotId: string): LocalSaveRecord | undefined {
  return listLocalSaves().find((s) => s.slotId === slotId);
}

export interface TransportCallbacks {
  onSync?: (lobby: RoomLobbyState, state: GameState | null) => void;
  onError?: (message: string) => void;
  onSaveConfirmed?: (slotName: string) => void;
  onConnectionChange?: (connected: boolean) => void;
}

export interface P2PClientTransport {
  sendAction: (action: ClientAction) => void;
  disconnect: () => void;
  readonly isP2P: boolean;
  readonly isP2PHost: boolean;
}

function encodePacket(payload: unknown): string {
  return JSON.stringify(payload);
}

function decodePacket(raw: unknown): Record<string, unknown> | null {
  try {
    if (typeof raw === 'string') return JSON.parse(raw);
    if (raw && typeof raw === 'object') return raw as Record<string, unknown>;
    return null;
  } catch {
    return null;
  }
}

export class P2PHostController implements P2PClientTransport {
  readonly isP2P: boolean;
  readonly isP2PHost = true;

  private peer: Peer | null = null;
  private conns = new Map<string, DataConnection>();
  private tickTimer: number | null = null;
  private destroyed = false;

  private lobby: RoomLobbyState;
  private state: GameState | null;
  private mapData: MapDataStatic;
  private hostPlayerId: string;
  private callbacks: TransportCallbacks;

  constructor(params: {
    mode: 'singleplayer' | 'multiplayer';
    enableNetworkP2P: boolean;
    playerId: string;
    playerName: string;
    scenarioId: '1939_alt' | '1939_hist';
    difficulty: DifficultyLevel;
    victoryThreshold: 75 | 80;
    maxHumanPlayers: number;
    countryId?: string | null;
    loadedState?: GameState;
    mapData: MapDataStatic;
    callbacks: TransportCallbacks;
  }) {
    this.isP2P = params.enableNetworkP2P;
    this.hostPlayerId = params.playerId;
    this.mapData = params.mapData;
    this.callbacks = params.callbacks;

    const roomCode = generateP2PRoomCode();
    const roomId = `p2p_${Date.now()}_${roomCode}`;

    const hostPlayer: RoomPlayer = {
      playerId: params.playerId,
      name: params.playerName || 'Başkomutan',
      countryId: params.countryId || null,
      ready: params.mode === 'singleplayer',
      connected: true,
      isHost: true,
    };

    this.state = params.loadedState ? structuredClone(params.loadedState) : null;
    if (this.state) {
      this.state.roomId = roomId;
      const humanCid = Object.values(this.state.countries).find((c) => c.isHuman)?.id || null;
      if (humanCid) {
        hostPlayer.countryId = humanCid;
        this.state.countries[humanCid].playerId = params.playerId;
      }
    }

    this.lobby = {
      roomId,
      roomCode,
      mode: params.mode,
      status: this.state ? 'playing' : 'lobby',
      maxHumanPlayers: params.maxHumanPlayers,
      scenarioId: this.state?.scenarioId || params.scenarioId,
      difficulty: this.state?.difficulty || params.difficulty,
      victoryThreshold: this.state?.victoryThreshold || params.victoryThreshold,
      players: [hostPlayer],
    };

    if (params.enableNetworkP2P) {
      this.initPeer(roomCode, 0);
    } else {
      this.callbacks.onConnectionChange?.(true);
      this.broadcastSync();
      if (this.state) {
        this.scheduleNextTick();
      }
    }
  }

  private initPeer(roomCode: string, attempt: number) {
    if (this.destroyed) return;
    this.lobby.roomCode = roomCode;
    const peer = new Peer(`${PEER_PREFIX}${roomCode}`, {
      config: { iceServers: ICE_SERVERS },
      debug: 0,
    });
    this.peer = peer;

    peer.on('open', () => {
      if (this.destroyed) return;
      this.callbacks.onConnectionChange?.(true);
      this.broadcastSync();
      if (this.state) {
        this.scheduleNextTick();
      }
    });

    peer.on('disconnected', () => {
      if (!this.destroyed && this.peer && !this.peer.destroyed) {
        try {
          this.peer.reconnect();
        } catch {
          // ignore
        }
      }
    });

    peer.on('connection', (conn) => {
      this.attachIncomingConnection(conn);
    });

    peer.on('error', (err) => {
      if (this.destroyed) return;
      if (err.type === 'unavailable-id' && attempt < 3) {
        peer.destroy();
        this.initPeer(generateP2PRoomCode(), attempt + 1);
        return;
      }
      this.callbacks.onError?.(
        `P2P sunucu hatası (${err.type || 'bağlantı'}). İnternet bağlantınızı kontrol edin.`
      );
      this.callbacks.onConnectionChange?.(false);
    });
  }

  private attachIncomingConnection(conn: DataConnection) {
    let boundPlayerId: string | null = null;

    conn.on('data', (raw) => {
      if (this.destroyed) return;
      const msg = decodePacket(raw);
      if (!msg) return;

      if (msg.type === 'JOIN_ROOM') {
        const pid = String(msg.playerId || '');
        const pname = String(msg.playerName || 'Komutan');
        if (!pid) return;

        const existing = this.lobby.players.find((p) => p.playerId === pid);
        if (existing) {
          existing.connected = true;
          if (pname) existing.name = pname;
          if (this.state && existing.countryId && this.state.countries[existing.countryId]) {
            this.state.countries[existing.countryId].isHuman = true;
            this.state.countries[existing.countryId].playerId = pid;
          }
        } else {
          if (this.lobby.status !== 'lobby') {
            conn.send(
              encodePacket({
                type: 'ERROR',
                message: 'Bu P2P oyuna katılım süresi dolmuş (oyun zaten başladı).',
              })
            );
            return;
          }
          if (this.lobby.players.length >= this.lobby.maxHumanPlayers) {
            conn.send(
              encodePacket({
                type: 'ERROR',
                message: `P2P oda dolu (Maksimum ${this.lobby.maxHumanPlayers} oyuncu).`,
              })
            );
            return;
          }
          this.lobby.players.push({
            playerId: pid,
            name: pname || `Oyuncu ${this.lobby.players.length + 1}`,
            countryId: null,
            ready: false,
            connected: true,
            isHost: false,
          });
        }

        boundPlayerId = pid;
        this.conns.set(pid, conn);
        this.broadcastSync();
        return;
      }

      if (msg.type === 'ACTION' && boundPlayerId && msg.action) {
        this.handleAction(boundPlayerId, msg.action as ClientAction);
      }
    });

    conn.on('close', () => {
      if (!boundPlayerId) return;
      const current = this.conns.get(boundPlayerId);
      if (current === conn) {
        this.conns.delete(boundPlayerId);
        const p = this.lobby.players.find((pl) => pl.playerId === boundPlayerId);
        if (p) {
          p.connected = false;
          this.broadcastSync();
        }
      }
    });
  }

  sendAction(action: ClientAction): void {
    this.handleAction(this.hostPlayerId, action);
  }

  private handleAction(playerId: string, action: ClientAction) {
    if (this.destroyed) return;
    const player = this.lobby.players.find((p) => p.playerId === playerId);
    if (!player) return;

    if (action.type === 'SELECT_COUNTRY') {
      if (this.lobby.status !== 'lobby') return;
      const taken = this.lobby.players.some(
        (p) => p.playerId !== playerId && p.countryId === action.countryId
      );
      if (taken) {
        this.sendToPlayer(playerId, {
          type: 'ERROR',
          message: 'Bu ülke başka bir oyuncu tarafından seçilmiş.',
        });
        return;
      }
      player.countryId = action.countryId;
      this.broadcastSync();
      return;
    }

    if (action.type === 'TOGGLE_READY') {
      if (this.lobby.status !== 'lobby') return;
      player.ready = !player.ready;
      this.broadcastSync();
      return;
    }

    if (action.type === 'UPDATE_SETTINGS') {
      if (!player.isHost || this.lobby.status !== 'lobby') return;
      if (action.scenarioId) this.lobby.scenarioId = action.scenarioId;
      if (action.difficulty) this.lobby.difficulty = action.difficulty;
      if (action.victoryThreshold) this.lobby.victoryThreshold = action.victoryThreshold;
      if (
        action.maxHumanPlayers &&
        action.maxHumanPlayers >= 2 &&
        action.maxHumanPlayers <= 16
      ) {
        this.lobby.maxHumanPlayers = action.maxHumanPlayers;
      }
      this.broadcastSync();
      return;
    }

    if (action.type === 'START_GAME') {
      if (!player.isHost || this.lobby.status !== 'lobby') return;
      const missingCountry = this.lobby.players.some((p) => !p.countryId);
      if (missingCountry) {
        this.sendToPlayer(playerId, {
          type: 'ERROR',
          message: 'Başlamak için tüm oyuncular bir ülke seçmelidir.',
        });
        return;
      }
      const humanAssignments: Record<string, string> = {};
      for (const p of this.lobby.players) {
        if (p.countryId) humanAssignments[p.countryId] = p.playerId;
      }
      this.state = createInitialGameState({
        roomId: this.lobby.roomId,
        mode: this.lobby.mode,
        scenarioId: this.lobby.scenarioId,
        difficulty: this.lobby.difficulty,
        victoryThreshold: this.lobby.victoryThreshold,
        humanAssignments,
        mapData: this.mapData,
      });
      this.lobby.status = 'playing';
      this.broadcastSync();
      this.scheduleNextTick();
      return;
    }

    const state = this.state;
    if (!state) return;

    if (action.type === 'SET_PAUSE') {
      if (this.lobby.mode === 'multiplayer' && !player.isHost) return;
      state.paused = action.paused;
      this.broadcastSync();
      return;
    }

    if (action.type === 'SET_SPEED') {
      if (this.lobby.mode === 'multiplayer' && !player.isHost) return;
      state.speed = action.speed;
      this.broadcastSync();
      this.scheduleNextTick();
      return;
    }

    if (action.type === 'SAVE_GAME') {
      const slotId = `local_${this.lobby.mode}_${player.countryId || 'game'}_${Date.now()}`;
      saveLocalSlot(slotId, action.slotName, state);
      this.sendToPlayer(playerId, {
        type: 'SAVE_CONFIRMED',
        slotName: action.slotName,
      });
      return;
    }

    if (action.type === 'SURRENDER_TO_AI') {
      if (player.countryId && state.countries[player.countryId]) {
        state.countries[player.countryId].isHuman = false;
        state.countries[player.countryId].playerId = null;
      }
      player.countryId = null;
      this.broadcastSync();
      return;
    }

    if (!player.countryId) return;
    applyClientAction(state, this.mapData, player.countryId, action);
    this.broadcastSync();
  }

  private scheduleNextTick() {
    if (this.tickTimer !== null) {
      window.clearTimeout(this.tickTimer);
      this.tickTimer = null;
    }
    if (this.destroyed || !this.state || this.state.victory) return;

    const delay =
      this.state.speed === 4 ? 250 : this.state.speed === 2 ? 500 : 1000;

    this.tickTimer = window.setTimeout(() => {
      if (this.destroyed || !this.state) return;
      if (!this.state.paused && !this.state.victory) {
        tickGameDay(this.state, this.mapData);
        if (this.state.day > 0 && this.state.day % 30 === 0) {
          saveLocalSlot(
            `local_autosave_${this.lobby.roomCode}`,
            `Otomatik Kayıt (${this.lobby.roomCode}) - Gün ${this.state.day}`,
            this.state
          );
        }
        if (this.state.victory) {
          this.lobby.status = 'finished';
        }
        this.broadcastSync();
      }
      this.scheduleNextTick();
    }, delay);
  }

  private sendToPlayer(playerId: string, payload: Record<string, unknown>) {
    if (playerId === this.hostPlayerId) {
      if (payload.type === 'ERROR') {
        this.callbacks.onError?.(String(payload.message || 'Hata'));
      } else if (payload.type === 'SAVE_CONFIRMED') {
        this.callbacks.onSaveConfirmed?.(String(payload.slotName || 'Kayıt'));
      }
      return;
    }
    const conn = this.conns.get(playerId);
    if (conn && conn.open) {
      conn.send(encodePacket(payload));
    }
  }

  private broadcastSync() {
    if (this.destroyed) return;
    const lobbyCopy = structuredClone(this.lobby);
    const stateCopy = this.state ? structuredClone(this.state) : null;
    this.callbacks.onSync?.(lobbyCopy, stateCopy);

    if (this.conns.size > 0) {
      const encoded = encodePacket({
        type: 'ROOM_SYNC',
        lobby: lobbyCopy,
        state: stateCopy,
      });
      for (const conn of this.conns.values()) {
        if (conn.open) {
          conn.send(encoded);
        }
      }
    }
  }

  disconnect(): void {
    this.destroyed = true;
    if (this.tickTimer !== null) {
      window.clearTimeout(this.tickTimer);
      this.tickTimer = null;
    }
    for (const conn of this.conns.values()) {
      try {
        conn.close();
      } catch {
        // ignore
      }
    }
    this.conns.clear();
    if (this.peer) {
      try {
        this.peer.destroy();
      } catch {
        // ignore
      }
      this.peer = null;
    }
    this.callbacks.onConnectionChange?.(false);
  }
}

export class P2PGuestController implements P2PClientTransport {
  readonly isP2P = true;
  readonly isP2PHost = false;

  private peer: Peer | null = null;
  private conn: DataConnection | null = null;
  private connectTimeout: number | null = null;
  private destroyed = false;
  private callbacks: TransportCallbacks;

  constructor(params: {
    roomCode: string;
    playerId: string;
    playerName: string;
    callbacks: TransportCallbacks;
  }) {
    this.callbacks = params.callbacks;
    const cleanCode = params.roomCode.trim().toUpperCase().replace(/^EC1939-/i, '');

    const peer = new Peer({
      config: { iceServers: ICE_SERVERS },
      debug: 0,
    });
    this.peer = peer;

    this.connectTimeout = window.setTimeout(() => {
      if (!this.destroyed && (!this.conn || !this.conn.open)) {
        this.callbacks.onError?.(
          `P2P odaya (${cleanCode}) ulaşılamadı. Kurucunun oyunu açık tuttuğundan ve kodun doğru olduğundan emin olun.`
        );
        this.callbacks.onConnectionChange?.(false);
      }
    }, 12_000);

    peer.on('open', () => {
      if (this.destroyed) return;
      const conn = peer.connect(`${PEER_PREFIX}${cleanCode}`, {
        reliable: true,
      });
      this.conn = conn;

      conn.on('open', () => {
        if (this.destroyed) return;
        if (this.connectTimeout !== null) {
          window.clearTimeout(this.connectTimeout);
          this.connectTimeout = null;
        }
        this.callbacks.onConnectionChange?.(true);
        conn.send(
          encodePacket({
            type: 'JOIN_ROOM',
            roomCode: cleanCode,
            playerId: params.playerId,
            playerName: params.playerName,
          })
        );
      });

      conn.on('data', (raw) => {
        if (this.destroyed) return;
        const msg = decodePacket(raw);
        if (!msg) return;
        if (msg.type === 'ROOM_SYNC') {
          this.callbacks.onSync?.(
            msg.lobby as RoomLobbyState,
            (msg.state as GameState | null) || null
          );
        } else if (msg.type === 'ERROR') {
          this.callbacks.onError?.(String(msg.message || 'Bağlantı hatası'));
        } else if (msg.type === 'SAVE_CONFIRMED') {
          this.callbacks.onSaveConfirmed?.(String(msg.slotName || 'Kayıt'));
        }
      });

      conn.on('close', () => {
        if (this.destroyed) return;
        this.callbacks.onConnectionChange?.(false);
        this.callbacks.onError?.('P2P kurucu ile bağlantı kesildi.');
      });

      conn.on('error', () => {
        if (this.destroyed) return;
        this.callbacks.onConnectionChange?.(false);
      });
    });

    peer.on('error', (err) => {
      if (this.destroyed) return;
      if (this.connectTimeout !== null) {
        window.clearTimeout(this.connectTimeout);
        this.connectTimeout = null;
      }
      if (err.type === 'peer-unavailable') {
        this.callbacks.onError?.(
          `P2P oda bulunamadı (${cleanCode}). Kurucunun lobi ekranında olduğundan emin olun.`
        );
      } else {
        this.callbacks.onError?.(
          `P2P bağlantı hatası (${err.type || 'ağ'}).`
        );
      }
      this.callbacks.onConnectionChange?.(false);
    });
  }

  sendAction(action: ClientAction): void {
    if (this.conn && this.conn.open) {
      this.conn.send(encodePacket({ type: 'ACTION', action }));
    }
  }

  disconnect(): void {
    this.destroyed = true;
    if (this.connectTimeout !== null) {
      window.clearTimeout(this.connectTimeout);
      this.connectTimeout = null;
    }
    if (this.conn) {
      try {
        this.conn.close();
      } catch {
        // ignore
      }
      this.conn = null;
    }
    if (this.peer) {
      try {
        this.peer.destroy();
      } catch {
        // ignore
      }
      this.peer = null;
    }
    this.callbacks.onConnectionChange?.(false);
  }
}
