import Phaser from 'phaser';
import type {
  Army,
  Battle,
  GameState,
  MapDataStatic,
  MapMode,
  MapProvinceStatic,
} from '../../shared/types.ts';
import { COUNTRIES } from '../../shared/data/countries.ts';
import { SCENARIOS } from '../../shared/data/scenarios.ts';
import {
  canEnterProvince,
  canPlayerSeeArmy,
  canPlayerSeeBattle,
  getArmyTotal,
  getRelation,
} from '../../shared/utils/gameHelpers.ts';

export interface MapCallbacks {
  onSelectProvince: (provinceId: string) => void;
  onRightClickProvince?: (provinceId: string) => void;
  onSelectArmy: (armyId: string) => void;
  onSelectBattle: (battleId: string) => void;
  onSelectSeaZone: (seaZoneId: string) => void;
  onTargetProvinceChosen: (provinceId: string) => void;
  onHoverProvince?: (provinceId: string | null) => void;
}

interface EffectBurst {
  x: number;
  y: number;
  age: number;
  maxAge: number;
  color: number;
  maxRadius: number;
}

interface CloudInstance {
  sprite: Phaser.GameObjects.Image;
  vx: number;
  vy: number;
}

function pointInPolygon(x: number, y: number, poly: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i][0], yi = poly[i][1];
    const xj = poly[j][0], yj = poly[j][1];
    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-9) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function hexToRgba(hex: string, alpha = 1): string {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16) || 100;
  const g = parseInt(clean.slice(2, 4), 16) || 116;
  const b = parseInt(clean.slice(4, 6), 16) || 139;
  return `rgba(${r},${g},${b},${alpha})`;
}

// Fast deterministic 2D noise for sculpted topographic relief hillshade
function hash2d(ix: number, iy: number): number {
  const n = Math.sin(ix * 127.1 + iy * 311.7) * 43758.5453123;
  return n - Math.floor(n);
}

function smoothNoise(x: number, y: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const u = fx * fx * (3 - 2 * fx);
  const v = fy * fy * (3 - 2 * fy);
  const a = hash2d(ix, iy);
  const b = hash2d(ix + 1, iy);
  const c = hash2d(ix, iy + 1);
  const d = hash2d(ix + 1, iy + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function fbm(x: number, y: number): number {
  let val = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < 4; i++) {
    val += amp * smoothNoise(x * freq, y * freq);
    freq *= 2.05;
    amp *= 0.5;
  }
  return val;
}

export class StrategyMapScene extends Phaser.Scene {
  private mapData!: MapDataStatic;
  private callbacks!: MapCallbacks;
  private gameState: GameState | null = null;
  private playerCountryId: string | null = null;
  private mapMode: MapMode = 'political';
  private selectedProvinceId: string | null = null;
  private hoveredProvinceId: string | null = null;
  private selectedArmyId: string | null = null;
  private targetingArmyId: string | null = null;
  private highlightOwnTargets = false;
  private lobbyScenarioId: '1939_alt' | '1939_hist' = '1939_alt';
  private isLobbyPan = true;

  private mapCanvasTex!: Phaser.Textures.CanvasTexture;
  private reliefCanvas!: HTMLCanvasElement;
  private mapImage!: Phaser.GameObjects.Image;
  private overlayGfx!: Phaser.GameObjects.Graphics;
  private arrowGfx!: Phaser.GameObjects.Graphics;
  private fxGfx!: Phaser.GameObjects.Graphics;
  private labelLayer!: Phaser.GameObjects.Container;
  private fleetLayer!: Phaser.GameObjects.Container;
  private armyLayer!: Phaser.GameObjects.Container;
  private battleLayer!: Phaser.GameObjects.Container;
  private floatingLayer!: Phaser.GameObjects.Container;
  private cloudLayer!: Phaser.GameObjects.Container;

  private provBBoxes: Map<string, { minX: number; minY: number; maxX: number; maxY: number }> = new Map();
  private provById: Map<string, MapProvinceStatic> = new Map();
  private cityLabels: Map<string, { dot: Phaser.GameObjects.Arc; text: Phaser.GameObjects.Text; isCap: boolean }> =
    new Map();

  private armyContainers: Map<string, Phaser.GameObjects.Container> = new Map();
  private armyVisualPos: Map<string, { x: number; y: number }> = new Map();
  private prevArmyTotals: Map<string, number> = new Map();
  private effectBursts: EffectBurst[] = [];
  private clouds: CloudInstance[] = [];
  private prevControllers: Map<string, string> = new Map();

  private isDragging = false;
  private dragStartX = 0;
  private dragStartY = 0;
  private camStartX = 0;
  private camStartY = 0;
  private dragDist = 0;
  private downButton = 0;
  private pulseTime = 0;
  private lastOwnersHash = '';
  private pressedKeys: Set<string> = new Set();

  constructor() {
    super({ key: 'StrategyMapScene' });
  }

  initData(mapData: MapDataStatic, callbacks: MapCallbacks) {
    this.mapData = mapData;
    this.callbacks = callbacks;
    this.provById = new Map(mapData.provinces.map((p) => [p.id, p]));
  }

  create() {
    const W = this.mapData.width;
    const H = this.mapData.height;

    this.game.canvas.oncontextmenu = (e) => e.preventDefault();

    for (const p of this.mapData.provinces) {
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (const poly of p.polygons) {
        for (const [x, y] of poly) {
          if (x < minX) minX = x;
          if (y < minY) minY = y;
          if (x > maxX) maxX = x;
          if (y > maxY) maxY = y;
        }
      }
      this.provBBoxes.set(p.id, { minX, minY, maxX, maxY });
    }

    // Build pre-computed topographic relief bump canvas (once!)
    this.buildReliefOverlayCanvas(W, H);

    // Rich deep cobalt ocean backdrop (like the Conquer the World WW2 map)
    const oceanGfx = this.add.graphics();
    oceanGfx.fillGradientStyle(0x1644a6, 0x184bb5, 0x0f2f7d, 0x0c2769, 1);
    oceanGfx.fillRect(-700, -700, W + 1400, H + 1400);

    // Subtle sea zone geometric sector lines & ocean grid
    oceanGfx.lineStyle(1, 0x60a5fa, 0.12);
    for (let x = -200; x <= W + 200; x += 150) {
      oceanGfx.lineBetween(x, -200, x, H + 200);
    }
    for (let y = -200; y <= H + 200; y += 150) {
      oceanGfx.lineBetween(-200, y, W + 200, y);
    }

    oceanGfx.lineStyle(1.4, 0x93c5fd, 0.16);
    const seaMap = new Map(this.mapData.seaZones.map((s) => [s.id, s]));
    for (const sz of this.mapData.seaZones) {
      for (const nbId of sz.neighbors) {
        const nb = seaMap.get(nbId);
        if (nb && sz.id < nb.id) {
          oceanGfx.lineBetween(sz.x, sz.y, nb.x, nb.y);
        }
      }
    }

    // Main CanvasTexture for landmasses, terrain hillshade, country labels, borders
    this.mapCanvasTex = this.textures.createCanvas('political-map', W, H)!;
    this.mapImage = this.add.image(0, 0, 'political-map').setOrigin(0, 0);

    this.overlayGfx = this.add.graphics();
    this.arrowGfx = this.add.graphics();
    this.fxGfx = this.add.graphics();
    this.labelLayer = this.add.container(0, 0);
    this.fleetLayer = this.add.container(0, 0);
    this.armyLayer = this.add.container(0, 0);
    this.battleLayer = this.add.container(0, 0);
    this.floatingLayer = this.add.container(0, 0);
    this.cloudLayer = this.add.container(0, 0);

    // Build atmospheric drifting clouds
    this.createAtmosphericClouds(W, H);

    // Sea zone labels
    for (const sz of this.mapData.seaZones) {
      const lbl = this.add
        .text(sz.x, sz.y, sz.name.toUpperCase(), {
          fontFamily: '"Plus Jakarta Sans", sans-serif',
          fontSize: '10px',
          color: '#bfdbfe',
          fontStyle: 'italic',
        })
        .setOrigin(0.5)
        .setAlpha(0.38);
      lbl.setInteractive({ useHandCursor: true });
      lbl.on('pointerdown', () => {
        if (this.dragDist < 6) this.callbacks.onSelectSeaZone(sz.id);
      });
      this.labelLayer.add(lbl);
    }

    // Province capital stars & city dots
    for (const p of this.mapData.provinces) {
      const dot = this.add.circle(p.x, p.y, p.isCapital ? 4.2 : 2.3, p.isCapital ? 0xfacc15 : 0xf1f5f9, 0.92);
      dot.setStrokeStyle(1.4, 0x090d16, 0.95);
      const txt = this.add
        .text(p.x, p.y + (p.isCapital ? 8 : 6), p.name, {
          fontFamily: '"Plus Jakarta Sans", sans-serif',
          fontSize: p.isCapital ? '10.5px' : '8.5px',
          fontStyle: p.isCapital ? 'bold' : 'normal',
          color: p.isCapital ? '#fef08a' : '#f1f5f9',
          stroke: '#090d16',
          strokeThickness: 3,
        })
        .setOrigin(0.5, 0);
      this.labelLayer.add([dot, txt]);
      this.cityLabels.set(p.id, { dot, text: txt, isCap: p.isCapital });
    }

    const cam = this.cameras.main;
    cam.setBounds(-260, -200, W + 520, H + 400);
    cam.centerOn(1050, 710);
    cam.setZoom(0.90);

    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      this.isDragging = true;
      this.dragStartX = pointer.x;
      this.dragStartY = pointer.y;
      this.camStartX = cam.scrollX;
      this.camStartY = cam.scrollY;
      this.dragDist = 0;
      this.downButton = pointer.button;
    });

    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      if (this.isDragging && pointer.isDown && this.downButton !== 2) {
        const dx = pointer.x - this.dragStartX;
        const dy = pointer.y - this.dragStartY;
        this.dragDist = Math.hypot(dx, dy);
        cam.scrollX = this.camStartX - dx / cam.zoom;
        cam.scrollY = this.camStartY - dy / cam.zoom;
      } else if (!this.isLobbyPan) {
        const worldPt = cam.getWorldPoint(pointer.x, pointer.y);
        const hit = this.findProvinceAt(worldPt.x, worldPt.y);
        if (hit !== this.hoveredProvinceId) {
          this.hoveredProvinceId = hit;
          this.callbacks.onHoverProvince?.(hit);
          this.redrawOverlays();
        }
      }
    });

    this.input.on('pointerup', (pointer: Phaser.Input.Pointer) => {
      const wasClick = this.dragDist < 8;
      const btn = this.downButton;
      this.isDragging = false;
      if (!wasClick) return;

      const worldPt = cam.getWorldPoint(pointer.x, pointer.y);
      const hit = this.findProvinceAt(worldPt.x, worldPt.y);
      if (!hit) return;

      if (btn === 2) {
        this.callbacks.onRightClickProvince?.(hit);
        return;
      }

      if (this.targetingArmyId) {
        this.callbacks.onTargetProvinceChosen(hit);
      } else {
        this.callbacks.onSelectProvince(hit);
      }
    });

    this.input.on(
      'wheel',
      (
        pointer: Phaser.Input.Pointer,
        _currentlyOver: unknown,
        _deltaX: number,
        deltaY: number
      ) => {
        const worldBefore = cam.getWorldPoint(pointer.x, pointer.y);
        const factor = deltaY > 0 ? 0.88 : 1.13;
        const newZoom = Phaser.Math.Clamp(cam.zoom * factor, 0.45, 3.2);
        cam.setZoom(newZoom);
        const worldAfter = cam.getWorldPoint(pointer.x, pointer.y);
        cam.scrollX += worldBefore.x - worldAfter.x;
        cam.scrollY += worldBefore.y - worldAfter.y;
        this.updateLabelVisibility();
      }
    );

    const handleKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (
        e.code === 'KeyW' ||
        e.code === 'KeyA' ||
        e.code === 'KeyS' ||
        e.code === 'KeyD' ||
        e.code === 'ArrowUp' ||
        e.code === 'ArrowDown' ||
        e.code === 'ArrowLeft' ||
        e.code === 'ArrowRight'
      ) {
        this.pressedKeys.add(e.code);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      this.pressedKeys.delete(e.code);
    };
    const handleBlur = () => {
      this.pressedKeys.clear();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);

    const cleanupKeys = () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', handleBlur);
      this.pressedKeys.clear();
    };
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, cleanupKeys);
    this.events.once(Phaser.Scenes.Events.DESTROY, cleanupKeys);

    this.lastOwnersHash = this.computeOwnerHash();
    this.redrawMapTexture();
    this.redrawOverlays();
    this.redrawArrowsAndFrontlines();
    this.syncArmyAndBattleObjects();
    this.updateLabelVisibility();
  }

  private buildReliefOverlayCanvas(W: number, H: number) {
    // Scaled relief heightfield (4x smaller -> super fast creation, smooth bilinear stretch)
    const sw = Math.ceil(W / 3);
    const sh = Math.ceil(H / 3);
    const canvas = document.createElement('canvas');
    canvas.width = sw;
    canvas.height = sh;
    const ctx = canvas.getContext('2d')!;
    const img = ctx.createImageData(sw, sh);
    const data = img.data;

    // Sample NW-SE directional hillshade using fbm noise
    for (let y = 0; y < sh; y++) {
      for (let x = 0; x < sw; x++) {
        const nx = x * 0.045;
        const ny = y * 0.045;
        const h0 = fbm(nx, ny);
        const hx = fbm(nx + 0.08, ny);
        const hy = fbm(nx, ny + 0.08);
        const slope = (h0 - hx) * 4.5 + (h0 - hy) * 4.5;
        // Neutral center is ~128 for soft-light/overlay look
        const shade = Math.max(40, Math.min(245, Math.round(135 + slope * 115 + (h0 - 0.5) * 40)));
        const idx = (y * sw + x) * 4;
        data[idx] = shade;
        data[idx + 1] = shade;
        data[idx + 2] = Math.min(255, shade + 6);
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    this.reliefCanvas = canvas;
  }

  private createAtmosphericClouds(W: number, H: number) {
    const texKey = 'cloud-puff';
    if (!this.textures.exists(texKey)) {
      const cTex = this.textures.createCanvas(texKey, 260, 140)!;
      const ctx = cTex.getContext();
      const puffs = [
        [80, 75, 55],
        [130, 58, 65],
        [185, 76, 50],
        [120, 88, 52],
      ];
      for (const [cx, cy, r] of puffs) {
        const grad = ctx.createRadialGradient(cx, cy, 4, cx, cy, r);
        grad.addColorStop(0, 'rgba(255, 255, 255, 0.34)');
        grad.addColorStop(0.6, 'rgba(226, 232, 240, 0.14)');
        grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();
      }
      cTex.refresh();
    }

    for (let i = 0; i < 12; i++) {
      const img = this.add.image(
        (i * 217) % (W + 300) - 150,
        (i * 151) % (H + 100) - 50,
        texKey
      );
      img.setScale(1.4 + (i % 4) * 0.65);
      img.setAlpha(0.11 + (i % 3) * 0.045);
      this.cloudLayer.add(img);
      this.clouds.push({
        sprite: img,
        vx: 4 + (i % 5) * 2.2,
        vy: -0.6 + (i % 3) * 0.5,
      });
    }
  }

  spawnProvincePing(provinceId: string, color = 0x38bdf8, maxRadius = 46) {
    const p = this.provById.get(provinceId);
    if (!p) return;
    this.effectBursts.push({
      x: p.x,
      y: p.y,
      age: 0,
      maxAge: 0.75,
      color,
      maxRadius,
    });
  }

  private spawnFloatingCasualty(x: number, y: number, lossK: number) {
    if (!this.floatingLayer || lossK <= 0) return;
    const txt = this.add
      .text(x + (Math.random() - 0.5) * 14, y - 14, `-${lossK}K`, {
        fontFamily: '"JetBrains Mono", monospace',
        fontSize: '12px',
        fontStyle: 'bold',
        color: '#fca5a5',
        stroke: '#090d16',
        strokeThickness: 3,
      })
      .setOrigin(0.5);
    this.floatingLayer.add(txt);
    this.tweens.add({
      targets: txt,
      y: txt.y - 26,
      alpha: 0,
      duration: 950,
      ease: 'Cubic.easeOut',
      onComplete: () => txt.destroy(),
    });
  }

  update(_time: number, delta: number) {
    const dtSec = Math.min(0.1, delta / 1000);
    this.pulseTime += dtSec * 3.2;

    const cam = this.cameras.main;
    let panX = 0;
    let panY = 0;
    if (this.pressedKeys.has('KeyA') || this.pressedKeys.has('ArrowLeft')) panX -= 1;
    if (this.pressedKeys.has('KeyD') || this.pressedKeys.has('ArrowRight')) panX += 1;
    if (this.pressedKeys.has('KeyW') || this.pressedKeys.has('ArrowUp')) panY -= 1;
    if (this.pressedKeys.has('KeyS') || this.pressedKeys.has('ArrowDown')) panY += 1;

    if (panX !== 0 || panY !== 0) {
      const mag = Math.hypot(panX, panY) || 1;
      const panSpeed = (680 / Math.max(0.45, cam.zoom)) * dtSec;
      cam.scrollX += (panX / mag) * panSpeed;
      cam.scrollY += (panY / mag) * panSpeed;
    } else if (this.isLobbyPan && !this.isDragging) {
      cam.scrollX += Math.sin(this.pulseTime * 0.12) * 0.3;
      cam.scrollY += Math.cos(this.pulseTime * 0.09) * 0.16;
    }

    // Drift atmospheric clouds gently across the theater
    const W = this.mapData.width;
    const H = this.mapData.height;
    for (const c of this.clouds) {
      c.sprite.x += c.vx * dtSec;
      c.sprite.y += c.vy * dtSec;
      if (c.sprite.x > W + 350) c.sprite.x = -320;
      if (c.sprite.y > H + 200) c.sprite.y = -150;
      if (c.sprite.y < -200) c.sprite.y = H + 150;
    }

    // Smoothly interpolate & bob moving armies at 60fps
    if (this.gameState) {
      this.animateArmiesAndBattles(dtSec);
    }

    // Animated arrows & effect bursts (capture flashes, command pings, battle sparks)
    this.redrawArrowsAndFrontlines();
    this.updateEffectBursts(dtSec);
  }

  private animateArmiesAndBattles(dtSec: number) {
    const gs = this.gameState;
    if (!gs) return;
    const lerpSpeed = Math.min(1, dtSec * 7.5);

    // Group stationary visible armies so multiple armies in same city offset neatly
    const byProv: Record<string, Army[]> = {};
    for (const army of Object.values(gs.armies)) {
      if (getArmyTotal(army.units) <= 0) continue;
      if (!canPlayerSeeArmy(gs, this.mapData, this.playerCountryId, army)) continue;
      if (!byProv[army.provinceId]) byProv[army.provinceId] = [];
      byProv[army.provinceId].push(army);
    }

    for (const [provId, list] of Object.entries(byProv)) {
      const mp = this.provById.get(provId);
      if (!mp) continue;

      list.forEach((army, idx) => {
        let targetX = mp.x;
        let targetY = mp.y - 10;
        let clashOffsetX = 0;
        let clashOffsetY = 0;

        if (army.inBattleId && gs.battles[army.inBattleId]) {
          const battle = gs.battles[army.inBattleId];
          const fromP = this.provById.get(battle.fromProvinceId);
          const toP = this.provById.get(battle.provinceId);
          if (fromP && toP) {
            const dx = toP.x - fromP.x;
            const dy = toP.y - fromP.y;
            const len = Math.max(1, Math.hypot(dx, dy));
            const ux = dx / len;
            const uy = dy / len;
            const px = -uy;
            const py = ux;
            const isAttacker = army.countryId === battle.attackerCountryId;
            const sideSign = isAttacker ? -1 : 1;
            const spread = (idx - (list.length - 1) / 2) * 16;

            // Place opposing armies directly across a frontline clash zone and lunge rhythmically toward each other
            targetX = toP.x + sideSign * ux * 24 + px * spread;
            targetY = toP.y + sideSign * uy * 24 + py * spread - 8;

            const strikeWave = Math.pow(
              Math.max(0, Math.sin(this.pulseTime * 3.1 + (isAttacker ? 0 : Math.PI) + idx * 0.5)),
              4
            );
            const lungeDir = isAttacker ? 1 : -1;
            clashOffsetX = lungeDir * ux * strikeWave * 10 + (Math.random() - 0.5) * 1.1;
            clashOffsetY = lungeDir * uy * strikeWave * 10 + (Math.random() - 0.5) * 1.1;
          }
        } else if (army.path.length > 0 && army.moveProgress > 0) {
          const nextMp = this.provById.get(army.path[0]);
          if (nextMp) {
            const t = Math.min(0.92, army.moveProgress / 100);
            targetX = mp.x + (nextMp.x - mp.x) * t;
            targetY = mp.y + (nextMp.y - mp.y) * t - 10;
          }
        } else if (list.length > 1) {
          const angle = (idx / list.length) * Math.PI * 2;
          targetX = mp.x + Math.cos(angle) * 20;
          targetY = mp.y + Math.sin(angle) * 20 - 10;
        }

        const cur = this.armyVisualPos.get(army.id) || { x: targetX, y: targetY };
        cur.x += (targetX - cur.x) * lerpSpeed;
        cur.y += (targetY - cur.y) * lerpSpeed;
        this.armyVisualPos.set(army.id, cur);

        const cont = this.armyContainers.get(army.id);
        if (cont) {
          const bob = army.path.length > 0 && !army.inBattleId ? Math.sin(this.pulseTime * 2.6 + idx) * 2 : 0;
          cont.setPosition(cur.x + clashOffsetX, cur.y + clashOffsetY + bob);
        }
      });
    }
  }

  private updateEffectBursts(dtSec: number) {
    this.fxGfx.clear();

    // Dynamic WW2 Frontline Clash Animations: tracer fire, artillery shells, shifting front line & muzzle bursts
    if (this.gameState) {
      for (const battle of Object.values(this.gameState.battles)) {
        if (!canPlayerSeeBattle(this.gameState, this.mapData, this.playerCountryId, battle)) continue;
        const from = this.provById.get(battle.fromProvinceId);
        const to = this.provById.get(battle.provinceId);
        if (!to) continue;

        const dx = from ? to.x - from.x : 1;
        const dy = from ? to.y - from.y : 0;
        const len = Math.max(1, Math.hypot(dx, dy));
        const ux = dx / len;
        const uy = dy / len;
        const px = -uy;
        const py = ux;

        // 1. Contested frontline bar shifting dynamically with battle.progress (0..100)
        const pushFrac = (battle.progress - 50) / 100; // -0.5 .. +0.5
        const lineCx = to.x + ux * (pushFrac * 18);
        const lineCy = to.y + uy * (pushFrac * 18) - 6;

        this.fxGfx.lineStyle(4, 0xf97316, 0.55);
        this.fxGfx.lineBetween(lineCx - px * 20, lineCy - py * 20, lineCx + px * 20, lineCy + py * 20);
        this.fxGfx.lineStyle(1.8, 0xfef08a, 0.95);
        this.fxGfx.lineBetween(lineCx - px * 17, lineCy - py * 17, lineCx + px * 17, lineCy + py * 17);

        // 2. Opposing gunfire tracer rounds crossing between attacker and defender fronts
        const atkBaseX = to.x - ux * 24;
        const atkBaseY = to.y - uy * 24 - 6;
        const defBaseX = to.x + ux * 20;
        const defBaseY = to.y + uy * 20 - 6;

        for (let r = 0; r < 3; r++) {
          const lateral = (r - 1) * 9;
          const phaseA = (this.pulseTime * 2.1 + r * 0.34) % 1;
          const phaseD = (this.pulseTime * 2.1 + r * 0.34 + 0.5) % 1;

          // Attacker -> Defender tracer
          const ax0 = atkBaseX + px * lateral;
          const ay0 = atkBaseY + py * lateral;
          const ax1 = defBaseX + px * lateral;
          const ay1 = defBaseY + py * lateral;
          const txA = ax0 + (ax1 - ax0) * phaseA;
          const tyA = ay0 + (ay1 - ay0) * phaseA;
          this.fxGfx.lineStyle(2.2, 0xfef08a, 0.95);
          this.fxGfx.lineBetween(txA - ux * 6, tyA - uy * 6, txA, tyA);
          if (phaseA > 0.85) {
            this.fxGfx.fillStyle(0xf97316, 0.92);
            this.fxGfx.fillCircle(ax1, ay1, 4.2);
          }

          // Defender -> Attacker tracer
          const txD = ax1 + (ax0 - ax1) * phaseD;
          const tyD = ay1 + (ay0 - ay1) * phaseD;
          this.fxGfx.lineStyle(2.0, 0x38bdf8, 0.9);
          this.fxGfx.lineBetween(txD + ux * 6, tyD + uy * 6, txD, tyD);
          if (phaseD > 0.85) {
            this.fxGfx.fillStyle(0xef4444, 0.92);
            this.fxGfx.fillCircle(ax0, ay0, 4.0);
          }
        }

        // 3. Parabolic artillery shell arc + shockwave impact ring
        const shellT = (this.pulseTime * 0.85 + battle.startDay * 0.3) % 1;
        const sx = atkBaseX + (defBaseX - atkBaseX) * shellT;
        const sy = atkBaseY + (defBaseY - atkBaseY) * shellT - Math.sin(shellT * Math.PI) * 18;
        this.fxGfx.fillStyle(0xfbbf24, 0.95);
        this.fxGfx.fillCircle(sx, sy, 2.5);

        const blastPhase = (this.pulseTime * 1.6 + battle.startDay) % 1;
        const ringR = 8 + blastPhase * 22;
        this.fxGfx.lineStyle(2.2, 0xf97316, (1 - blastPhase) * 0.85);
        this.fxGfx.strokeCircle(lineCx, lineCy, ringR);
      }
    }

    for (let i = this.effectBursts.length - 1; i >= 0; i--) {
      const b = this.effectBursts[i];
      b.age += dtSec;
      if (b.age >= b.maxAge) {
        this.effectBursts.splice(i, 1);
        continue;
      }
      const p = b.age / b.maxAge;
      const radius = 8 + p * b.maxRadius;
      const alpha = (1 - p) * 0.9;
      this.fxGfx.lineStyle(3.2 * (1 - p) + 1, b.color, alpha);
      this.fxGfx.strokeCircle(b.x, b.y, radius);
      this.fxGfx.fillStyle(b.color, alpha * 0.16);
      this.fxGfx.fillCircle(b.x, b.y, radius * 0.65);
    }
  }

  syncState(params: {
    gameState: GameState | null;
    playerCountryId: string | null;
    mapMode: MapMode;
    selectedProvinceId: string | null;
    selectedArmyId: string | null;
    targetingArmyId: string | null;
    highlightOwnTargets?: boolean;
    lobbyScenarioId: '1939_alt' | '1939_hist';
    isLobbyPan: boolean;
  }) {
    const modeChanged = this.mapMode !== params.mapMode;
    const scenarioChanged = this.lobbyScenarioId !== params.lobbyScenarioId;
    const playerChanged = this.playerCountryId !== params.playerCountryId;

    // Detect newly conquered provinces & casualty drops during battle!
    if (params.gameState) {
      for (const p of Object.values(params.gameState.provinces)) {
        const prev = this.prevControllers.get(p.id);
        if (prev && prev !== p.controllerId) {
          const hex = COUNTRIES[p.controllerId]?.color || '#facc15';
          const colorNum = parseInt(hex.replace('#', ''), 16) || 0xfacc15;
          this.spawnProvincePing(p.id, colorNum, 55);
        }
        this.prevControllers.set(p.id, p.controllerId);
      }

      for (const army of Object.values(params.gameState.armies)) {
        const curTotal = getArmyTotal(army.units);
        const prevTotal = this.prevArmyTotals.get(army.id);
        if (
          prevTotal !== undefined &&
          curTotal < prevTotal &&
          army.inBattleId &&
          canPlayerSeeArmy(params.gameState, this.mapData, params.playerCountryId, army)
        ) {
          const pos = this.armyVisualPos.get(army.id) || this.provById.get(army.provinceId);
          if (pos) this.spawnFloatingCasualty(pos.x, pos.y, prevTotal - curTotal);
        }
        this.prevArmyTotals.set(army.id, curTotal);
      }
    } else {
      this.prevControllers.clear();
      this.prevArmyTotals.clear();
    }

    this.gameState = params.gameState;
    this.playerCountryId = params.playerCountryId;
    this.mapMode = params.mapMode;
    this.selectedProvinceId = params.selectedProvinceId;
    this.selectedArmyId = params.selectedArmyId;
    this.targetingArmyId = params.targetingArmyId;
    this.highlightOwnTargets = Boolean(params.highlightOwnTargets || params.targetingArmyId);
    this.lobbyScenarioId = params.lobbyScenarioId;
    this.isLobbyPan = params.isLobbyPan;

    if (!this.mapCanvasTex) return;

    const ownerHash = this.computeOwnerHash();
    if (ownerHash !== this.lastOwnersHash || modeChanged || scenarioChanged || playerChanged) {
      this.lastOwnersHash = ownerHash;
      this.redrawMapTexture();
    }

    this.redrawOverlays();
    this.redrawArrowsAndFrontlines();
    this.syncArmyAndBattleObjects();
  }

  zoomStep(mult: number) {
    if (!this.cameras?.main) return;
    const cam = this.cameras.main;
    cam.setZoom(Phaser.Math.Clamp(cam.zoom * mult, 0.45, 3.2));
    this.updateLabelVisibility();
  }

  focusProvince(provinceId: string) {
    const p = this.provById.get(provinceId);
    if (!p || !this.cameras?.main) return;
    this.cameras.main.pan(p.x, p.y, 350, 'Cubic.easeOut');
  }

  resetCamera() {
    if (!this.cameras?.main) return;
    this.cameras.main.pan(1050, 710, 350, 'Cubic.easeOut');
    this.cameras.main.zoomTo(0.90, 350);
    this.updateLabelVisibility();
  }

  private updateLabelVisibility() {
    const zoom = this.cameras.main.zoom;
    for (const item of this.cityLabels.values()) {
      item.text.setVisible(item.isCap ? zoom >= 0.72 : zoom >= 1.32);
      item.dot.setVisible(item.isCap || zoom >= 0.92);
    }
  }

  private computeOwnerHash(): string {
    if (!this.gameState) return `lobby_${this.lobbyScenarioId}_${this.mapMode}`;
    return Object.values(this.gameState.provinces)
      .map((p) => `${p.id}:${p.controllerId}:${p.supplyLevel}:${p.nuked ? 1 : 0}`)
      .join('|');
  }

  private getProvinceOwner(p: MapProvinceStatic): string {
    if (this.gameState?.provinces[p.id]) {
      return this.gameState.provinces[p.id].controllerId;
    }
    const scen = SCENARIOS[this.lobbyScenarioId];
    return scen?.provinceOwnerOverrides[p.id] || p.countryId;
  }

  private getProvinceFillColor(p: MapProvinceStatic): string {
    const ownerId = this.getProvinceOwner(p);
    if (this.mapMode === 'terrain') {
      const tColors: Record<string, string> = {
        plains: '#65a30d',
        forest: '#15803d',
        hills: '#a16207',
        mountain: '#64748b',
        desert: '#d97706',
        urban: '#475569',
      };
      return tColors[p.terrain] || '#64748b';
    }

    if (this.mapMode === 'supply' && this.gameState?.provinces[p.id]) {
      const sup = this.gameState.provinces[p.id].supplyLevel;
      if (sup >= 85) return '#16a34a';
      if (sup >= 65) return '#ca8a04';
      return '#dc2626';
    }

    if (this.mapMode === 'diplomacy' && this.gameState && this.playerCountryId) {
      if (ownerId === this.playerCountryId) return '#16a34a';
      const rel = getRelation(this.gameState.relations, this.playerCountryId, ownerId);
      if (rel.atWar) return '#dc2626';
      if (rel.allied) return '#0284c7';
      if (rel.nonAggression) return '#0d9488';
      return '#475569';
    }

    return COUNTRIES[ownerId]?.color || '#64748b';
  }

  private redrawMapTexture() {
    const ctx = this.mapCanvasTex.getContext();
    const W = this.mapData.width;
    const H = this.mapData.height;
    ctx.clearRect(0, 0, W, H);

    // 1. Coastal shallow-water halo pass behind landmasses
    ctx.save();
    ctx.shadowColor = 'rgba(56, 189, 248, 0.42)';
    ctx.shadowBlur = 12;
    ctx.fillStyle = '#0f172a';
    for (const p of this.mapData.provinces) {
      for (const poly of p.polygons) {
        if (poly.length < 3) continue;
        ctx.beginPath();
        ctx.moveTo(poly[0][0], poly[0][1]);
        for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0], poly[i][1]);
        ctx.closePath();
        ctx.fill();
      }
    }
    ctx.restore();

    // 2. Sculpted terrain relief base masked onto landmasses
    ctx.save();
    ctx.beginPath();
    for (const p of this.mapData.provinces) {
      for (const poly of p.polygons) {
        if (poly.length < 3) continue;
        ctx.moveTo(poly[0][0], poly[0][1]);
        for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0], poly[i][1]);
        ctx.closePath();
      }
    }
    ctx.clip();
    ctx.drawImage(this.reliefCanvas, 0, 0, W, H);
    ctx.restore();

    // 3. Tint terrain relief with translucent rich political/terrain colors + subtle terrain grain
    for (const p of this.mapData.provinces) {
      const baseColor = this.getProvinceFillColor(p);
      const nuked = this.gameState?.provinces[p.id]?.nuked;
      const fillAlpha = this.mapMode === 'political' ? 0.72 : 0.78;
      ctx.fillStyle = nuked ? 'rgba(63,63,70,0.88)' : hexToRgba(baseColor, fillAlpha);
      ctx.strokeStyle = 'rgba(9, 13, 22, 0.36)';
      ctx.lineWidth = 0.9;

      for (const poly of p.polygons) {
        if (poly.length < 3) continue;
        ctx.beginPath();
        ctx.moveTo(poly[0][0], poly[0][1]);
        for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0], poly[i][1]);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
    }

    // 4. Crisp international borders between different owner countries
    ctx.save();
    ctx.strokeStyle = 'rgba(9, 13, 22, 0.85)';
    ctx.lineWidth = 2.0;
    for (const p of this.mapData.provinces) {
      const ownerA = this.getProvinceOwner(p);
      const hasForeignNeighbor = p.neighbors.some((nbId) => {
        const nb = this.provById.get(nbId);
        return nb && this.getProvinceOwner(nb) !== ownerA;
      });
      const isCoast = p.isPort || !hasForeignNeighbor;
      if (!hasForeignNeighbor && !isCoast) continue;
      for (const poly of p.polygons) {
        if (poly.length < 3) continue;
        ctx.beginPath();
        ctx.moveTo(poly[0][0], poly[0][1]);
        for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0], poly[i][1]);
        ctx.closePath();
        ctx.stroke();
      }
    }
    ctx.restore();

    // 5. Large stylized country names drawn across territories (like screenshot!)
    this.drawCountryWatermarks(ctx);

    this.mapCanvasTex.refresh();
  }

  private drawCountryWatermarks(ctx: CanvasRenderingContext2D) {
    // Group provinces by contiguous territory cluster per country so islands/colonies do not pull the label into the ocean
    const visited = new Set<string>();
    interface CountryCluster {
      countryId: string;
      provinces: MapProvinceStatic[];
      sumX: number;
      sumY: number;
      minX: number;
      maxX: number;
      minY: number;
      maxY: number;
      area: number;
    }

    const clustersByCountry: Record<string, CountryCluster[]> = {};

    for (const p of this.mapData.provinces) {
      if (visited.has(p.id)) continue;
      const ownerId = this.getProvinceOwner(p);
      const queue: MapProvinceStatic[] = [p];
      visited.add(p.id);
      const compProvs: MapProvinceStatic[] = [];
      let sumX = 0;
      let sumY = 0;
      let minX = Infinity;
      let maxX = -Infinity;
      let minY = Infinity;
      let maxY = -Infinity;

      while (queue.length > 0) {
        const cur = queue.shift()!;
        compProvs.push(cur);
        sumX += cur.x;
        sumY += cur.y;
        const bb = this.provBBoxes.get(cur.id);
        if (bb) {
          minX = Math.min(minX, bb.minX);
          maxX = Math.max(maxX, bb.maxX);
          minY = Math.min(minY, bb.minY);
          maxY = Math.max(maxY, bb.maxY);
        }
        for (const nbId of cur.neighbors) {
          if (visited.has(nbId)) continue;
          const nb = this.provById.get(nbId);
          if (nb && this.getProvinceOwner(nb) === ownerId) {
            visited.add(nbId);
            queue.push(nb);
          }
        }
      }

      const spanW = Math.max(12, maxX - minX);
      const spanH = Math.max(12, maxY - minY);
      const cluster: CountryCluster = {
        countryId: ownerId,
        provinces: compProvs,
        sumX,
        sumY,
        minX,
        maxX,
        minY,
        maxY,
        area: spanW * spanH,
      };
      if (!clustersByCountry[ownerId]) clustersByCountry[ownerId] = [];
      clustersByCountry[ownerId].push(cluster);
    }

    // Pick primary contiguous core (plus very large secondary theaters) and sort largest first
    const targetClusters: CountryCluster[] = [];
    for (const list of Object.values(clustersByCountry)) {
      list.sort((a, b) => b.provinces.length - a.provinces.length || b.area - a.area);
      list.forEach((c, idx) => {
        if (idx === 0 || (c.provinces.length >= 4 && c.area >= 9000)) {
          targetClusters.push(c);
        }
      });
    }
    targetClusters.sort((a, b) => b.area - a.area);

    const placedBoxes: Array<{ x1: number; y1: number; x2: number; y2: number }> = [];
    const collides = (x1: number, y1: number, x2: number, y2: number) =>
      placedBoxes.some((b) => !(x2 < b.x1 || x1 > b.x2 || y2 < b.y1 || y1 > b.y2));

    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    for (const c of targetClusters) {
      const country = COUNTRIES[c.countryId];
      if (!country) continue;

      const spanW = Math.max(20, c.maxX - c.minX);
      const spanH = Math.max(18, c.maxY - c.minY);
      if (spanW < 36 && c.provinces.length === 1) continue;

      let cx = c.sumX / c.provinces.length;
      let cy = c.sumY / c.provinces.length;

      // Keep anchor inside actual land polygon if concave coastline places mean in the water
      const insideAny = c.provinces.some((pr) =>
        pr.polygons.some((poly) => pointInPolygon(cx, cy, poly))
      );
      if (!insideAny) {
        let bestProv = c.provinces[0];
        let bestDist = Infinity;
        for (const pr of c.provinces) {
          const d = Math.hypot(pr.x - cx, pr.y - cy);
          if (d < bestDist) {
            bestDist = d;
            bestProv = pr;
          }
        }
        cx = bestProv.x;
        cy = bestProv.y;
      }

      const rawName = country.name;
      let fontSize = Math.min(34, Math.max(8, Math.floor(Math.min(spanW * 0.65 / Math.max(4, rawName.length * 0.56), spanH * 0.42))));

      const measureForSize = (fs: number) => {
        ctx.font = `900 ${fs}px Georgia, "Times New Roman", serif`;
        return ctx.measureText(rawName).width;
      };

      let textW = measureForSize(fontSize);
      while (textW > spanW * 0.92 && fontSize > 8) {
        fontSize -= 1;
        textW = measureForSize(fontSize);
      }

      if (textW > spanW * 1.4 && spanW < 70) continue;

      // Try horizontal placement with small vertical nudges to eliminate any bounding-box overlap
      let placed = false;
      const trySizes = fontSize > 8 ? [fontSize, Math.max(8, fontSize - 2)] : [8];
      const yOffsets = [0, -12, 12, -22, 22];

      for (const fs of trySizes) {
        if (placed) break;
        const w = measureForSize(fs);
        const h = fs + 4;
        for (const dy of yOffsets) {
          const py = cy + dy;
          if (py - h / 2 < c.minY - 6 || py + h / 2 > c.maxY + 6) continue;
          const x1 = cx - w / 2 - 4;
          const y1 = py - h / 2 - 3;
          const x2 = cx + w / 2 + 4;
          const y2 = py + h / 2 + 3;
          if (!collides(x1, y1, x2, y2)) {
            ctx.font = `900 ${fs}px Georgia, "Times New Roman", serif`;
            ctx.lineJoin = 'round';
            ctx.lineWidth = Math.max(2.0, fs * 0.15);
            ctx.strokeStyle = 'rgba(9, 13, 22, 0.86)';
            ctx.fillStyle = 'rgba(248, 250, 252, 0.92)';
            ctx.strokeText(rawName, cx, py);
            ctx.fillText(rawName, cx, py);
            placedBoxes.push({ x1, y1, x2, y2 });
            placed = true;
            break;
          }
        }
      }
    }
    ctx.restore();
  }

  private redrawOverlays() {
    this.overlayGfx.clear();

    const drawHighlight = (provId: string, color: number, width: number, fillAlpha = 0) => {
      const p = this.provById.get(provId);
      if (!p) return;
      if (fillAlpha > 0) this.overlayGfx.fillStyle(color, fillAlpha);
      this.overlayGfx.lineStyle(width, color, 0.96);
      for (const poly of p.polygons) {
        if (poly.length < 3) continue;
        this.overlayGfx.beginPath();
        this.overlayGfx.moveTo(poly[0][0], poly[0][1]);
        for (let i = 1; i < poly.length; i++) this.overlayGfx.lineTo(poly[i][0], poly[i][1]);
        this.overlayGfx.closePath();
        if (fillAlpha > 0) this.overlayGfx.fillPath();
        this.overlayGfx.strokePath();
      }
    };

    // Highlight valid target / own / enemy territories whenever an own army is armed OR selected/targeting!
    const armedArmyId = this.targetingArmyId || this.selectedArmyId;
    if (armedArmyId && this.gameState && this.playerCountryId) {
      const army = this.gameState.armies[armedArmyId];
      if (army && army.countryId === this.playerCountryId) {
        for (const p of this.mapData.provinces) {
          if (p.id === army.provinceId) continue;
          const owner = this.gameState.provinces[p.id]?.controllerId;
          if (!owner) continue;
          const rel = getRelation(this.gameState.relations, army.countryId, owner);
          if (owner !== army.countryId && rel.atWar) {
            drawHighlight(p.id, 0xef4444, 1.8, 0.22);
          } else if (
            (this.targetingArmyId || this.highlightOwnTargets) &&
            canEnterProvince(this.gameState, army.countryId, p.id)
          ) {
            drawHighlight(p.id, 0x38bdf8, 1.4, 0.13);
          }
        }
      }
    }

    // Highlight player's chosen Ordu Çıkış Şehri (recruitProvinceId) on map
    if (this.gameState && this.playerCountryId) {
      const myCountry = this.gameState.countries[this.playerCountryId];
      const recruitId =
        myCountry?.recruitProvinceId &&
        this.gameState.provinces[myCountry.recruitProvinceId]?.controllerId === this.playerCountryId
          ? myCountry.recruitProvinceId
          : null;
      if (recruitId) {
        const rp = this.provById.get(recruitId);
        if (rp) {
          this.overlayGfx.lineStyle(2.2, 0x10b981, 0.95);
          this.overlayGfx.strokeCircle(rp.x, rp.y, 10.5);
          this.overlayGfx.fillStyle(0x10b981, 0.95);
          this.overlayGfx.fillTriangle(rp.x + 1, rp.y - 16, rp.x + 10, rp.y - 13, rp.x + 1, rp.y - 10);
          this.overlayGfx.lineStyle(1.8, 0xfef08a, 1);
          this.overlayGfx.lineBetween(rp.x + 1, rp.y - 17, rp.x + 1, rp.y - 4);
        }
      }
    }

    if (this.hoveredProvinceId && this.hoveredProvinceId !== this.selectedProvinceId) {
      drawHighlight(this.hoveredProvinceId, 0xf8fafc, 2.0, 0.13);
    }

    if (this.selectedProvinceId) {
      drawHighlight(this.selectedProvinceId, 0xfacc15, 2.8, 0.2);
    }
  }

  private redrawArrowsAndFrontlines() {
    this.arrowGfx.clear();
    if (!this.gameState) return;

    // Animated marching routes (respect border-neighbor visibility fog of war)
    for (const army of Object.values(this.gameState.armies)) {
      if (army.path.length === 0) continue;
      if (!canPlayerSeeArmy(this.gameState, this.mapData, this.playerCountryId, army)) continue;
      const start = this.provById.get(army.provinceId);
      if (!start) continue;

      const vis = this.armyVisualPos.get(army.id) || { x: start.x, y: start.y };
      const isMine = army.countryId === this.playerCountryId;
      const lastTarget = this.provById.get(army.path[army.path.length - 1]);
      const targetOwner = lastTarget ? this.gameState.provinces[lastTarget.id]?.controllerId : null;
      const isAttack =
        targetOwner &&
        targetOwner !== army.countryId &&
        getRelation(this.gameState.relations, army.countryId, targetOwner).atWar;

      const color = isAttack ? 0xef4444 : isMine ? 0x38bdf8 : 0xe2e8f0;
      this.arrowGfx.lineStyle(isMine ? 3.5 : 2.2, color, isMine ? 0.92 : 0.65);

      let prevX = vis.x;
      let prevY = vis.y + 8;
      for (const nextId of army.path) {
        const nextP = this.provById.get(nextId);
        if (!nextP) continue;
        this.arrowGfx.lineBetween(prevX, prevY, nextP.x, nextP.y);

        // Animated marching chevrons sliding along each segment
        const segLen = Math.hypot(nextP.x - prevX, nextP.y - prevY);
        const steps = Math.max(1, Math.floor(segLen / 34));
        const flow = (this.pulseTime * 0.45) % 1;
        this.arrowGfx.fillStyle(0xfef08a, isMine ? 0.92 : 0.55);
        for (let s = 0; s < steps; s++) {
          const t = (s / steps + flow / steps) % 1;
          const dx = prevX + (nextP.x - prevX) * t;
          const dy = prevY + (nextP.y - prevY) * t;
          this.arrowGfx.fillCircle(dx, dy, isMine ? 2.5 : 1.8);
        }

        prevX = nextP.x;
        prevY = nextP.y;
      }

      if (army.path.length > 0) {
        const dest = this.provById.get(army.path[army.path.length - 1]);
        const prev =
          army.path.length > 1
            ? this.provById.get(army.path[army.path.length - 2])
            : { x: vis.x, y: vis.y + 8 };
        if (dest && prev) {
          const angle = Math.atan2(dest.y - prev.y, dest.x - prev.x);
          const headLen = 12;
          this.arrowGfx.fillStyle(color, 0.96);
          this.arrowGfx.fillTriangle(
            dest.x,
            dest.y,
            dest.x - headLen * Math.cos(angle - Math.PI / 6),
            dest.y - headLen * Math.sin(angle - Math.PI / 6),
            dest.x - headLen * Math.cos(angle + Math.PI / 6),
            dest.y - headLen * Math.sin(angle + Math.PI / 6)
          );
        }
      }
    }

    // Active battle attack lines (filtered by fog of war)
    for (const battle of Object.values(this.gameState.battles)) {
      if (!canPlayerSeeBattle(this.gameState, this.mapData, this.playerCountryId, battle)) continue;
      const from = this.provById.get(battle.fromProvinceId);
      const to = this.provById.get(battle.provinceId);
      if (from && to) {
        this.arrowGfx.lineStyle(4.2, 0xf97316, 0.72);
        this.arrowGfx.lineBetween(from.x, from.y, to.x, to.y);
      }
    }
  }

  private syncArmyAndBattleObjects() {
    this.battleLayer.removeAll(true);
    this.fleetLayer.removeAll(true);

    if (!this.gameState) {
      this.armyLayer.removeAll(true);
      this.armyContainers.clear();
      this.armyVisualPos.clear();
      return;
    }

    const activeIds = new Set<string>();
    const seaMap = new Map(this.mapData.seaZones.map((s) => [s.id, s]));

    // Clean up gone or fog-hidden armies
    for (const id of Array.from(this.armyContainers.keys())) {
      const army = this.gameState.armies[id];
      if (
        !army ||
        getArmyTotal(army.units) <= 0 ||
        !canPlayerSeeArmy(this.gameState, this.mapData, this.playerCountryId, army)
      ) {
        this.armyContainers.get(id)?.destroy(true);
        this.armyContainers.delete(id);
        this.armyVisualPos.delete(id);
      }
    }

    // Group visible armies for clean non-overlapping offsets
    const byProvince: Record<string, Army[]> = {};
    for (const army of Object.values(this.gameState.armies)) {
      if (getArmyTotal(army.units) <= 0) continue;
      if (!canPlayerSeeArmy(this.gameState, this.mapData, this.playerCountryId, army)) continue;
      if (!byProvince[army.provinceId]) byProvince[army.provinceId] = [];
      byProvince[army.provinceId].push(army);
    }

    for (const [provId, list] of Object.entries(byProvince)) {
      const mp = this.provById.get(provId);
      if (!mp) continue;

      list.forEach((army, idx) => {
        activeIds.add(army.id);
        const total = getArmyTotal(army.units);
        const angle = (idx / Math.max(1, list.length)) * Math.PI * 2;
        const radius = list.length === 1 ? 0 : 20;
        const basePos = this.armyVisualPos.get(army.id) || {
          x: mp.x + Math.cos(angle) * radius,
          y: mp.y + Math.sin(angle) * radius - 10,
        };
        if (!this.armyVisualPos.has(army.id)) {
          this.armyVisualPos.set(army.id, basePos);
        }

        const isMine = army.countryId === this.playerCountryId;
        const isSelected = army.id === this.selectedArmyId || army.id === this.targetingArmyId;
        const countryColor = COUNTRIES[army.countryId]?.color || '#475569';
        const colorNum = parseInt(countryColor.replace('#', ''), 16) || 0x475569;

        // Rebuild counter graphics cleanly while keeping smoothed coordinates
        this.armyContainers.get(army.id)?.destroy(true);
        const container = this.add.container(basePos.x, basePos.y);

        if (isSelected) {
          const ring = this.add.rectangle(0, 0, 50, 26, 0xfacc15, 0.28);
          ring.setStrokeStyle(2.2, 0xfacc15, 1);
          container.add(ring);
        }

        // Main tactical unit token
        const bg = this.add.rectangle(0, 0, 44, 21, 0x0f172a, 0.94);
        bg.setStrokeStyle(isMine ? 2 : 1.5, isMine ? 0x38bdf8 : colorNum, 1);

        const colorBar = this.add.rectangle(-18, 0, 5, 19, colorNum, 1);

        // Mini helmet / tank dot icon inside token
        const isTankHeavy = army.units.tank >= Math.max(3, army.units.infantry * 0.4);
        const unitGlyph = this.add.circle(-9, -1, 3.2, isTankHeavy ? 0xfbbf24 : 0x84cc16, 1);
        unitGlyph.setStrokeStyle(1, 0x090d16, 1);

        const label = this.add
          .text(6, -1, `${total}K`, {
            fontFamily: '"JetBrains Mono", monospace',
            fontSize: '10.5px',
            fontStyle: 'bold',
            color: army.inBattleId ? '#fca5a5' : '#ffffff',
          })
          .setOrigin(0.5);

        // Morale bar strip on bottom of counter
        const moraleFrac = Math.max(0.15, Math.min(1, army.morale / 100));
        const moraleBar = this.add
          .rectangle(-20, 8.5, 40 * moraleFrac, 2.2, army.morale > 50 ? 0x22c55e : 0xef4444, 0.95)
          .setOrigin(0, 0.5);

        container.add([bg, colorBar, unitGlyph, label, moraleBar]);

        if (army.commanderId) {
          const star = this.add.circle(20, -9, 3.8, 0xfacc15, 1);
          star.setStrokeStyle(1.2, 0x090d16, 1);
          container.add(star);
        }

        bg.setInteractive({ useHandCursor: true });
        bg.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
          pointer.event.stopPropagation();
          this.callbacks.onSelectArmy(army.id);
        });

        this.armyLayer.add(container);
        this.armyContainers.set(army.id, container);
      });
    }

    // Active two-sided tug-of-war battle clash badges (WW2 Mapping Army-Size style!)
    for (const battle of Object.values(this.gameState.battles) as Battle[]) {
      if (!canPlayerSeeBattle(this.gameState, this.mapData, this.playerCountryId, battle)) continue;
      const mp = this.provById.get(battle.provinceId);
      if (!mp) continue;

      const atkHex = COUNTRIES[battle.attackerCountryId]?.color || '#ef4444';
      const defHex = COUNTRIES[battle.defenderCountryId]?.color || '#3b82f6';
      const atkColor = parseInt(atkHex.replace('#', ''), 16) || 0xef4444;
      const defColor = parseInt(defHex.replace('#', ''), 16) || 0x3b82f6;

      const cont = this.add.container(mp.x, mp.y - 38);
      const badgeW = 92;
      const badge = this.add.rectangle(0, 0, badgeW, 22, 0x0f172a, 0.96);
      badge.setStrokeStyle(1.8, 0xf97316, 1);

      const leftStripe = this.add.rectangle(-badgeW / 2 + 2.5, 0, 5, 20, atkColor, 1);
      const rightStripe = this.add.rectangle(badgeW / 2 - 2.5, 0, 5, 20, defColor, 1);

      // Tug-of-war progress bar along bottom edge of badge
      const progW = badgeW - 6;
      const atkFrac = Math.max(0.08, Math.min(0.92, battle.progress / 100));
      const barBg = this.add.rectangle(-progW / 2, 8.5, progW, 3, defColor, 0.9).setOrigin(0, 0.5);
      const barAtk = this.add.rectangle(-progW / 2, 8.5, progW * atkFrac, 3, atkColor, 0.95).setOrigin(0, 0.5);

      const txt = this.add
        .text(
          0,
          -1.5,
          `${battle.attacker.currentStrength}K ⚔ ${battle.defender.currentStrength}K`,
          {
            fontFamily: '"JetBrains Mono", monospace',
            fontSize: '9.5px',
            fontStyle: 'bold',
            color: '#fef2f2',
          }
        )
        .setOrigin(0.5);

      cont.add([badge, leftStripe, rightStripe, barBg, barAtk, txt]);
      badge.setInteractive({ useHandCursor: true });
      badge.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
        pointer.event.stopPropagation();
        this.callbacks.onSelectBattle(battle.id);
      });
      this.battleLayer.add(cont);
    }

    // Fleets at sea
    for (const fleet of Object.values(this.gameState.fleets)) {
      if (!fleet.isAtSea || fleet.ships.length === 0) continue;
      const sz = seaMap.get(fleet.locationId);
      if (!sz) continue;
      const cont = this.add.container(sz.x, sz.y + 18);
      const bg = this.add.rectangle(0, 0, 44, 17, 0x082f49, 0.92);
      bg.setStrokeStyle(1.5, 0x38bdf8, 0.95);
      const txt = this.add
        .text(0, 0, `⚓ ${fleet.ships.length}`, {
          fontFamily: '"JetBrains Mono", monospace',
          fontSize: '9.5px',
          color: '#bae6fd',
        })
        .setOrigin(0.5);
      cont.add([bg, txt]);
      this.fleetLayer.add(cont);
    }
  }

  private findProvinceAt(x: number, y: number): string | null {
    for (const p of this.mapData.provinces) {
      const bb = this.provBBoxes.get(p.id);
      if (!bb || x < bb.minX || x > bb.maxX || y < bb.minY || y > bb.maxY) continue;
      for (const poly of p.polygons) {
        if (pointInPolygon(x, y, poly)) return p.id;
      }
    }
    return null;
  }
}
