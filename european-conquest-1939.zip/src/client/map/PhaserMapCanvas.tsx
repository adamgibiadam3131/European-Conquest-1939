import React, { useEffect, useRef } from 'react';
import Phaser from 'phaser';
import type { GameState, MapDataStatic, MapMode } from '../../shared/types.ts';
import { StrategyMapScene, type MapCallbacks } from './StrategyMapScene.ts';

interface PhaserMapCanvasProps {
  mapData: MapDataStatic;
  gameState: GameState | null;
  playerCountryId: string | null;
  mapMode: MapMode;
  selectedProvinceId: string | null;
  selectedArmyId: string | null;
  targetingArmyId: string | null;
  highlightOwnTargets?: boolean;
  lobbyScenarioId: '1939_alt' | '1939_hist';
  isLobbyPan: boolean;
  callbacks: MapCallbacks;
  sceneRefOut: React.MutableRefObject<StrategyMapScene | null>;
}

export const PhaserMapCanvas: React.FC<PhaserMapCanvasProps> = ({
  mapData,
  gameState,
  playerCountryId,
  mapMode,
  selectedProvinceId,
  selectedArmyId,
  targetingArmyId,
  highlightOwnTargets,
  lobbyScenarioId,
  isLobbyPan,
  callbacks,
  sceneRefOut,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const callbacksRef = useRef<MapCallbacks>(callbacks);
  callbacksRef.current = callbacks;

  useEffect(() => {
    if (!containerRef.current) return;

    const scene = new StrategyMapScene();
    scene.initData(mapData, {
      onSelectProvince: (id) => callbacksRef.current.onSelectProvince(id),
      onRightClickProvince: (id) => callbacksRef.current.onRightClickProvince?.(id),
      onSelectArmy: (id) => callbacksRef.current.onSelectArmy(id),
      onSelectBattle: (id) => callbacksRef.current.onSelectBattle(id),
      onSelectSeaZone: (id) => callbacksRef.current.onSelectSeaZone(id),
      onTargetProvinceChosen: (id) => callbacksRef.current.onTargetProvinceChosen(id),
      onHoverProvince: (id) => callbacksRef.current.onHoverProvince?.(id),
    });

    const game = new Phaser.Game({
      type: Phaser.AUTO,
      parent: containerRef.current,
      width: window.innerWidth,
      height: window.innerHeight,
      backgroundColor: '#08172b',
      scale: {
        mode: Phaser.Scale.RESIZE,
        autoCenter: Phaser.Scale.CENTER_BOTH,
      },
      render: {
        antialias: true,
        pixelArt: false,
      },
      scene: [scene],
    });

    sceneRefOut.current = scene;

    return () => {
      sceneRefOut.current = null;
      game.destroy(true);
    };
  }, [mapData, sceneRefOut]);

  useEffect(() => {
    const scene = sceneRefOut.current;
    if (!scene) return;
    scene.syncState({
      gameState,
      playerCountryId,
      mapMode,
      selectedProvinceId,
      selectedArmyId,
      targetingArmyId,
      highlightOwnTargets,
      lobbyScenarioId,
      isLobbyPan,
    });
  }, [
    gameState,
    playerCountryId,
    mapMode,
    selectedProvinceId,
    selectedArmyId,
    targetingArmyId,
    highlightOwnTargets,
    lobbyScenarioId,
    isLobbyPan,
    sceneRefOut,
  ]);

  return (
    <div
      ref={containerRef}
      className={`fixed inset-0 w-full h-full ${targetingArmyId ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'}`}
    />
  );
};
