export type IdeologyType = 'communism' | 'democracy' | 'fascism' | 'monarchy';

export type TerrainType = 'plains' | 'forest' | 'hills' | 'mountain' | 'desert' | 'urban';

export type RegionGroup =
  | 'Avrupa'
  | 'Türkiye ve Kafkasya'
  | 'Orta Doğu'
  | 'Arap Yarımadası'
  | 'Kuzey Afrika';

export type LandUnitType =
  | 'infantry'
  | 'tank'
  | 'antitank'
  | 'artillery'
  | 'motorized'
  | 'antiair';

export type AirUnitType = 'fighter' | 'bomber' | 'cas' | 'recon';

export type NavalUnitType =
  | 'transport'
  | 'destroyer'
  | 'cruiser'
  | 'battleship'
  | 'carrier'
  | 'submarine';

export type BuildingType =
  | 'factory'
  | 'housing'
  | 'road'
  | 'railway'
  | 'military_base'
  | 'airbase'
  | 'port'
  | 'radar'
  | 'nuclear_facility';

export type ProductionItemType =
  | 'infantry_gear'
  | 'tank_parts'
  | 'antitank_weapons'
  | 'artillery_guns'
  | 'consumer_goods'
  | 'fighters'
  | 'bombers'
  | 'warships'
  | 'submarines';

export type AirMissionType = 'air_superiority' | 'cas' | 'bombing' | 'recon' | 'idle';

export type DifficultyLevel = 'easy' | 'normal' | 'hard';

export type GameSpeed = 1 | 2 | 4;

export type MapMode = 'political' | 'diplomacy' | 'supply' | 'terrain';

export interface MapProvinceStatic {
  id: string;
  name: string;
  countryId: string;
  isCapital: boolean;
  isPort: boolean;
  terrain: TerrainType;
  basePop: number;
  baseFactories: number;
  x: number;
  y: number;
  polygons: [number, number][][];
  neighbors: string[];
  seaNeighbors: string[];
}

export interface SeaZoneStatic {
  id: string;
  name: string;
  x: number;
  y: number;
  neighbors: string[];
  portProvinces: string[];
}

export interface MapDataStatic {
  width: number;
  height: number;
  source: string;
  provinces: MapProvinceStatic[];
  seaZones: SeaZoneStatic[];
}

export interface CountryStatic {
  id: string;
  name: string;
  region: RegionGroup;
  color: string;
  leader: string;
  ideology: IdeologyType;
  capitalProvinceId: string;
  isMajor: boolean;
  flagColors: string[];
  flagLayout: 'horizontal' | 'vertical' | 'cross' | 'nordic' | 'canton' | 'crescent' | 'bicolor' | 'eagle';
  flagSymbol?: string;
}

export interface ConstructionItem {
  id: string;
  buildingType: BuildingType;
  daysRemaining: number;
  totalDays: number;
}

export interface ProvinceState {
  id: string;
  ownerId: string;
  controllerId: string;
  population: number;
  buildings: Record<BuildingType, number>;
  constructions: ConstructionItem[];
  supplyLevel: number; // 0..100
  defenseLevel: number;
  nuked: boolean;
}

export interface ArmyComposition {
  infantry: number;
  tank: number;
  antitank: number;
  artillery: number;
  motorized: number;
  antiair: number;
}

export interface Army {
  id: string;
  name: string;
  countryId: string;
  provinceId: string;
  units: ArmyComposition; // each integer = 1K troops
  commanderId: string | null;
  experience: number; // 0..100
  morale: number; // 0..100
  supply: number; // 0..100
  path: string[]; // queued provinceIds to move through
  moveProgress: number; // 0..100 towards path[0]
  inBattleId: string | null;
  isRetreating: boolean;
}

export interface TrainingOrder {
  id: string;
  unitType: LandUnitType;
  targetProvinceId: string;
  daysRemaining: number;
  totalDays: number;
}

export interface AirWing {
  id: string;
  countryId: string;
  provinceId: string; // airbase province
  type: AirUnitType;
  count: number;
  mission: AirMissionType;
  targetProvinceId: string | null;
}

export interface ShipInstance {
  id: string;
  type: NavalUnitType;
  name: string;
  hp: number;
  maxHp: number;
}

export interface Fleet {
  id: string;
  name: string;
  countryId: string;
  locationId: string; // provinceId (docked) or seaZoneId (at sea)
  isAtSea: boolean;
  ships: ShipInstance[];
  mission: 'docked' | 'patrol' | 'escort' | 'raid';
  targetSeaZoneId: string | null;
}

export interface ShipBuildOrder {
  id: string;
  provinceId: string;
  shipType: NavalUnitType;
  daysRemaining: number;
  totalDays: number;
}

export interface CommanderStatic {
  id: string;
  countryId: string; // 'GENERIC' for fallback pool
  name: string;
  title: string;
  isLegacy?: boolean;
  unlockCost: number;
  attackBonus: number; // e.g. 0.08 = +8%
  defenseBonus: number;
  tankBonus: number;
  infantryBonus: number;
  xpBonus: number;
  portraitStyle: {
    skin: string;
    hair: string;
    uniform: string;
    hat: 'peak' | 'beret' | 'fez' | 'none' | 'helmet';
    mustache: 'none' | 'handlebar' | 'chevron' | 'trimmed';
    glasses?: boolean;
  };
}

export interface CommanderState {
  id: string;
  unlocked: boolean;
  assignedArmyId: string | null;
  level: number;
  xp: number;
}

export type TechCategory =
  | 'infantry'
  | 'tank'
  | 'artillery'
  | 'infrastructure'
  | 'economy'
  | 'air'
  | 'navy'
  | 'radar'
  | 'rockets'
  | 'nuclear';

export interface TechNode {
  id: string;
  category: TechCategory;
  name: string;
  description: string;
  cost: number;
  days: number;
  tier: number;
  prerequisites: string[];
  bonuses: {
    infantryAttack?: number;
    infantryDefense?: number;
    tankAttack?: number;
    tankDefense?: number;
    artilleryPower?: number;
    antitankPower?: number;
    antiairPower?: number;
    factoryEfficiency?: number;
    taxIncome?: number;
    researchSpeed?: number;
    researchSlots?: number;
    supplyBonus?: number;
    airPower?: number;
    navalPower?: number;
    rocketPower?: number;
    nukeReady?: boolean;
    unlocksUnit?: LandUnitType | AirUnitType | NavalUnitType;
    unlocksBuilding?: BuildingType;
    unlocksProduction?: ProductionItemType;
  };
}

export interface ActiveResearch {
  techId: string;
  daysRemaining: number;
  totalDays: number;
}

export interface FocusNode {
  id: string;
  name: string;
  description: string;
  branch: IdeologyType | 'center';
  row: number;
  col: number;
  costDiplomacy: number;
  prerequisites: string[];
  effects: {
    diplomacyGain?: number;
    manpowerFactor?: number;
    factoryEfficiency?: number;
    taxBonus?: number;
    attackVsIdeology?: { ideology: IdeologyType; bonus: number };
    navalBuildSpeed?: number;
    researchSpeed?: number;
    infantryAttack?: number;
    defenseBonus?: number;
    ideologyDiscount?: IdeologyType;
  };
}

export interface DiplomacyRelation {
  countryA: string;
  countryB: string;
  opinion: number; // -100..100
  atWar: boolean;
  allied: boolean;
  nonAggression: boolean;
  warStartDay?: number;
}

export interface PeaceTreatyTerms {
  demandProvinceIds: string[];
  cedeProvinceIds: string[];
  vassalizeTarget: boolean;
  becomeVassal: boolean;
  demandMoney: number;
  demandManpower: number;
}

export interface PeaceOffer {
  id: string;
  fromCountryId: string;
  toCountryId: string;
  terms: PeaceTreatyTerms;
  createdDay: number;
}

export interface BattleSideSummary {
  countryId: string;
  armyIds: string[];
  initialStrength: number;
  currentStrength: number;
  casualties: ArmyComposition;
  commanderName: string | null;
  modifiers: {
    techBonus: number;
    commanderBonus: number;
    terrainBonus: number;
    airSupport: number;
    supplyPenalty: number;
  };
}

export interface Battle {
  id: string;
  provinceId: string;
  fromProvinceId: string;
  attackerCountryId: string;
  defenderCountryId: string;
  startDay: number;
  attacker: BattleSideSummary;
  defender: BattleSideSummary;
  progress: number; // 0..100 (50 balanced, 100 attacker wins, 0 defender wins)
}

export interface BattleHistoryEntry {
  id: string;
  provinceId: string;
  provinceName: string;
  attackerCountryId: string;
  defenderCountryId: string;
  winnerCountryId: string;
  attackerLosses: number;
  defenderLosses: number;
  day: number;
}

export interface CountryEconomyStats {
  taxIncome: number;
  consumerGoodsIncome: number;
  armyUpkeep: number;
  navyUpkeep: number;
  airUpkeep: number;
  otherUpkeep: number;
  netIncome: number;
  factoryEfficiency: number;
  totalFactories: number;
}

export interface CountryState {
  id: string;
  isHuman: boolean;
  playerId: string | null;
  ideology: IdeologyType;
  money: number;
  manpower: number;
  maxManpower: number;
  uranium: number;
  nukes: number;
  diplomacyPoints: number;
  totalFactories: number;
  productionAllocations: Record<ProductionItemType, number>; // weights/factories
  stockpiles: Record<ProductionItemType, number>;
  dailyProduction: Record<ProductionItemType, number>;
  researchedTechs: string[];
  activeResearch: ActiveResearch[];
  maxResearchSlots: number;
  completedFocuses: string[];
  trainingQueue: TrainingOrder[];
  shipQueue: ShipBuildOrder[];
  recruitProvinceId?: string | null;
  commanders: Record<string, CommanderState>;
  economy: CountryEconomyStats;
  provincesCaptured: number;
  totalCasualtiesInflicted: number;
  totalCasualtiesTaken: number;
  vassalOfId: string | null;
  eliminated: boolean;
}

export interface VictorySummary {
  winnerType: 'country' | 'coalition';
  winnerIds: string[];
  winnerNames: string[];
  controlPercent: number;
  thresholdPercent: number;
  day: number;
  rankings: {
    countryId: string;
    name: string;
    color: string;
    provinces: number;
    controlPercent: number;
    casualtiesInflicted: number;
    casualtiesTaken: number;
    isHuman: boolean;
  }[];
}

export interface GameNotification {
  id: string;
  day: number;
  type: 'war' | 'peace' | 'alliance' | 'conquest' | 'research' | 'nuke' | 'info';
  title: string;
  message: string;
}

export interface GameState {
  roomId: string;
  mode: 'singleplayer' | 'multiplayer';
  scenarioId: '1939_alt' | '1939_hist';
  difficulty: DifficultyLevel;
  victoryThreshold: 75 | 80;
  day: number; // 0 = 1 Eylül 1939
  paused: boolean;
  speed: GameSpeed;
  countries: Record<string, CountryState>;
  provinces: Record<string, ProvinceState>;
  armies: Record<string, Army>;
  airWings: Record<string, AirWing>;
  fleets: Record<string, Fleet>;
  relations: Record<string, DiplomacyRelation>; // key sorted `A__B`
  peaceOffers: PeaceOffer[];
  battles: Record<string, Battle>;
  battleHistory: BattleHistoryEntry[];
  notifications: GameNotification[];
  victory: VictorySummary | null;
}

export interface RoomPlayer {
  playerId: string;
  name: string;
  countryId: string | null;
  ready: boolean;
  connected: boolean;
  isHost: boolean;
}

export interface RoomLobbyState {
  roomId: string;
  roomCode: string;
  mode: 'singleplayer' | 'multiplayer';
  status: 'lobby' | 'playing' | 'finished';
  maxHumanPlayers: number;
  scenarioId: '1939_alt' | '1939_hist';
  difficulty: DifficultyLevel;
  victoryThreshold: 75 | 80;
  players: RoomPlayer[];
}

export type ClientAction =
  | { type: 'SELECT_COUNTRY'; countryId: string }
  | { type: 'TOGGLE_READY' }
  | { type: 'UPDATE_SETTINGS'; scenarioId?: '1939_alt' | '1939_hist'; difficulty?: DifficultyLevel; victoryThreshold?: 75 | 80; maxHumanPlayers?: number }
  | { type: 'START_GAME' }
  | { type: 'SET_PAUSE'; paused: boolean }
  | { type: 'SET_SPEED'; speed: GameSpeed }
  | { type: 'RECRUIT_UNIT'; unitType: LandUnitType; provinceId?: string }
  | { type: 'SET_RECRUIT_PROVINCE'; provinceId: string }
  | { type: 'BUY_MANPOWER_CAMPAIGN' }
  | { type: 'BUILD_STRUCTURE'; provinceId: string; buildingType: BuildingType }
  | { type: 'SET_PRODUCTION_ALLOCATION'; item: ProductionItemType; factories: number }
  | { type: 'START_RESEARCH'; techId: string }
  | { type: 'UNLOCK_COMMANDER'; commanderId: string }
  | { type: 'ASSIGN_COMMANDER'; commanderId: string; armyId: string | null }
  | { type: 'SWITCH_IDEOLOGY'; ideology: IdeologyType }
  | { type: 'COMPLETE_FOCUS'; focusId: string }
  | { type: 'DIPLOMACY_ACTION'; targetCountryId: string; action: 'declare_war' | 'propose_peace' | 'form_alliance' | 'break_alliance' | 'non_aggression' | 'send_aid' | 'release_vassal' | 'declare_independence'; demandProvinces?: boolean }
  | { type: 'SEND_PEACE_OFFER'; targetCountryId: string; terms: PeaceTreatyTerms }
  | { type: 'RESPOND_PEACE_OFFER'; offerId: string; accept: boolean }
  | { type: 'MOVE_ARMY'; armyId: string; targetProvinceId: string }
  | { type: 'SPLIT_ARMY'; armyId: string }
  | { type: 'MERGE_ARMIES'; provinceId: string }
  | { type: 'BUILD_AIR_WING'; provinceId: string; airType: AirUnitType }
  | { type: 'SET_AIR_MISSION'; wingId: string; mission: AirMissionType; targetProvinceId: string | null }
  | { type: 'BUILD_SHIP'; provinceId: string; shipType: NavalUnitType }
  | { type: 'MOVE_FLEET'; fleetId: string; targetSeaZoneId: string; mission: 'patrol' | 'escort' | 'raid' | 'docked' }
  | { type: 'LAUNCH_NUKE'; targetProvinceId: string }
  | { type: 'SAVE_GAME'; slotName: string }
  | { type: 'SURRENDER_TO_AI' };
