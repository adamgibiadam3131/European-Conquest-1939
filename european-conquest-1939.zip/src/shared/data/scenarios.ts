import type { IdeologyType } from '../types.ts';

export interface ScenarioConfig {
  id: '1939_alt' | '1939_hist';
  name: string;
  description: string;
  startDate: string;
  provinceOwnerOverrides: Record<string, string>; // provinceId -> countryId
  ideologyOverrides: Record<string, IdeologyType>;
  initialAlliances: [string, string][];
  initialWars: [string, string][];
}

export const SCENARIOS: Record<'1939_alt' | '1939_hist', ScenarioConfig> = {
  '1939_alt': {
    id: '1939_alt',
    name: '1 Eylül 1939 — Alternatif Tarih (Tüm Devletler Özgür)',
    description:
      'Avrupa, Türkiye, Kafkasya, Orta Doğu, Arap Yarımadası ve Kuzey Afrika’daki tüm 67 ülke bağımsız ve oynanabilir durumdadır.',
    startDate: '1 Eylül 1939',
    provinceOwnerOverrides: {},
    ideologyOverrides: {},
    initialAlliances: [
      ['UK', 'FRA'],
      ['UK', 'POL'],
    ],
    initialWars: [],
  },
  '1939_hist': {
    id: '1939_hist',
    name: '1 Eylül 1939 — Tarihsel Bloklar',
    description:
      '1939 tarihi bloklarına yakın sahiplik düzeni: Avusturya/Çekya Almanya kontrolünde, Kafkasya/Ukrayna/Belarus Sovyetler Birliği’nde, Kuzey Afrika’da Fransız/İtalyan etkileri.',
    startDate: '1 Eylül 1939',
    provinceOwnerOverrides: {
      aus_vienna: 'GER',
      aus_innsbruck: 'GER',
      cze_prague: 'GER',
      cze_brno: 'GER',
      blr_minsk: 'RUS',
      blr_gomel: 'RUS',
      ukr_kyiv: 'RUS',
      ukr_kharkiv: 'RUS',
      ukr_odessa: 'RUS',
      ukr_lviv: 'RUS',
      ukr_crimea: 'RUS',
      geo_tbilisi: 'RUS',
      arm_yerevan: 'RUS',
      aze_baku: 'RUS',
      lby_tripoli: 'ITA',
      lby_benghazi: 'ITA',
      alb_tirana: 'ITA',
      alg_algiers: 'FRA',
      alg_oran: 'FRA',
      alg_tamanrasset: 'FRA',
      tun_tunis: 'FRA',
      syr_damascus: 'FRA',
      syr_aleppo: 'FRA',
      leb_beirut: 'FRA',
      egy_cairo: 'UK',
      egy_alexandria: 'UK',
      egy_aswan: 'UK',
      pal_jerusalem: 'UK',
      jor_amman: 'UK',
    },
    ideologyOverrides: {
      GER: 'fascism',
      ITA: 'fascism',
      RUS: 'communism',
    },
    initialAlliances: [
      ['UK', 'FRA'],
      ['UK', 'POL'],
      ['GER', 'ITA'],
    ],
    initialWars: [['GER', 'POL']],
  },
};
