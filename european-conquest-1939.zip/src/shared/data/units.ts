import type {
  AirUnitType,
  BuildingType,
  LandUnitType,
  NavalUnitType,
  ProductionItemType,
  TerrainType,
} from '../types.ts';

export interface LandUnitSpec {
  id: LandUnitType;
  name: string;
  description: string;
  moneyCost: number;
  manpowerCost: number; // 1000 = 1K
  trainDays: number;
  dailyUpkeep: number;
  attack: number;
  defense: number;
  antiTank: number;
  artillerySoftAttack: number;
  antiAir: number;
  speed: number;
  equipmentCost: Partial<Record<ProductionItemType, number>>;
  requiredTech?: string;
}

export const LAND_UNITS: Record<LandUnitType, LandUnitSpec> = {
  infantry: {
    id: 'infantry',
    name: 'Piyade (1K)',
    description: 'Savunmada dayanıklı, her arazide güvenilir temel kara birliği.',
    moneyCost: 2200,
    manpowerCost: 1000,
    trainDays: 5,
    dailyUpkeep: 18,
    attack: 10,
    defense: 15,
    antiTank: 2,
    artillerySoftAttack: 1,
    antiAir: 1,
    speed: 1.0,
    equipmentCost: { infantry_gear: 10 },
  },
  tank: {
    id: 'tank',
    name: 'Tank Birliği (1K)',
    description: 'Yüksek zırh ve saldırı gücüyle düşman hatlarını yaran taarruz kuvveti.',
    moneyCost: 6500,
    manpowerCost: 1000,
    trainDays: 10,
    dailyUpkeep: 55,
    attack: 28,
    defense: 16,
    antiTank: 10,
    artillerySoftAttack: 5,
    antiAir: 1,
    speed: 1.5,
    equipmentCost: { tank_parts: 15 },
    requiredTech: 'tank_1',
  },
  antitank: {
    id: 'antitank',
    name: 'Anti-Tank (1K)',
    description: 'Düşman tank birliklerine karşı ağır zırh delici savunma sağlar.',
    moneyCost: 3400,
    manpowerCost: 1000,
    trainDays: 7,
    dailyUpkeep: 28,
    attack: 8,
    defense: 14,
    antiTank: 24,
    artillerySoftAttack: 2,
    antiAir: 1,
    speed: 0.95,
    equipmentCost: { antitank_weapons: 12 },
  },
  artillery: {
    id: 'artillery',
    name: 'Topçu (1K)',
    description: 'Savaşta düşman tahkimatını ve savunma katsayısını ciddi biçimde zayıflatır.',
    moneyCost: 4200,
    manpowerCost: 1000,
    trainDays: 8,
    dailyUpkeep: 34,
    attack: 18,
    defense: 9,
    antiTank: 4,
    artillerySoftAttack: 22,
    antiAir: 0,
    speed: 0.85,
    equipmentCost: { artillery_guns: 12 },
  },
  motorized: {
    id: 'motorized',
    name: 'Motorize Piyade (1K)',
    description: 'Hızlı intikal kabiliyetine sahip mekanize piyade tümeni.',
    moneyCost: 3900,
    manpowerCost: 1000,
    trainDays: 7,
    dailyUpkeep: 32,
    attack: 15,
    defense: 16,
    antiTank: 4,
    artillerySoftAttack: 3,
    antiAir: 2,
    speed: 1.6,
    equipmentCost: { infantry_gear: 8, tank_parts: 4 },
    requiredTech: 'inf_motorized',
  },
  antiair: {
    id: 'antiair',
    name: 'Uçaksavar (1K)',
    description: 'Düşman hava saldırılarını ve yakın hava desteğini büyük ölçüde azaltır.',
    moneyCost: 3200,
    manpowerCost: 1000,
    trainDays: 6,
    dailyUpkeep: 25,
    attack: 6,
    defense: 12,
    antiTank: 4,
    artillerySoftAttack: 2,
    antiAir: 26,
    speed: 0.95,
    equipmentCost: { artillery_guns: 6, infantry_gear: 4 },
    requiredTech: 'art_aa',
  },
};

export interface AirUnitSpec {
  id: AirUnitType;
  name: string;
  description: string;
  moneyCost: number;
  dailyUpkeep: number;
  airAttack: number;
  groundSupport: number;
  bombingPower: number;
  reconBonus: number;
  requiredTech?: string;
}

export const AIR_UNITS: Record<AirUnitType, AirUnitSpec> = {
  fighter: {
    id: 'fighter',
    name: 'Avcı Uçağı Filosu',
    description: 'Hava üstünlüğü kurar ve düşman bombardıman uçaklarını düşürür.',
    moneyCost: 9000,
    dailyUpkeep: 60,
    airAttack: 24,
    groundSupport: 4,
    bombingPower: 2,
    reconBonus: 5,
    requiredTech: 'air_fighter_1',
  },
  cas: {
    id: 'cas',
    name: 'Yakın Hava Desteği (CAS)',
    description: 'Kara savaşlarında cephedeki düşman birliklerine doğrudan darbe vurur.',
    moneyCost: 10500,
    dailyUpkeep: 70,
    airAttack: 8,
    groundSupport: 26,
    bombingPower: 8,
    reconBonus: 4,
    requiredTech: 'air_cas_1',
  },
  bomber: {
    id: 'bomber',
    name: 'Stratejik Bombardıman',
    description: 'Düşman fabrikalarını, ikmal hatlarını ve savunma tesislerini vurur.',
    moneyCost: 13500,
    dailyUpkeep: 90,
    airAttack: 6,
    groundSupport: 12,
    bombingPower: 28,
    reconBonus: 2,
    requiredTech: 'air_bomber_1',
  },
  recon: {
    id: 'recon',
    name: 'Keşif Uçağı',
    description: 'İstihbarat sağlar ve topçu/saldırı isabetini artırır.',
    moneyCost: 6500,
    dailyUpkeep: 40,
    airAttack: 4,
    groundSupport: 8,
    bombingPower: 0,
    reconBonus: 22,
    requiredTech: 'air_fighter_1',
  },
};

export interface NavalUnitSpec {
  id: NavalUnitType;
  name: string;
  description: string;
  moneyCost: number;
  buildDays: number;
  dailyUpkeep: number;
  maxHp: number;
  attack: number;
  aa: number;
  requiredTech?: string;
}

export const NAVAL_UNITS: Record<NavalUnitType, NavalUnitSpec> = {
  transport: {
    id: 'transport',
    name: 'Nakliye Gemisi',
    description: 'Deniz aşırı çıkarma ve asker taşımacılığı için zorunludur.',
    moneyCost: 6000,
    buildDays: 8,
    dailyUpkeep: 25,
    maxHp: 50,
    attack: 2,
    aa: 2,
  },
  destroyer: {
    id: 'destroyer',
    name: 'Muhrip',
    description: 'Hızlı eskort gemisi; denizaltılara ve küçük gemilere karşı etkilidir.',
    moneyCost: 14000,
    buildDays: 12,
    dailyUpkeep: 65,
    maxHp: 120,
    attack: 18,
    aa: 10,
    requiredTech: 'navy_destroyer',
  },
  cruiser: {
    id: 'cruiser',
    name: 'Kruvazör',
    description: 'Çok amaçlı ağır filo gemisi.',
    moneyCost: 24000,
    buildDays: 16,
    dailyUpkeep: 110,
    maxHp: 210,
    attack: 34,
    aa: 18,
    requiredTech: 'navy_cruiser',
  },
  battleship: {
    id: 'battleship',
    name: 'Zırhlı Gemi',
    description: 'Denizlerin en ağır ateş gücüne sahip dev savaş gemisi.',
    moneyCost: 38000,
    buildDays: 24,
    dailyUpkeep: 180,
    maxHp: 380,
    attack: 62,
    aa: 24,
    requiredTech: 'navy_battleship',
  },
  carrier: {
    id: 'carrier',
    name: 'Uçak Gemisi',
    description: 'Açık denizlerde hava üstünlüğü ve uzak menzil saldırı gücü sağlar.',
    moneyCost: 48000,
    buildDays: 28,
    dailyUpkeep: 220,
    maxHp: 340,
    attack: 74,
    aa: 34,
    requiredTech: 'navy_carrier',
  },
  submarine: {
    id: 'submarine',
    name: 'Denizaltı',
    description: 'Düşman ikmal ve nakliye konvoylarına sinsi baskınlar düzenler.',
    moneyCost: 12000,
    buildDays: 10,
    dailyUpkeep: 50,
    maxHp: 90,
    attack: 24,
    aa: 2,
    requiredTech: 'navy_submarine',
  },
};

export interface BuildingSpec {
  id: BuildingType;
  name: string;
  description: string;
  cost: number;
  buildDays: number;
  maxPerProvince: number;
  requiresPort?: boolean;
  requiredTech?: string;
}

export const BUILDINGS: Record<BuildingType, BuildingSpec> = {
  factory: {
    id: 'factory',
    name: 'Fabrika',
    description: 'Ülke genelindeki üretim kapasitesini (+1 Fabrika) ve vergiyi artırır.',
    cost: 12000,
    buildDays: 12,
    maxPerProvince: 12,
  },
  housing: {
    id: 'housing',
    name: 'Konut / Evler',
    description: 'Şehir nüfus kapasitesini ve insan gücü havuzunu (+8K) büyütür.',
    cost: 7000,
    buildDays: 8,
    maxPerProvince: 10,
  },
  road: {
    id: 'road',
    name: 'Karayolu Ağı',
    description: 'Bölge ikmal seviyesini (+%12) ve birlik hareket hızını artırır.',
    cost: 5500,
    buildDays: 6,
    maxPerProvince: 5,
  },
  railway: {
    id: 'railway',
    name: 'Demiryolu Hattı',
    description: 'Ağır birliklere yüksek ikmal (+%20) ve cephe desteği sağlar.',
    cost: 9000,
    buildDays: 10,
    maxPerProvince: 4,
    requiredTech: 'infra_logistics',
  },
  military_base: {
    id: 'military_base',
    name: 'Askerî Üs / Tahkimat',
    description: 'Bölge savunma bonusunu (+%15) artırır.',
    cost: 8500,
    buildDays: 9,
    maxPerProvince: 5,
  },
  airbase: {
    id: 'airbase',
    name: 'Hava Üssü',
    description: 'Bölgede konuşlandırılabilecek uçak kapasitesini (+30) artırır.',
    cost: 10000,
    buildDays: 10,
    maxPerProvince: 6,
  },
  port: {
    id: 'port',
    name: 'Deniz Limanı',
    description: 'Gemi üretimini ve filo kapasitesini (+4 gemi) artırır.',
    cost: 11000,
    buildDays: 11,
    maxPerProvince: 6,
    requiresPort: true,
  },
  radar: {
    id: 'radar',
    name: 'Radar Tesisi',
    description: 'Bölgedeki hava savunmasını ve keşif bonusunu (+%15) güçlendirir.',
    cost: 13000,
    buildDays: 12,
    maxPerProvince: 3,
    requiredTech: 'radar_1',
  },
  nuclear_facility: {
    id: 'nuclear_facility',
    name: 'Nükleer Tesis',
    description: 'Günlük Uranyum zenginleştirme ve atom bombası üretimi sağlar.',
    cost: 45000,
    buildDays: 25,
    maxPerProvince: 2,
    requiredTech: 'nuke_facility',
  },
};

export interface ProductionItemSpec {
  id: ProductionItemType;
  name: string;
  perFactoryPerDay: number;
  maxStock: number; // Infinity for consumer_goods
  taxPerUnit?: number;
  requiredTech?: string;
}

export const PRODUCTION_ITEMS: ProductionItemSpec[] = [
  {
    id: 'infantry_gear',
    name: 'Piyade Donanımı',
    perFactoryPerDay: 2.5,
    maxStock: 300,
  },
  {
    id: 'tank_parts',
    name: 'Tank Parçaları',
    perFactoryPerDay: 1.6,
    maxStock: 250,
  },
  {
    id: 'antitank_weapons',
    name: 'Anti-Tank Silahları',
    perFactoryPerDay: 1.8,
    maxStock: 250,
  },
  {
    id: 'artillery_guns',
    name: 'Topçu Donanımı',
    perFactoryPerDay: 1.7,
    maxStock: 250,
  },
  {
    id: 'consumer_goods',
    name: 'Tüketim Malları',
    perFactoryPerDay: 1.0,
    maxStock: 999999,
    taxPerUnit: 115,
  },
  {
    id: 'fighters',
    name: 'Avcı & Keşif Uçakları',
    perFactoryPerDay: 0.4,
    maxStock: 100,
    requiredTech: 'air_fighter_1',
  },
  {
    id: 'bombers',
    name: 'Bombardıman & CAS',
    perFactoryPerDay: 0.3,
    maxStock: 80,
    requiredTech: 'air_bomber_1',
  },
  {
    id: 'warships',
    name: 'Savaş Gemileri',
    perFactoryPerDay: 0.2,
    maxStock: 40,
    requiredTech: 'navy_destroyer',
  },
  {
    id: 'submarines',
    name: 'Denizaltılar',
    perFactoryPerDay: 0.25,
    maxStock: 40,
    requiredTech: 'navy_submarine',
  },
];

export const TERRAIN_MODIFIERS: Record<
  TerrainType,
  { label: string; attackMod: number; defenseMod: number; moveMod: number }
> = {
  plains: { label: 'Ova', attackMod: 1.0, defenseMod: 1.0, moveMod: 1.0 },
  urban: { label: 'Şehir', attackMod: 0.85, defenseMod: 1.35, moveMod: 0.9 },
  forest: { label: 'Orman', attackMod: 0.9, defenseMod: 1.2, moveMod: 0.85 },
  hills: { label: 'Tepelik', attackMod: 0.9, defenseMod: 1.25, moveMod: 0.8 },
  mountain: { label: 'Dağlık', attackMod: 0.72, defenseMod: 1.5, moveMod: 0.65 },
  desert: { label: 'Çöl', attackMod: 0.95, defenseMod: 0.95, moveMod: 0.85 },
};
