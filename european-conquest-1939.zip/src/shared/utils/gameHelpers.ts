import type {
  Army,
  ArmyComposition,
  CountryState,
  DiplomacyRelation,
  GameState,
  MapDataStatic,
  PeaceTreatyTerms,
} from '../types.ts';
import { TECH_TREE } from '../data/techTree.ts';
import { FOCUS_TREE, IDEOLOGY_DETAILS } from '../data/focusTree.ts';

export function relationKey(a: string, b: string): string {
  return a < b ? `${a}__${b}` : `${b}__${a}`;
}

export function getRelation(
  relations: Record<string, DiplomacyRelation>,
  a: string,
  b: string
): DiplomacyRelation {
  const key = relationKey(a, b);
  return (
    relations[key] || {
      countryA: a < b ? a : b,
      countryB: a < b ? b : a,
      opinion: 0,
      atWar: false,
      allied: false,
      nonAggression: false,
    }
  );
}

const TURKISH_MONTHS = [
  'Ocak',
  'Şubat',
  'Mart',
  'Nisan',
  'Mayıs',
  'Haziran',
  'Temmuz',
  'Ağustos',
  'Eylül',
  'Ekim',
  'Kasım',
  'Aralık',
];

// Day 0 = 1 Eylül 1939
export function formatGameDate(dayOffset: number): string {
  const base = new Date(Date.UTC(1939, 8, 1)); // Sept 1, 1939
  base.setUTCDate(base.getUTCDate() + Math.max(0, Math.floor(dayOffset)));
  const d = base.getUTCDate();
  const m = TURKISH_MONTHS[base.getUTCMonth()];
  const y = base.getUTCFullYear();
  return `${d} ${m} ${y}`;
}

export function formatCompact(value: number): string {
  const abs = Math.abs(value);
  const sign = value < 0 ? '-' : '';
  if (abs >= 1_000_000) return `${sign}${(abs / 1_000_000).toFixed(1)}M`;
  if (abs >= 1_000) return `${sign}${(abs / 1_000).toFixed(1)}K`;
  return `${sign}${Math.round(abs)}`;
}

export function getArmyTotal(units: ArmyComposition): number {
  return (
    units.infantry +
    units.tank +
    units.antitank +
    units.artillery +
    units.motorized +
    units.antiair
  );
}

export interface CountryComputedModifiers {
  infantryAttack: number;
  infantryDefense: number;
  tankAttack: number;
  tankDefense: number;
  artilleryPower: number;
  antitankPower: number;
  antiairPower: number;
  factoryEfficiency: number;
  taxIncome: number;
  researchSpeed: number;
  manpowerFactor: number;
  supplyBonus: number;
  airPower: number;
  navalPower: number;
  navalBuildSpeed: number;
  diplomacyGain: number;
  nukeReady: boolean;
}

export function getCountryModifiers(country: CountryState): CountryComputedModifiers {
  const ideol = IDEOLOGY_DETAILS[country.ideology];
  const mods: CountryComputedModifiers = {
    infantryAttack: 1 + ideol.attackMod,
    infantryDefense: 1 + ideol.defenseMod,
    tankAttack: 1 + ideol.attackMod,
    tankDefense: 1 + ideol.defenseMod,
    artilleryPower: 1,
    antitankPower: 1,
    antiairPower: 1,
    factoryEfficiency: 1 + ideol.factoryEfficiencyMod,
    taxIncome: 1 + ideol.taxMod,
    researchSpeed: 1 + ideol.researchMod,
    manpowerFactor: 1 + ideol.manpowerMod,
    supplyBonus: 0,
    airPower: 1,
    navalPower: 1,
    navalBuildSpeed: 1,
    diplomacyGain: country.ideology === 'democracy' ? 1.1 : 1.0,
    nukeReady: false,
  };

  for (const techId of country.researchedTechs) {
    const t = TECH_TREE.find((n) => n.id === techId);
    if (!t) continue;
    const b = t.bonuses;
    if (b.infantryAttack) mods.infantryAttack += b.infantryAttack;
    if (b.infantryDefense) mods.infantryDefense += b.infantryDefense;
    if (b.tankAttack) mods.tankAttack += b.tankAttack;
    if (b.tankDefense) mods.tankDefense += b.tankDefense;
    if (b.artilleryPower) mods.artilleryPower += b.artilleryPower;
    if (b.antitankPower) mods.antitankPower += b.antitankPower;
    if (b.antiairPower) mods.antiairPower += b.antiairPower;
    if (b.factoryEfficiency) mods.factoryEfficiency += b.factoryEfficiency;
    if (b.taxIncome) mods.taxIncome += b.taxIncome;
    if (b.researchSpeed) mods.researchSpeed += b.researchSpeed;
    if (b.supplyBonus) mods.supplyBonus += b.supplyBonus;
    if (b.airPower) mods.airPower += b.airPower;
    if (b.navalPower) mods.navalPower += b.navalPower;
    if (b.nukeReady) mods.nukeReady = true;
  }

  for (const focusId of country.completedFocuses) {
    const f = FOCUS_TREE.find((n) => n.id === focusId);
    if (!f) continue;
    const e = f.effects;
    if (e.infantryAttack) mods.infantryAttack += e.infantryAttack;
    if (e.defenseBonus) {
      mods.infantryDefense += e.defenseBonus;
      mods.tankDefense += e.defenseBonus;
    }
    if (e.factoryEfficiency) mods.factoryEfficiency += e.factoryEfficiency;
    if (e.taxBonus) mods.taxIncome += e.taxBonus;
    if (e.researchSpeed) mods.researchSpeed += e.researchSpeed;
    if (e.manpowerFactor) mods.manpowerFactor += e.manpowerFactor;
    if (e.navalBuildSpeed) mods.navalBuildSpeed += e.navalBuildSpeed;
    if (e.diplomacyGain) mods.diplomacyGain += e.diplomacyGain;
  }

  return mods;
}

export function canEnterProvince(
  state: GameState,
  movingCountryId: string,
  targetProvinceId: string
): boolean {
  const prov = state.provinces[targetProvinceId];
  if (!prov) return false;
  if (prov.controllerId === movingCountryId) return true;
  if (state.countries[prov.controllerId]?.vassalOfId === movingCountryId) return true;
  if (state.countries[movingCountryId]?.vassalOfId === prov.controllerId) return true;
  const rel = getRelation(state.relations, movingCountryId, prov.controllerId);
  return rel.allied || rel.atWar;
}

export function calculatePeaceEvaluation(
  state: GameState,
  fromCountryId: string,
  toCountryId: string,
  terms: PeaceTreatyTerms
): {
  warScore: number;
  treatyCost: number;
  willAiAccept: boolean;
  summaryText: string;
} {
  const myProvs = Object.values(state.provinces).filter((p) => p.controllerId === fromCountryId).length;
  const targetProvs = Object.values(state.provinces).filter((p) => p.controllerId === toCountryId).length;
  const myArmy = Object.values(state.armies)
    .filter((a) => a.countryId === fromCountryId)
    .reduce((s, a) => s + getArmyTotal(a.units), 0);
  const targetArmy = Object.values(state.armies)
    .filter((a) => a.countryId === toCountryId)
    .reduce((s, a) => s + getArmyTotal(a.units), 0);

  const rel = getRelation(state.relations, fromCountryId, toCountryId);
  const warDurationBonus = Math.min(20, Math.max(0, state.day - (rel.warStartDay || state.day)));
  const provScore = Math.max(-45, Math.min(60, (myProvs - targetProvs) * 7));
  const armyRatio = myArmy / Math.max(1, myArmy + targetArmy);
  const armyScore = Math.round((armyRatio - 0.5) * 90);
  const warScore = Math.max(-95, Math.min(100, provScore + armyScore + warDurationBonus));

  let treatyCost = 4; // Base peace baseline
  for (const pid of terms.demandProvinceIds) {
    const p = state.provinces[pid];
    treatyCost += 14 + (p?.buildings.factory || 0) * 2;
  }
  for (const _pid of terms.cedeProvinceIds) {
    treatyCost -= 16;
  }
  if (terms.vassalizeTarget) treatyCost += 35;
  if (terms.becomeVassal) treatyCost -= 55;
  treatyCost += Math.round(terms.demandMoney / 3500);
  treatyCost += Math.round(terms.demandManpower / 1200);

  const willAiAccept = warScore >= treatyCost - 4;
  const summaryText = willAiAccept
    ? 'Şartlar savaş dengesine uygun — Karşı taraf kabul etmeye hazır.'
    : `Talepler çok ağır (Gereken Skor: ${treatyCost}, Mevcut: ${warScore}). Toprak/talep azaltın veya savaşta üstünlük kurun.`;

  return { warScore, treatyCost, willAiAccept, summaryText };
}

// BFS pathfinding across allowed provinces (and naval port crossings if country has transport ships)
export function findProvincePath(
  state: GameState,
  mapData: MapDataStatic,
  countryId: string,
  fromId: string,
  toId: string
): string[] | null {
  if (fromId === toId) return [];
  const provById = new Map(mapData.provinces.map((p) => [p.id, p]));
  const seaById = new Map(mapData.seaZones.map((s) => [s.id, s]));

  // Check if country has transport ships (allows sea-port hopping across allied/contested ports)
  const hasTransport = Object.values(state.fleets).some(
    (f) => f.countryId === countryId && f.ships.some((s) => s.type === 'transport' && s.hp > 0)
  );

  const visited = new Set<string>([fromId]);
  const parent = new Map<string, string>();
  const queue: string[] = [fromId];

  while (queue.length > 0) {
    const cur = queue.shift()!;
    if (cur === toId) {
      const path: string[] = [];
      let step: string | undefined = toId;
      while (step && step !== fromId) {
        path.unshift(step);
        step = parent.get(step);
      }
      return path;
    }

    const staticProv = provById.get(cur);
    if (!staticProv) continue;

    // Land neighbors
    for (const nb of staticProv.neighbors) {
      if (visited.has(nb)) continue;
      if (!canEnterProvince(state, countryId, nb)) continue;
      visited.add(nb);
      parent.set(nb, cur);
      queue.push(nb);
    }

    // Sea port neighbors (if transport ship available and current province is a friendly port)
    if (hasTransport && staticProv.isPort && state.provinces[cur]?.controllerId === countryId) {
      for (const seaId of staticProv.seaNeighbors) {
        const sea = seaById.get(seaId);
        if (!sea) continue;
        // Check adjacent sea zones + ports in same/adjacent sea
        const reachableSeas = [sea, ...sea.neighbors.map((nid) => seaById.get(nid)).filter(Boolean)];
        for (const rSea of reachableSeas) {
          if (!rSea) continue;
          for (const portId of rSea.portProvinces) {
            if (visited.has(portId)) continue;
            if (!canEnterProvince(state, countryId, portId)) continue;
            visited.add(portId);
            parent.set(portId, cur);
            queue.push(portId);
          }
        }
      }
    }
  }

  return null;
}

export function getArmiesInProvince(state: GameState, provinceId: string): Army[] {
  return Object.values(state.armies).filter((a) => a.provinceId === provinceId && getArmyTotal(a.units) > 0);
}

export function canPlayerSeeArmy(
  state: GameState,
  mapData: MapDataStatic,
  playerCountryId: string | null,
  army: Army
): boolean {
  if (!playerCountryId) return true;
  if (army.countryId === playerCountryId) return true;

  if (army.inBattleId) {
    const battle = state.battles[army.inBattleId];
    if (
      battle &&
      (battle.attackerCountryId === playerCountryId ||
        battle.defenderCountryId === playerCountryId)
    ) {
      return true;
    }
  }

  const rel = getRelation(state.relations, playerCountryId, army.countryId);
  if (rel.atWar || rel.allied) return true;

  if (
    state.countries[army.countryId]?.vassalOfId === playerCountryId ||
    state.countries[playerCountryId]?.vassalOfId === army.countryId
  ) {
    return true;
  }

  const playerProvIds = new Set<string>();
  for (const p of Object.values(state.provinces)) {
    if (p.controllerId === playerCountryId) playerProvIds.add(p.id);
  }

  const borderNeighborCountries = new Set<string>();
  for (const mp of mapData.provinces) {
    if (!playerProvIds.has(mp.id)) continue;
    for (const nbId of mp.neighbors) {
      if (nbId === army.provinceId) return true;
      const nbOwner = state.provinces[nbId]?.controllerId;
      if (nbOwner && nbOwner !== playerCountryId) {
        borderNeighborCountries.add(nbOwner);
      }
    }
  }

  return borderNeighborCountries.has(army.countryId);
}

export function canPlayerSeeBattle(
  state: GameState,
  mapData: MapDataStatic,
  playerCountryId: string | null,
  battle: { provinceId: string; fromProvinceId: string; attackerCountryId: string; defenderCountryId: string }
): boolean {
  if (!playerCountryId) return true;
  if (
    battle.attackerCountryId === playerCountryId ||
    battle.defenderCountryId === playerCountryId
  ) {
    return true;
  }

  for (const cid of [battle.attackerCountryId, battle.defenderCountryId]) {
    const rel = getRelation(state.relations, playerCountryId, cid);
    if (rel.atWar || rel.allied) return true;
    if (
      state.countries[cid]?.vassalOfId === playerCountryId ||
      state.countries[playerCountryId]?.vassalOfId === cid
    ) {
      return true;
    }
  }

  const playerProvIds = new Set<string>();
  for (const p of Object.values(state.provinces)) {
    if (p.controllerId === playerCountryId) playerProvIds.add(p.id);
  }
  const borderCountries = new Set<string>();
  for (const mp of mapData.provinces) {
    if (!playerProvIds.has(mp.id)) continue;
    for (const nbId of mp.neighbors) {
      if (nbId === battle.provinceId || nbId === battle.fromProvinceId) return true;
      const nbOwner = state.provinces[nbId]?.controllerId;
      if (nbOwner && nbOwner !== playerCountryId) borderCountries.add(nbOwner);
    }
  }
  return (
    borderCountries.has(battle.attackerCountryId) ||
    borderCountries.has(battle.defenderCountryId)
  );
}

export function autoMergeStationaryArmies(
  state: GameState,
  countryId: string,
  provinceId: string,
  preferredPrimaryId?: string
): Army | null {
  const candidates = Object.values(state.armies).filter(
    (a) =>
      a.countryId === countryId &&
      a.provinceId === provinceId &&
      !a.inBattleId &&
      a.path.length === 0 &&
      getArmyTotal(a.units) > 0
  );
  if (candidates.length === 0) return null;
  if (candidates.length === 1) return candidates[0];

  candidates.sort((a, b) => {
    const aHasCmd = a.commanderId ? 1 : 0;
    const bHasCmd = b.commanderId ? 1 : 0;
    if (aHasCmd !== bHasCmd) return bHasCmd - aHasCmd;
    if (preferredPrimaryId) {
      if (a.id === preferredPrimaryId && b.id !== preferredPrimaryId) return -1;
      if (b.id === preferredPrimaryId && a.id !== preferredPrimaryId) return 1;
    }
    return getArmyTotal(b.units) - getArmyTotal(a.units);
  });

  const primary = candidates[0];
  const country = state.countries[countryId];
  let totalStr = getArmyTotal(primary.units);
  let expSum = primary.experience * totalStr;
  let moraleSum = primary.morale * totalStr;
  let supplySum = primary.supply * totalStr;

  for (let i = 1; i < candidates.length; i++) {
    const sec = candidates[i];
    const secStr = getArmyTotal(sec.units);
    primary.units.infantry += sec.units.infantry;
    primary.units.tank += sec.units.tank;
    primary.units.antitank += sec.units.antitank;
    primary.units.artillery += sec.units.artillery;
    primary.units.motorized += sec.units.motorized;
    primary.units.antiair += sec.units.antiair;

    totalStr += secStr;
    expSum += sec.experience * secStr;
    moraleSum += sec.morale * secStr;
    supplySum += sec.supply * secStr;

    if (sec.commanderId && country?.commanders[sec.commanderId]) {
      if (!primary.commanderId) {
        primary.commanderId = sec.commanderId;
        country.commanders[sec.commanderId].assignedArmyId = primary.id;
      } else {
        country.commanders[sec.commanderId].assignedArmyId = null;
      }
    }
    delete state.armies[sec.id];
  }

  if (totalStr > 0) {
    primary.experience = Math.min(100, expSum / totalStr);
    primary.morale = Math.min(100, moraleSum / totalStr);
    primary.supply = Math.min(100, supplySum / totalStr);
  }
  return primary;
}



