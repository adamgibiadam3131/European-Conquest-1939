import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import rawMapData from './shared/data/mapData.json';
import type {
  ClientAction,
  DifficultyLevel,
  GameSpeed,
  GameState,
  MapDataStatic,
  MapMode,
  RoomLobbyState,
} from './shared/types.ts';
import { SCENARIOS } from './shared/data/scenarios.ts';
import { canEnterProvince, findProvincePath, getArmyTotal, getRelation } from './shared/utils/gameHelpers.ts';
import { PhaserMapCanvas } from './client/map/PhaserMapCanvas.tsx';
import type { StrategyMapScene } from './client/map/StrategyMapScene.ts';
import {
  createRoomApi,
  GameSocketClient,
  getLocalSave,
  getOrCreatePlayerId,
} from './client/network/GameClient.ts';
import {
  P2PGuestController,
  P2PHostController,
  type P2PClientTransport,
  type TransportCallbacks,
} from './client/network/P2PTransport.ts';
import { SoundEngine } from './client/audio/SoundEngine.ts';
import { TitleLobbyScreen } from './client/components/TitleLobbyScreen.tsx';
import { TopBar } from './client/components/TopBar.tsx';
import { SideMenus, type ActivePanelId } from './client/components/SideMenus.tsx';
import { ArmyPanel } from './client/components/panels/ArmyPanel.tsx';
import { ResearchPanel } from './client/components/panels/ResearchPanel.tsx';
import { GovernmentPanel } from './client/components/panels/GovernmentPanel.tsx';
import { DiplomacyPanel } from './client/components/panels/DiplomacyPanel.tsx';
import { ProductionPanel } from './client/components/panels/ProductionPanel.tsx';
import { AirForcePanel } from './client/components/panels/AirForcePanel.tsx';
import { NavyPanel } from './client/components/panels/NavyPanel.tsx';
import {
  BattlesPanel,
  LeaderboardPanel,
} from './client/components/panels/BattlesLeaderboardPanels.tsx';
import { ProvinceDrawer } from './client/components/ProvinceDrawer.tsx';
import { ArmyDetailModal } from './client/components/ArmyDetailModal.tsx';
import { BattleModal } from './client/components/BattleModal.tsx';
import { VictoryModal } from './client/components/VictoryModal.tsx';
import { TutorialOverlay } from './client/components/TutorialOverlay.tsx';
import { ArmyHotbar } from './client/components/ArmyHotbar.tsx';
import { PeaceTreatyModal } from './client/components/PeaceTreatyModal.tsx';
import { COUNTRIES } from './shared/data/countries.ts';
import { formatCompact } from './shared/utils/gameHelpers.ts';

const MAP_DATA = rawMapData as unknown as MapDataStatic;

export default function App() {
  const playerId = useMemo(() => getOrCreatePlayerId(), []);
  const [playerName, setPlayerName] = useState<string>(
    () => localStorage.getItem('ec1939_player_name') || 'Başkomutan'
  );
  const [lobby, setLobby] = useState<RoomLobbyState | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [connected, setConnected] = useState(false);
  const [transportMode, setTransportMode] = useState<'ws' | 'p2p' | 'local'>('ws');
  const [isJoiningP2P, setIsJoiningP2P] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const [selectedLobbyCountryId, setSelectedLobbyCountryId] = useState<string>('TUR');
  const [lobbyScenarioId, setLobbyScenarioId] = useState<'1939_alt' | '1939_hist'>('1939_alt');

  const [activePanel, setActivePanel] = useState<ActivePanelId>(null);
  const [mapMode, setMapMode] = useState<MapMode>('political');
  const [selectedProvinceId, setSelectedProvinceId] = useState<string | null>(null);
  const [selectedArmyId, setSelectedArmyId] = useState<string | null>(null);
  const [armedArmyId, setArmedArmyId] = useState<string | null>(null);
  const [targetingArmyId, setTargetingArmyId] = useState<string | null>(null);
  const [selectedBattleId, setSelectedBattleId] = useState<string | null>(null);
  const [peaceTargetId, setPeaceTargetId] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);

  const sceneRef = useRef<StrategyMapScene | null>(null);
  const socketRef = useRef<GameSocketClient | null>(null);
  const p2pRef = useRef<P2PClientTransport | null>(null);
  const prevNotifIdRef = useRef<string | null>(null);
  const autoJoinedRef = useRef(false);

  useEffect(() => {
    localStorage.setItem('ec1939_player_name', playerName);
  }, [playerName]);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => {
      setToastMsg((cur) => (cur === msg ? null : cur));
    }, 3200);
  }, []);

  const transportCallbacks = useMemo<TransportCallbacks>(
    () => ({
      onConnectionChange: (ok) => setConnected(ok),
      onError: (msg) => {
        setIsJoiningP2P(false);
        setErrorMsg(msg);
        showToast(msg);
      },
      onSaveConfirmed: (slotName) => {
        SoundEngine.playResearchDone();
        showToast(`Oyun kaydedildi: ${slotName}`);
      },
      onSync: (nextLobby, nextState) => {
        setIsJoiningP2P(false);
        setLobby(nextLobby);
        setGameState(nextState);
        setErrorMsg(null);

        if (nextState) {
          const latest = nextState.notifications[0];
          if (latest && latest.id !== prevNotifIdRef.current) {
            prevNotifIdRef.current = latest.id;
            if (latest.type === 'war') SoundEngine.playWarDeclared();
            else if (latest.type === 'research') SoundEngine.playResearchDone();
            showToast(`${latest.title} — ${latest.message}`);
          }
          if (nextState.victory) {
            SoundEngine.playVictory();
          }
        }
      },
    }),
    [showToast]
  );

  // Initialize persistent WebSocket client
  useEffect(() => {
    const client = new GameSocketClient(playerId, playerName);
    client.onConnectionChange = transportCallbacks.onConnectionChange;
    client.onError = transportCallbacks.onError;
    client.onSaveConfirmed = transportCallbacks.onSaveConfirmed;
    client.onSync = transportCallbacks.onSync;

    socketRef.current = client;
    return () => {
      client.disconnect();
      p2pRef.current?.disconnect();
      p2pRef.current = null;
    };
  }, [playerId, transportCallbacks]);

  // Show beginner tutorial once on first game start
  useEffect(() => {
    if (gameState && !localStorage.getItem('ec1939_tutorial_seen')) {
      localStorage.setItem('ec1939_tutorial_seen', '1');
      setShowTutorial(true);
    }
  }, [gameState]);

  const myLobbyPlayer = lobby?.players.find((p) => p.playerId === playerId) || null;
  const playerCountryId = myLobbyPlayer?.countryId || null;
  const isHost = Boolean(myLobbyPlayer?.isHost);

  const sendAction = useCallback((action: ClientAction) => {
    SoundEngine.playClick();
    if (p2pRef.current) {
      p2pRef.current.sendAction(action);
    } else {
      socketRef.current?.sendAction(action);
    }
  }, []);

  // Keyboard shortcuts during gameplay
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (!gameState) return;

      if (e.code === 'Space') {
        e.preventDefault();
        if (gameState.mode === 'singleplayer' || isHost) {
          sendAction({ type: 'SET_PAUSE', paused: !gameState.paused });
        }
      } else if (e.code === 'Escape') {
        if (peaceTargetId) setPeaceTargetId(null);
        else if (targetingArmyId) setTargetingArmyId(null);
        else if (selectedBattleId) setSelectedBattleId(null);
        else if (activePanel) setActivePanel(null);
        else if (selectedArmyId) setSelectedArmyId(null);
        else if (armedArmyId) setArmedArmyId(null);
        else if (selectedProvinceId) setSelectedProvinceId(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    gameState,
    isHost,
    peaceTargetId,
    targetingArmyId,
    selectedBattleId,
    activePanel,
    selectedArmyId,
    armedArmyId,
    selectedProvinceId,
    sendAction,
  ]);

  const disconnectAllTransports = useCallback(() => {
    p2pRef.current?.disconnect();
    p2pRef.current = null;
    socketRef.current?.disconnect();
  }, []);

  const handleStartSingleplayer = async (opts: {
    countryId: string;
    scenarioId: '1939_alt' | '1939_hist';
    difficulty: DifficultyLevel;
    victoryThreshold: 75 | 80;
  }) => {
    disconnectAllTransports();
    setErrorMsg(null);
    setTransportMode('local');
    const localHost = new P2PHostController({
      mode: 'singleplayer',
      enableNetworkP2P: false,
      playerId,
      playerName,
      scenarioId: opts.scenarioId,
      difficulty: opts.difficulty,
      victoryThreshold: opts.victoryThreshold,
      maxHumanPlayers: 1,
      countryId: opts.countryId,
      mapData: MAP_DATA,
      callbacks: transportCallbacks,
    });
    p2pRef.current = localHost;
    localHost.sendAction({ type: 'START_GAME' });
  };

  const handleCreateMultiplayer = async (opts: {
    scenarioId: '1939_alt' | '1939_hist';
    difficulty: DifficultyLevel;
    victoryThreshold: 75 | 80;
    maxHumanPlayers: number;
    useServerWs?: boolean;
  }) => {
    disconnectAllTransports();
    setErrorMsg(null);
    if (opts.useServerWs) {
      try {
        setTransportMode('ws');
        const { lobby: created } = await createRoomApi({
          mode: 'multiplayer',
          playerId,
          playerName,
          scenarioId: opts.scenarioId,
          difficulty: opts.difficulty,
          victoryThreshold: opts.victoryThreshold,
          maxHumanPlayers: opts.maxHumanPlayers,
        });
        socketRef.current?.connect(created.roomCode, playerName);
      } catch (err) {
        setErrorMsg((err as Error).message);
      }
      return;
    }

    setTransportMode('p2p');
    setConnected(false);
    const p2pHost = new P2PHostController({
      mode: 'multiplayer',
      enableNetworkP2P: true,
      playerId,
      playerName,
      scenarioId: opts.scenarioId,
      difficulty: opts.difficulty,
      victoryThreshold: opts.victoryThreshold,
      maxHumanPlayers: opts.maxHumanPlayers,
      mapData: MAP_DATA,
      callbacks: transportCallbacks,
    });
    p2pRef.current = p2pHost;
  };

  const handleJoinMultiplayer = useCallback(
    (code: string, useServerWs = false) => {
      const clean = code.trim().toUpperCase();
      if (!clean) return;
      disconnectAllTransports();
      setErrorMsg(null);
      if (useServerWs) {
        setTransportMode('ws');
        socketRef.current?.connect(clean, playerName);
        return;
      }
      setTransportMode('p2p');
      setConnected(false);
      setIsJoiningP2P(true);
      p2pRef.current = new P2PGuestController({
        roomCode: clean,
        playerId,
        playerName,
        callbacks: transportCallbacks,
      });
    },
    [disconnectAllTransports, playerId, playerName, transportCallbacks]
  );

  // Auto-join when opened via ?p2p=CODE or ?room=CODE invite URL
  useEffect(() => {
    if (autoJoinedRef.current) return;
    const params = new URLSearchParams(window.location.search);
    const p2pCode = params.get('p2p');
    const wsCode = params.get('room');
    if (p2pCode) {
      autoJoinedRef.current = true;
      handleJoinMultiplayer(p2pCode, false);
    } else if (wsCode) {
      autoJoinedRef.current = true;
      handleJoinMultiplayer(wsCode, true);
    }
  }, [handleJoinMultiplayer]);

  const handleLoadSave = async (slotId: string) => {
    disconnectAllTransports();
    setErrorMsg(null);
    const localRec = getLocalSave(slotId);
    if (localRec) {
      const isMp = localRec.mode === 'multiplayer';
      setTransportMode(isMp ? 'p2p' : 'local');
      p2pRef.current = new P2PHostController({
        mode: localRec.mode,
        enableNetworkP2P: isMp,
        playerId,
        playerName,
        scenarioId: (localRec.state.scenarioId as '1939_alt' | '1939_hist') || '1939_alt',
        difficulty: localRec.state.difficulty,
        victoryThreshold: localRec.state.victoryThreshold,
        maxHumanPlayers: isMp ? 5 : 1,
        loadedState: localRec.state,
        mapData: MAP_DATA,
        callbacks: transportCallbacks,
      });
      return;
    }

    try {
      setTransportMode('ws');
      const { lobby: created } = await createRoomApi({
        mode: 'singleplayer',
        playerId,
        playerName,
        loadSlotId: slotId,
      });
      socketRef.current?.connect(created.roomCode, playerName);
    } catch (err) {
      setErrorMsg((err as Error).message);
    }
  };

  const handleExitToMenu = () => {
    disconnectAllTransports();
    setIsJoiningP2P(false);
    setLobby(null);
    setGameState(null);
    setActivePanel(null);
    setSelectedProvinceId(null);
    setSelectedArmyId(null);
    setArmedArmyId(null);
    setTargetingArmyId(null);
    setSelectedBattleId(null);
    sceneRef.current?.resetCamera();
  };

  const issueArmyMarch = useCallback(
    (armyId: string, targetProvId: string) => {
      if (!gameState || !playerCountryId) return false;
      const army = gameState.armies[armyId];
      if (!army || army.countryId !== playerCountryId) return false;
      if (army.inBattleId) {
        showToast('Bu ordu şu an aktif bir muharebede!');
        return false;
      }
      if (!canEnterProvince(gameState, playerCountryId, targetProvId)) {
        showToast('Bu toprağa ilerlemek için önce Diplomasi ekranından savaş ilan etmelisiniz.');
        return false;
      }
      const path = findProvincePath(gameState, MAP_DATA, playerCountryId, army.provinceId, targetProvId);
      if (!path || path.length === 0) {
        showToast('Ulaşılabilir kara veya liman rotası bulunamadı (denizaşırı için Taşıma Gemisi gerekir).');
        return false;
      }

      const targetProvOwner = gameState.provinces[targetProvId]?.controllerId;
      const isWarTarget =
        targetProvOwner &&
        targetProvOwner !== playerCountryId &&
        getRelation(gameState.relations, playerCountryId, targetProvOwner).atWar;

      SoundEngine.playMarchOrder();
      if (p2pRef.current) {
        p2pRef.current.sendAction({
          type: 'MOVE_ARMY',
          armyId,
          targetProvinceId: targetProvId,
        });
      } else {
        socketRef.current?.sendAction({
          type: 'MOVE_ARMY',
          armyId,
          targetProvinceId: targetProvId,
        });
      }
      sceneRef.current?.spawnProvincePing(targetProvId, isWarTarget ? 0xef4444 : 0x38bdf8, 52);

      const provName = MAP_DATA.provinces.find((p) => p.id === targetProvId)?.name || targetProvId;
      showToast(
        isWarTarget
          ? `⚔️ ${army.name} (${getArmyTotal(army.units)}K) → ${provName} cephesine ilerliyor!`
          : `➜ ${army.name} → ${provName} bölgesine hareket ediyor.`
      );
      return true;
    },
    [gameState, playerCountryId, showToast]
  );

  const mapCallbacks = useMemo(
    () => ({
      onSelectProvince: (provId: string) => {
        if (!gameState) {
          // Clicking map in lobby selects that country
          const mp = MAP_DATA.provinces.find((p) => p.id === provId);
          if (mp) {
            const owner =
              SCENARIOS[lobbyScenarioId]?.provinceOwnerOverrides[mp.id] || mp.countryId;
            setSelectedLobbyCountryId(owner);
            if (lobby && lobby.status === 'lobby') {
              sendAction({ type: 'SELECT_COUNTRY', countryId: owner });
            }
          }
          return;
        }

        // 1. Explicit clicked army / targeting army: clicking ANY reachable own, allied, or war city marches there directly!
        const explicitArmyId =
          targetingArmyId ||
          (selectedArmyId && gameState.armies[selectedArmyId]?.countryId === playerCountryId
            ? selectedArmyId
            : null);

        if (explicitArmyId && playerCountryId && gameState.armies[explicitArmyId]) {
          const activeArmy = gameState.armies[explicitArmyId];
          if (activeArmy.provinceId !== provId) {
            if (canEnterProvince(gameState, playerCountryId, provId)) {
              issueArmyMarch(explicitArmyId, provId);
              if (targetingArmyId) setTargetingArmyId(null);
              return;
            }
            if (targetingArmyId) {
              issueArmyMarch(explicitArmyId, provId);
              setTargetingArmyId(null);
              return;
            }
            // Clicked a peaceful neutral province -> stop army move selection and inspect that country
            setSelectedArmyId(null);
            setArmedArmyId(null);
          }
        }

        // 2. Passive garrison quick-attack when an army in a clicked city is armed
        if (armedArmyId && playerCountryId && gameState.armies[armedArmyId]) {
          const armedArmy = gameState.armies[armedArmyId];
          const targetOwner = gameState.provinces[provId]?.controllerId;
          const isEnemyAtWar =
            targetOwner &&
            targetOwner !== playerCountryId &&
            getRelation(gameState.relations, playerCountryId, targetOwner).atWar;

          if (isEnemyAtWar && armedArmy.provinceId !== provId) {
            issueArmyMarch(armedArmyId, provId);
            return;
          }
        }

        SoundEngine.playClick();
        setSelectedProvinceId(provId);

        // Clicking your own city that has friendly army(ies) passively arms the strongest ready army
        if (playerCountryId) {
          const readyArmiesHere = Object.values(gameState.armies)
            .filter(
              (a) =>
                a.countryId === playerCountryId &&
                a.provinceId === provId &&
                !a.inBattleId &&
                getArmyTotal(a.units) > 0
            )
            .sort((a, b) => getArmyTotal(b.units) - getArmyTotal(a.units));

          if (readyArmiesHere.length > 0) {
            setArmedArmyId(readyArmiesHere[0].id);
          } else if (gameState.provinces[provId]?.controllerId !== playerCountryId) {
            setArmedArmyId(null);
          }
        }
      },
      onRightClickProvince: (provId: string) => {
        if (!gameState || !playerCountryId) return;
        const activeArmy = targetingArmyId || armedArmyId || selectedArmyId;
        if (activeArmy) {
          issueArmyMarch(activeArmy, provId);
        }
      },
      onSelectArmy: (armyId: string) => {
        SoundEngine.playClick();
        setSelectedArmyId(armyId);
        if (gameState?.armies[armyId]?.countryId === playerCountryId) {
          setArmedArmyId(armyId);
        }
        setTargetingArmyId(null);
      },
      onSelectBattle: (battleId: string) => {
        SoundEngine.playClick();
        setSelectedBattleId(battleId);
      },
      onSelectSeaZone: (seaZoneId: string) => {
        if (gameState) {
          const sz = MAP_DATA.seaZones.find((s) => s.id === seaZoneId);
          if (sz) showToast(`${sz.name} — Deniz Bölgesi`);
        }
      },
      onTargetProvinceChosen: (targetProvId: string) => {
        if (!targetingArmyId) return;
        issueArmyMarch(targetingArmyId, targetProvId);
        setTargetingArmyId(null);
      },
    }),
    [gameState, lobby, lobbyScenarioId, armedArmyId, targetingArmyId, selectedArmyId, playerCountryId, issueArmyMarch, showToast]
  );

  const playerCountryState =
    gameState && playerCountryId ? gameState.countries[playerCountryId] : null;
  const hasAvailableResearch = Boolean(
    playerCountryState &&
      playerCountryState.activeResearch.length < playerCountryState.maxResearchSlots
  );

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950">
      {/* Persistent Phaser 2D Strategy Map */}
      <PhaserMapCanvas
        mapData={MAP_DATA}
        gameState={gameState}
        playerCountryId={playerCountryId}
        mapMode={mapMode}
        selectedProvinceId={selectedProvinceId}
        selectedArmyId={selectedArmyId || armedArmyId}
        targetingArmyId={targetingArmyId}
        highlightOwnTargets={Boolean(
          targetingArmyId ||
            (selectedArmyId && gameState?.armies[selectedArmyId]?.countryId === playerCountryId)
        )}
        lobbyScenarioId={lobbyScenarioId}
        isLobbyPan={!gameState}
        callbacks={mapCallbacks}
        sceneRefOut={sceneRef}
      />

      {/* Title & Multiplayer Lobby Overlay */}
      {!gameState && (
        <TitleLobbyScreen
          lobby={lobby}
          playerId={playerId}
          playerName={playerName}
          onChangePlayerName={setPlayerName}
          selectedLobbyCountryId={selectedLobbyCountryId}
          onSelectLobbyCountryId={setSelectedLobbyCountryId}
          lobbyScenarioId={lobbyScenarioId}
          onChangeScenarioId={setLobbyScenarioId}
          connected={connected}
          transportMode={transportMode}
          isJoiningP2P={isJoiningP2P}
          onStartSingleplayer={handleStartSingleplayer}
          onCreateMultiplayerRoom={handleCreateMultiplayer}
          onJoinMultiplayerRoom={handleJoinMultiplayer}
          onLoadSavedGame={handleLoadSave}
          onLobbySelectCountry={(cid) => sendAction({ type: 'SELECT_COUNTRY', countryId: cid })}
          onLobbyToggleReady={() => sendAction({ type: 'TOGGLE_READY' })}
          onLobbyStartGame={() => sendAction({ type: 'START_GAME' })}
          onLeaveLobby={handleExitToMenu}
          errorMessage={errorMsg}
        />
      )}

      {/* Active Gameplay HUD */}
      {gameState && (
        <>
          <TopBar
            state={gameState}
            playerCountryId={playerCountryId}
            isHost={isHost}
            connected={connected}
            muted={muted}
            onTogglePause={() => sendAction({ type: 'SET_PAUSE', paused: !gameState.paused })}
            onSetSpeed={(spd: GameSpeed) => sendAction({ type: 'SET_SPEED', speed: spd })}
            onSaveGame={() => {
              const label = `${playerCountryId || 'Oyun'} - Gün ${gameState.day}`;
              sendAction({ type: 'SAVE_GAME', slotName: label });
            }}
            onToggleMute={() => {
              const next = !muted;
              setMuted(next);
              SoundEngine.setMuted(next);
            }}
            onOpenTutorial={() => setShowTutorial(true)}
            onOpenLeaderboard={() => setActivePanel(activePanel === 'leaderboard' ? null : 'leaderboard')}
          />

          <SideMenus
            activePanel={activePanel}
            onSelectPanel={(p) => {
              SoundEngine.playClick();
              setActivePanel(p);
            }}
            mapMode={mapMode}
            onChangeMapMode={setMapMode}
            onZoomIn={() => sceneRef.current?.zoomStep(1.22)}
            onZoomOut={() => sceneRef.current?.zoomStep(0.82)}
            onResetCam={() => sceneRef.current?.resetCamera()}
            onOpenTutorial={() => setShowTutorial(true)}
            onExitGame={handleExitToMenu}
            activeBattleCount={Object.keys(gameState.battles).length}
            hasAvailableResearch={hasAvailableResearch}
          />

          {/* Bottom-Center Screenshot-Matched Army Command Hotbar */}
          {playerCountryId && !activePanel && (
            <ArmyHotbar
              state={gameState}
              mapData={MAP_DATA}
              playerCountryId={playerCountryId}
              selectedArmyId={selectedArmyId || armedArmyId}
              onSelectArmy={(aid, provId) => {
                SoundEngine.playClick();
                setSelectedArmyId(aid);
                setArmedArmyId(aid);
                setTargetingArmyId(null);
                setSelectedProvinceId(null);
                sceneRef.current?.focusProvince(provId);
              }}
              onOpenArmyPanel={() => {
                SoundEngine.playClick();
                setActivePanel('army');
              }}
            />
          )}

          {/* Multiplayer Room Badge */}
          {lobby && lobby.mode === 'multiplayer' && (
            <div className="fixed top-16 left-18 z-20 px-3 py-1.5 rounded-full hud-pill text-xs text-slate-200 flex items-center gap-2">
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-600/30 border border-emerald-500/50 text-emerald-300">
                {transportMode === 'p2p' ? 'P2P' : 'WS'}
              </span>
              <span className="text-slate-400">Oda:</span>
              <span className="font-mono-num font-bold text-amber-300">{lobby.roomCode}</span>
              <span className="text-slate-400">
                · {lobby.players.filter((p) => p.connected).length}/{lobby.players.length} Aktif
              </span>
            </div>
          )}

          {/* Armed / Targeting Banner */}
          {(targetingArmyId ||
            (selectedArmyId && gameState.armies[selectedArmyId]?.countryId === playerCountryId) ||
            (armedArmyId && gameState.armies[armedArmyId])) &&
            !activePanel && (
              <div className="animate-banner-in fixed top-16 left-1/2 -translate-x-1/2 z-30 px-4 py-1.5 rounded-full hud-pill text-xs font-bold flex items-center gap-3">
                <span className="text-amber-300 hud-text-shadow">
                  {targetingArmyId
                    ? 'Hedef seçmek için haritadaki bir bölgeye tıklayın'
                    : selectedArmyId && gameState.armies[selectedArmyId]?.countryId === playerCountryId
                    ? `⚔️ ${gameState.armies[selectedArmyId]!.name} (${getArmyTotal(gameState.armies[selectedArmyId]!.units)}K) seçili — Kendi şehirlerinize, müttefiklere veya savaş topraklarına tıklayarak yürütün`
                    : `⚔️ ${gameState.armies[armedArmyId!]?.name} (${getArmyTotal(gameState.armies[armedArmyId!]!.units)}K) hazır — Sağ tıkla yürüt veya savaş toprağına tıkla`}
                </span>
                <button
                  onClick={() => {
                    setTargetingArmyId(null);
                    setSelectedArmyId(null);
                    setArmedArmyId(null);
                  }}
                  className="px-2 py-0.5 rounded-full bg-slate-950/70 hover:bg-slate-950 text-slate-200 text-[11px]"
                >
                  İptal
                </button>
              </div>
            )}

          {/* Live Event Notification Banner */}
          {toastMsg && (
            <div className="animate-banner-in fixed bottom-26 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-full hud-pill text-xs font-bold text-sky-100 pointer-events-none">
              {toastMsg}
            </div>
          )}

          {/* Active Strategy Panels */}
          {playerCountryId && activePanel === 'army' && (
            <ArmyPanel
              state={gameState}
              mapData={MAP_DATA}
              playerCountryId={playerCountryId}
              onAction={sendAction}
              onClose={() => setActivePanel(null)}
            />
          )}

          {playerCountryId && activePanel === 'research' && (
            <ResearchPanel
              state={gameState}
              playerCountryId={playerCountryId}
              onAction={sendAction}
              onClose={() => setActivePanel(null)}
            />
          )}

          {playerCountryId && activePanel === 'government' && (
            <GovernmentPanel
              state={gameState}
              playerCountryId={playerCountryId}
              onAction={sendAction}
              onClose={() => setActivePanel(null)}
            />
          )}

          {playerCountryId && activePanel === 'diplomacy' && (
            <DiplomacyPanel
              state={gameState}
              playerCountryId={playerCountryId}
              onAction={sendAction}
              onOpenPeaceModal={(tid) => {
                setActivePanel(null);
                setPeaceTargetId(tid);
              }}
              onClose={() => setActivePanel(null)}
            />
          )}

          {playerCountryId && activePanel === 'production' && (
            <ProductionPanel
              state={gameState}
              playerCountryId={playerCountryId}
              onAction={sendAction}
              onClose={() => setActivePanel(null)}
            />
          )}

          {playerCountryId && activePanel === 'air' && (
            <AirForcePanel
              state={gameState}
              mapData={MAP_DATA}
              playerCountryId={playerCountryId}
              onAction={sendAction}
              onClose={() => setActivePanel(null)}
            />
          )}

          {playerCountryId && activePanel === 'navy' && (
            <NavyPanel
              state={gameState}
              mapData={MAP_DATA}
              playerCountryId={playerCountryId}
              onAction={sendAction}
              onClose={() => setActivePanel(null)}
            />
          )}

          {activePanel === 'battles' && (
            <BattlesPanel
              state={gameState}
              mapData={MAP_DATA}
              onSelectBattle={(bid) => {
                setActivePanel(null);
                setSelectedBattleId(bid);
              }}
              onClose={() => setActivePanel(null)}
            />
          )}

          {activePanel === 'leaderboard' && (
            <LeaderboardPanel
              state={gameState}
              mapData={MAP_DATA}
              onClose={() => setActivePanel(null)}
            />
          )}

          {/* Province Inspector Drawer */}
          {selectedProvinceId && !activePanel && (
            <ProvinceDrawer
              provinceId={selectedProvinceId}
              state={gameState}
              mapData={MAP_DATA}
              playerCountryId={playerCountryId}
              selectedArmyId={armedArmyId || selectedArmyId}
              onMarchSelectedArmy={(targetProvId) => {
                const aid = armedArmyId || selectedArmyId;
                if (aid) issueArmyMarch(aid, targetProvId);
              }}
              onAction={sendAction}
              onSelectArmy={(aid) => {
                setArmedArmyId(aid);
                setSelectedArmyId(aid);
              }}
              onClose={() => setSelectedProvinceId(null)}
            />
          )}

          {/* Army Detail Modal */}
          {selectedArmyId && gameState.armies[selectedArmyId] && (
            <ArmyDetailModal
              armyId={selectedArmyId}
              state={gameState}
              mapData={MAP_DATA}
              playerCountryId={playerCountryId}
              isTargeting={targetingArmyId === selectedArmyId}
              onStartTargeting={(aid) => setTargetingArmyId(aid)}
              onCancelTargeting={() => setTargetingArmyId(null)}
              onAction={sendAction}
              onClose={() => {
                setSelectedArmyId(null);
                setTargetingArmyId(null);
              }}
            />
          )}

          {/* Active Battle Modal */}
          {selectedBattleId && gameState.battles[selectedBattleId] && (
            <BattleModal
              battleId={selectedBattleId}
              state={gameState}
              mapData={MAP_DATA}
              onClose={() => setSelectedBattleId(null)}
            />
          )}

          {/* Peace Treaty Negotiation Modal */}
          {playerCountryId && peaceTargetId && gameState.countries[peaceTargetId] && (
            <PeaceTreatyModal
              state={gameState}
              mapData={MAP_DATA}
              playerCountryId={playerCountryId}
              targetCountryId={peaceTargetId}
              onSubmit={(terms) =>
                sendAction({
                  type: 'SEND_PEACE_OFFER',
                  targetCountryId: peaceTargetId,
                  terms,
                })
              }
              onClose={() => setPeaceTargetId(null)}
            />
          )}

          {/* Incoming Human Peace Offer Prompt (Multiplayer) */}
          {playerCountryId &&
            (() => {
              const incomingOffer = (gameState.peaceOffers || []).find(
                (o) => o.toCountryId === playerCountryId
              );
              if (!incomingOffer) return null;
              const senderName = COUNTRIES[incomingOffer.fromCountryId]?.name || incomingOffer.fromCountryId;
              return (
                <div className="fixed bottom-24 right-5 z-50 w-[360px] max-w-[calc(100vw-2rem)] p-4 rounded-2xl bg-[#1e2636]/96 border-2 border-amber-400 shadow-2xl space-y-2.5 text-xs">
                  <div className="font-display text-lg font-bold text-amber-300">
                    📜 Barış Teklifi: {senderName}
                  </div>
                  <div className="space-y-1 text-slate-200">
                    {incomingOffer.terms.demandProvinceIds.length > 0 && (
                      <div>• İstenen Toprak: {incomingOffer.terms.demandProvinceIds.length} eyalet</div>
                    )}
                    {incomingOffer.terms.cedeProvinceIds.length > 0 && (
                      <div>• Teklif Edilen Toprak: {incomingOffer.terms.cedeProvinceIds.length} eyalet</div>
                    )}
                    {incomingOffer.terms.vassalizeTarget && (
                      <div className="text-rose-300 font-semibold">• Vasal olma şartı içeriyor</div>
                    )}
                    {incomingOffer.terms.becomeVassal && (
                      <div className="text-emerald-300 font-semibold">• Rakip sizin vasalınız olacak</div>
                    )}
                    {incomingOffer.terms.demandMoney > 0 && (
                      <div>• İstenen Para: {formatCompact(incomingOffer.terms.demandMoney)}</div>
                    )}
                    {incomingOffer.terms.demandManpower > 0 && (
                      <div>• İstenen İnsangücü: {formatCompact(incomingOffer.terms.demandManpower)}</div>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() =>
                        sendAction({ type: 'RESPOND_PEACE_OFFER', offerId: incomingOffer.id, accept: true })
                      }
                      className="py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                    >
                      Kabul Et
                    </button>
                    <button
                      onClick={() =>
                        sendAction({ type: 'RESPOND_PEACE_OFFER', offerId: incomingOffer.id, accept: false })
                      }
                      className="py-2 rounded-xl bg-rose-700 hover:bg-rose-600 text-white font-bold"
                    >
                      Reddet
                    </button>
                  </div>
                </div>
              );
            })()}

          {/* Victory / Game End Modal */}
          {gameState.victory && (
            <VictoryModal victory={gameState.victory} onReturnToMenu={handleExitToMenu} />
          )}

          {/* Beginner Tutorial */}
          {showTutorial && <TutorialOverlay onClose={() => setShowTutorial(false)} />}
        </>
      )}
    </div>
  );
}
