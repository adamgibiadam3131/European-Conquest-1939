import express from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer } from 'ws';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { RoomManager } from './server/rooms/RoomManager.ts';
import { SaveStore } from './server/storage/SaveStore.ts';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';

async function bootstrap() {
  const app = express();
  app.use(express.json({ limit: '5mb' }));

  const roomManager = new RoomManager();

  // REST API Endpoints
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, name: 'European Conquest 1939', version: '1.0.0' });
  });

  app.get('/api/saves', (_req, res) => {
    res.json({ saves: SaveStore.listSaves() });
  });

  app.delete('/api/saves/:slotId', (req, res) => {
    const deleted = SaveStore.deleteSave(req.params.slotId);
    res.json({ ok: deleted });
  });

  app.post('/api/rooms', (req, res) => {
    const {
      mode = 'singleplayer',
      playerId,
      playerName,
      scenarioId,
      difficulty,
      victoryThreshold,
      maxHumanPlayers,
      countryId,
      loadSlotId,
    } = req.body || {};

    if (!playerId) {
      res.status(400).json({ error: 'playerId gerekli' });
      return;
    }

    let loadedState = undefined;
    if (loadSlotId) {
      const loaded = SaveStore.loadGame(loadSlotId);
      if (!loaded) {
        res.status(404).json({ error: 'Kayıt dosyası bulunamadı.' });
        return;
      }
      loadedState = loaded.state;
    }

    const lobby = roomManager.createRoom({
      mode: mode === 'multiplayer' ? 'multiplayer' : 'singleplayer',
      playerId,
      playerName: playerName || 'Komutan',
      scenarioId,
      difficulty,
      victoryThreshold,
      maxHumanPlayers,
      countryId,
      loadedState,
    });

    res.json({ lobby });
  });

  app.get('/api/rooms/:code', (req, res) => {
    const room = roomManager.getRoomByCode(req.params.code);
    if (!room) {
      res.status(404).json({ error: 'Oda bulunamadı.' });
      return;
    }
    res.json({ lobby: room.lobby });
  });

  // Mount Vite middleware in dev, or serve static dist in production
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = http.createServer(app);

  // WebSocket Server on /ws path (never collides with Vite)
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    let boundRoomId: string | null = null;
    let boundPlayerId: string | null = null;

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === 'JOIN_ROOM') {
          const { roomCode, playerId, playerName } = msg;
          const room = roomManager.getRoomByCode(roomCode);
          if (!room) {
            ws.send(JSON.stringify({ type: 'ERROR', message: 'Oda bulunamadı.' }));
            return;
          }
          const result = roomManager.joinConnection(roomCode, playerId, playerName, ws);
          if (!result.ok) {
            ws.send(JSON.stringify({ type: 'ERROR', message: result.error }));
            return;
          }
          boundRoomId = room.lobby.roomId;
          boundPlayerId = playerId;
          return;
        }

        if (msg.type === 'ACTION' && boundRoomId && boundPlayerId && msg.action) {
          roomManager.handleClientAction(boundRoomId, boundPlayerId, msg.action);
        }
      } catch (err) {
        console.error('WS message error:', err);
      }
    });

    ws.on('close', () => {
      if (boundRoomId && boundPlayerId) {
        roomManager.handleDisconnect(boundRoomId, boundPlayerId);
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`European Conquest 1939 sunucusu http://0.0.0.0:${PORT} adresinde hazır`);
  });
}

bootstrap();
