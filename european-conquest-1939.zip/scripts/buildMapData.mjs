import fs from 'fs';
import path from 'path';
import * as topojson from 'topojson-client';
import * as d3 from 'd3-geo';

const world50 = JSON.parse(
  fs.readFileSync(path.resolve('node_modules/world-atlas/countries-50m.json'), 'utf8')
);
const rawFeatures = topojson.feature(world50, world50.objects.countries).features;

// Projection: Upright Mercator tuned for Europe, Anatolia, Caucasus, Middle East, Arabia & North Africa
const WIDTH = 2200;
const HEIGHT = 1480;

const projection = d3
  .geoMercator()
  .center([18, 48])
  .scale(865)
  .translate([1020, 735]);

// Map countries from world-atlas to our game country IDs
// Using exact ISO numeric IDs or names where numeric ID is undefined (Kosovo, N. Cyprus)
function getCountryCode(feature) {
  const name = feature.properties?.name || '';
  const id = String(feature.id || '');
  const byId = {
    '826': 'UK',
    '250': 'FRA',
    '276': 'GER',
    '380': 'ITA',
    '724': 'ESP',
    '620': 'POR',
    '616': 'POL',
    '578': 'NOR',
    '752': 'SWE',
    '246': 'FIN',
    '208': 'DEN',
    '528': 'NED',
    '056': 'BEL',
    '756': 'SWI',
    '040': 'AUS',
    '203': 'CZE',
    '703': 'SLO_SK', // Slovakia
    '348': 'HUN',
    '642': 'ROM',
    '100': 'BUL',
    '688': 'SER',
    '191': 'CRO',
    '070': 'BOS',
    '705': 'SLV',
    '499': 'MNE',
    '807': 'MKD',
    '300': 'GRE',
    '008': 'ALB',
    '372': 'IRE',
    '352': 'ICE',
    '233': 'EST',
    '428': 'LAT',
    '440': 'LIT',
    '498': 'MOL',
    '112': 'BLR',
    '804': 'UKR',
    '643': 'RUS',
    '442': 'LUX',
    '020': 'AND',
    '492': 'MCO',
    '674': 'SMR',
    '438': 'LIE',
    '470': 'MLT',
    '196': 'CYP',
    '792': 'TUR',
    '031': 'AZE',
    '051': 'ARM',
    '268': 'GEO',
    '364': 'IRN',
    '368': 'IRQ',
    '760': 'SYR',
    '422': 'LEB',
    '400': 'JOR',
    '376': 'PAL',
    '275': 'PAL',
    '682': 'SAU',
    '887': 'YEM',
    '512': 'OMA',
    '784': 'UAE',
    '634': 'QAT',
    '048': 'BHR',
    '414': 'KUW',
    '818': 'EGY',
    '434': 'LBY',
    '788': 'TUN',
    '012': 'ALG',
    '504': 'MOR',
    '732': 'MOR', // W. Sahara folded into Morocco theater boundary if clipped
  };
  if (byId[id]) return byId[id];
  if (name === 'Kosovo') return 'KOS';
  if (name === 'N. Cyprus') return 'CYP';
  return null;
}

// Strategic province definitions per country [id, cityName, lon, lat, isCapital, isPort, terrain, basePop, baseFactories]
const PROVINCE_SEEDS = {
  UK: [
    ['uk_london', 'Londra', -0.12, 51.5, true, true, 'urban', 8500, 5],
    ['uk_manchester', 'Manchester', -2.24, 53.48, false, true, 'hills', 5200, 4],
    ['uk_edinburgh', 'Edinburgh', -3.19, 55.95, false, true, 'hills', 3100, 2],
    ['uk_belfast', 'Belfast', -5.93, 54.6, false, true, 'plains', 1400, 1],
  ],
  IRE: [
    ['ire_dublin', 'Dublin', -6.26, 53.35, true, true, 'plains', 2900, 2],
  ],
  ICE: [
    ['ice_reykjavik', 'Reykjavik', -21.9, 64.14, true, true, 'mountain', 450, 1],
  ],
  FRA: [
    ['fra_paris', 'Paris', 2.35, 48.85, true, false, 'urban', 9200, 5],
    ['fra_calais', 'Lille / Calais', 2.6, 50.6, false, true, 'plains', 4100, 3],
    ['fra_brest', 'Brest', -4.48, 48.39, false, true, 'plains', 3200, 2],
    ['fra_strasbourg', 'Strasbourg', 7.2, 48.58, false, false, 'forest', 3600, 3],
    ['fra_lyon', 'Lyon', 4.83, 45.76, false, false, 'hills', 4400, 3],
    ['fra_bordeaux', 'Bordeaux', -0.58, 44.84, false, true, 'plains', 3500, 2],
    ['fra_marseille', 'Marsilya', 5.37, 43.3, false, true, 'hills', 4200, 2],
  ],
  ESP: [
    ['esp_madrid', 'Madrid', -3.7, 40.42, true, false, 'hills', 5600, 3],
    ['esp_barcelona', 'Barselona', 2.17, 41.39, false, true, 'hills', 4900, 3],
    ['esp_bilbao', 'Bilbao', -2.93, 43.26, false, true, 'mountain', 3100, 2],
    ['esp_sevilla', 'Sevilla', -5.98, 37.39, false, true, 'plains', 4200, 2],
  ],
  POR: [
    ['por_lisbon', 'Lizbon', -9.14, 38.72, true, true, 'hills', 4100, 2],
    ['por_porto', 'Porto', -8.61, 41.15, false, true, 'hills', 2800, 1],
  ],
  GER: [
    ['ger_berlin', 'Berlin', 13.4, 52.52, true, false, 'urban', 8900, 6],
    ['ger_hamburg', 'Hamburg', 9.99, 53.55, false, true, 'plains', 5100, 4],
    ['ger_cologne', 'Köln / Ruhr', 6.96, 50.94, false, false, 'urban', 7800, 6],
    ['ger_frankfurt', 'Frankfurt', 8.68, 50.11, false, false, 'forest', 5400, 4],
    ['ger_munich', 'Münih', 11.58, 48.14, false, false, 'hills', 5800, 4],
    ['ger_dresden', 'Dresden / Silezya', 14.5, 51.05, false, false, 'plains', 4900, 3],
    ['ger_konigsberg', 'Königsberg', 20.5, 54.71, false, true, 'plains', 2400, 2],
  ],
  ITA: [
    ['ita_rome', 'Roma', 12.49, 41.9, true, true, 'hills', 6800, 4],
    ['ita_milan', 'Milano', 9.19, 45.46, false, false, 'urban', 7200, 5],
    ['ita_venice', 'Venedik', 12.32, 45.44, false, true, 'plains', 4200, 3],
    ['ita_naples', 'Napoli', 14.27, 40.85, false, true, 'hills', 5400, 3],
    ['ita_palermo', 'Palermo', 13.36, 38.12, false, true, 'mountain', 3800, 1],
  ],
  POL: [
    ['pol_warsaw', 'Varşova', 21.01, 52.23, true, false, 'plains', 6900, 4],
    ['pol_danzig', 'Danzig / Poznan', 17.6, 53.4, false, true, 'plains', 4600, 3],
    ['pol_krakow', 'Krakow', 19.94, 50.06, false, false, 'hills', 5200, 3],
    ['pol_lwow', 'Brest / Doğu Polonya', 24.0, 51.5, false, false, 'forest', 4100, 2],
  ],
  NOR: [
    ['nor_oslo', 'Oslo', 10.75, 59.91, true, true, 'forest', 1800, 2],
    ['nor_bergen', 'Bergen', 5.32, 60.39, false, true, 'mountain', 900, 1],
    ['nor_narvik', 'Narvik', 16.5, 67.5, false, true, 'mountain', 500, 1],
  ],
  SWE: [
    ['swe_stockholm', 'Stockholm', 18.07, 59.33, true, true, 'forest', 2800, 3],
    ['swe_gothenburg', 'Göteborg / Malmö', 12.5, 57.2, false, true, 'plains', 2400, 2],
    ['swe_kiruna', 'Kiruna / Kuzey', 18.5, 65.5, false, true, 'forest', 1100, 1],
  ],
  FIN: [
    ['fin_helsinki', 'Helsinki', 24.94, 60.17, true, true, 'forest', 2200, 2],
    ['fin_oulu', 'Oulu / Laponya', 25.5, 65.0, false, true, 'forest', 1400, 1],
  ],
  DEN: [
    ['den_copenhagen', 'Kopenhag', 12.57, 55.68, true, true, 'plains', 2100, 2],
    ['den_aarhus', 'Aarhus', 9.8, 56.1, false, true, 'plains', 1700, 1],
  ],
  NED: [
    ['ned_amsterdam', 'Amsterdam', 4.9, 52.37, true, true, 'plains', 4600, 3],
    ['ned_rotterdam', 'Rotterdam', 5.5, 51.6, false, true, 'plains', 3900, 2],
  ],
  BEL: [
    ['bel_brussels', 'Brüksel', 4.35, 50.85, true, true, 'urban', 4800, 3],
    ['bel_liege', 'Liège', 5.57, 50.63, false, false, 'forest', 3400, 2],
  ],
  LUX: [['lux_city', 'Lüksemburg', 6.13, 49.61, true, false, 'forest', 300, 1]],
  SWI: [
    ['swi_bern', 'Bern', 7.45, 46.95, true, false, 'mountain', 2200, 2],
    ['swi_zurich', 'Zürih', 8.54, 47.37, false, false, 'mountain', 2100, 2],
  ],
  AUS: [
    ['aus_vienna', 'Viyana', 16.37, 48.21, true, false, 'hills', 4200, 3],
    ['aus_innsbruck', 'Innsbruck', 12.5, 47.26, false, false, 'mountain', 2400, 1],
  ],
  CZE: [
    ['cze_prague', 'Prag', 14.42, 50.08, true, false, 'hills', 5800, 4],
    ['cze_brno', 'Brno', 16.61, 49.2, false, false, 'hills', 4100, 3],
  ],
  SLO_SK: [['svk_bratislava', 'Bratislava', 18.5, 48.6, true, false, 'mountain', 3500, 2]],
  HUN: [
    ['hun_budapest', 'Budapeşte', 19.04, 47.5, true, false, 'plains', 5600, 3],
    ['hun_debrecen', 'Debrecen', 21.1, 47.3, false, false, 'plains', 3400, 1],
  ],
  ROM: [
    ['rom_bucharest', 'Bükreş', 26.1, 44.43, true, true, 'plains', 6400, 3],
    ['rom_cluj', 'Cluj-Napoca', 23.6, 46.77, false, false, 'mountain', 4900, 2],
    ['rom_iasi', 'Yaş', 27.6, 47.16, false, false, 'plains', 4200, 2],
  ],
  BUL: [
    ['bul_sofia', 'Sofya', 23.32, 42.7, true, false, 'mountain', 3600, 2],
    ['bul_varna', 'Varna', 27.5, 43.2, false, true, 'plains', 2700, 1],
  ],
  SLV: [['slv_ljubljana', 'Ljubljana', 14.51, 46.06, true, true, 'mountain', 1400, 1]],
  CRO: [
    ['cro_zagreb', 'Zagreb', 15.98, 45.81, true, false, 'hills', 2400, 2],
    ['cro_split', 'Split', 16.44, 43.51, false, true, 'mountain', 1600, 1],
  ],
  BOS: [['bos_sarajevo', 'Saraybosna', 18.41, 43.86, true, false, 'mountain', 2700, 1]],
  SER: [
    ['ser_belgrade', 'Belgrad', 20.45, 44.79, true, false, 'plains', 4400, 3],
    ['ser_nis', 'Niş', 21.9, 43.32, false, false, 'hills', 2600, 1],
  ],
  MNE: [['mne_podgorica', 'Podgoritsa', 19.26, 42.44, true, true, 'mountain', 500, 1]],
  KOS: [['kos_pristina', 'Priştine', 21.16, 42.66, true, false, 'mountain', 700, 1]],
  MKD: [['mkd_skopje', 'Üsküp', 21.43, 41.99, true, false, 'mountain', 1100, 1]],
  GRE: [
    ['gre_athens', 'Atina', 23.73, 37.98, true, true, 'hills', 4200, 2],
    ['gre_thessaloniki', 'Selanik', 22.94, 40.64, false, true, 'mountain', 2900, 2],
  ],
  ALB: [['alb_tirana', 'Tiran', 19.82, 41.33, true, true, 'mountain', 1100, 1]],
  EST: [['est_tallinn', 'Tallinn', 24.75, 59.44, true, true, 'forest', 1150, 1]],
  LAT: [['lat_riga', 'Riga', 24.11, 56.95, true, true, 'plains', 1950, 1]],
  LIT: [['lit_vilnius', 'Vilnius / Kaunas', 24.0, 55.2, true, true, 'plains', 2900, 2]],
  MOL: [['mol_chisinau', 'Kişinev', 28.86, 47.01, true, false, 'plains', 2400, 1]],
  BLR: [
    ['blr_minsk', 'Minsk', 27.56, 53.9, true, false, 'forest', 4800, 3],
    ['blr_gomel', 'Gomel', 30.98, 52.43, false, false, 'forest', 3400, 2],
  ],
  UKR: [
    ['ukr_kyiv', 'Kiev', 30.52, 50.45, true, false, 'plains', 8200, 4],
    ['ukr_kharkiv', 'Harkov', 36.23, 49.99, false, false, 'plains', 7400, 4],
    ['ukr_odessa', 'Odessa', 30.72, 46.48, false, true, 'plains', 5600, 3],
    ['ukr_lviv', 'Lviv', 24.03, 49.84, false, false, 'hills', 4900, 2],
    ['ukr_crimea', 'Sivastopol / Kırım', 34.1, 44.95, false, true, 'hills', 2100, 2],
  ],
  RUS: [
    ['rus_moscow', 'Moskova', 37.62, 55.76, true, false, 'urban', 12500, 7],
    ['rus_leningrad', 'Leningrad', 30.31, 59.93, false, true, 'forest', 7800, 5],
    ['rus_smolensk', 'Smolensk', 32.04, 54.78, false, false, 'forest', 5200, 3],
    ['rus_voronezh', 'Voronej', 39.2, 51.67, false, false, 'plains', 6100, 3],
    ['rus_stalingrad', 'Stalingrad', 44.51, 48.7, false, false, 'plains', 6800, 4],
    ['rus_rostov', 'Rostov / Kuban', 39.7, 46.5, false, true, 'plains', 5400, 3],
    ['rus_kazan', 'Kazan', 49.12, 55.8, false, false, 'forest', 6400, 4],
    ['rus_arkhangelsk', 'Arhangelsk / Murmansk', 38.0, 64.5, false, true, 'forest', 2200, 2],
    ['rus_ufa', 'Ufa / Ural', 56.0, 55.5, false, false, 'mountain', 5500, 4],
  ],
  TUR: [
    ['tur_ankara', 'Ankara', 32.86, 39.93, true, false, 'hills', 5200, 3],
    ['tur_istanbul', 'İstanbul', 28.98, 41.01, false, true, 'urban', 5800, 4],
    ['tur_izmir', 'İzmir', 27.14, 38.42, false, true, 'hills', 4100, 2],
    ['tur_adana', 'Adana / Antalya', 34.5, 37.0, false, true, 'mountain', 3600, 2],
    ['tur_erzurum', 'Erzurum / Trabzon', 41.27, 39.9, false, true, 'mountain', 3200, 2],
  ],
  GEO: [['geo_tbilisi', 'Tiflis', 44.8, 41.72, true, true, 'mountain', 3500, 2]],
  ARM: [['arm_yerevan', 'Erivan', 44.51, 40.18, true, false, 'mountain', 1400, 1]],
  AZE: [['aze_baku', 'Bakü', 49.87, 40.41, true, true, 'hills', 3200, 3]],
  IRN: [
    ['irn_tehran', 'Tahran', 51.39, 35.69, true, true, 'mountain', 5400, 3],
    ['irn_tabriz', 'Tebriz', 46.29, 38.08, false, false, 'mountain', 3600, 2],
    ['irn_isfahan', 'İsfahan / Şiraz', 51.67, 31.8, false, true, 'desert', 3800, 2],
    ['irn_mashhad', 'Meşhed', 57.5, 35.5, false, false, 'desert', 2600, 1],
  ],
  IRQ: [
    ['irq_baghdad', 'Bağdat', 44.37, 33.31, true, false, 'desert', 2800, 2],
    ['irq_basra', 'Basra', 47.78, 30.51, false, true, 'desert', 1600, 1],
  ],
  SYR: [
    ['syr_damascus', 'Şam', 36.29, 33.51, true, true, 'desert', 1900, 1],
    ['syr_aleppo', 'Halep', 37.16, 36.2, false, false, 'plains', 1600, 1],
  ],
  LEB: [['leb_beirut', 'Beyrut', 35.5, 33.89, true, true, 'hills', 1100, 1]],
  JOR: [['jor_amman', 'Amman', 36.5, 31.5, true, true, 'desert', 1000, 1]],
  PAL: [['pal_jerusalem', 'Kudüs / Yafa', 35.0, 31.77, true, true, 'hills', 1500, 1]],
  SAU: [
    ['sau_riyadh', 'Riyad', 46.72, 24.71, true, true, 'desert', 1900, 2],
    ['sau_jeddah', 'Cidde / Mekke', 39.2, 21.5, false, true, 'desert', 1500, 1],
    ['sau_tabuk', 'Tebük / Kuzey', 39.5, 28.5, false, true, 'desert', 900, 1],
  ],
  YEM: [['yem_sanaa', 'Sana / Aden', 45.0, 14.8, true, true, 'mountain', 2400, 1]],
  OMA: [['oma_muscat', 'Maskat', 57.0, 21.5, true, true, 'desert', 900, 1]],
  UAE: [['uae_abudhabi', 'Abu Dabi / Dubai', 54.4, 24.2, true, true, 'desert', 400, 1]],
  QAT: [['qat_doha', 'Doha', 51.2, 25.3, true, true, 'desert', 250, 1]],
  BHR: [['bhr_manama', 'Manama', 50.55, 26.2, true, true, 'desert', 200, 1]],
  KUW: [['kuw_city', 'Kuveyt', 47.6, 29.3, true, true, 'desert', 350, 1]],
  EGY: [
    ['egy_cairo', 'Kahire', 31.24, 30.04, true, false, 'urban', 7500, 3],
    ['egy_alexandria', 'İskenderiye', 29.2, 30.8, false, true, 'desert', 4800, 2],
    ['egy_aswan', 'Asvan / Kızıldeniz', 32.8, 25.5, false, true, 'desert', 3900, 1],
  ],
  LBY: [
    ['lby_tripoli', 'Trablus', 13.19, 32.89, true, true, 'desert', 900, 1],
    ['lby_benghazi', 'Bingazi', 21.0, 30.5, false, true, 'desert', 700, 1],
  ],
  TUN: [['tun_tunis', 'Tunus', 9.8, 35.0, true, true, 'hills', 2800, 2]],
  ALG: [
    ['alg_algiers', 'Cezayir', 3.06, 36.75, true, true, 'hills', 4200, 2],
    ['alg_oran', 'Oran', -0.6, 34.5, false, true, 'desert', 2400, 1],
    ['alg_tamanrasset', 'Sahra Güneyi', 5.0, 28.5, false, false, 'desert', 900, 1],
  ],
  MOR: [
    ['mor_rabat', 'Rabat / Kazablanka', -6.85, 33.97, true, true, 'hills', 4800, 2],
    ['mor_marrakesh', 'Marakeş', -8.0, 30.5, false, false, 'mountain', 2900, 1],
  ],
  AND: [['and_la', 'Andorra', 1.52, 42.51, true, false, 'mountain', 120, 1]],
  MCO: [['mco_city', 'Monako', 7.42, 43.73, true, true, 'urban', 100, 1]],
  SMR: [['smr_city', 'San Marino', 12.46, 43.94, true, false, 'mountain', 100, 1]],
  LIE: [['lie_vaduz', 'Vaduz', 9.52, 47.14, true, false, 'mountain', 100, 1]],
  MLT: [['mlt_valletta', 'Valletta', 14.51, 35.9, true, true, 'hills', 300, 1]],
  CYP: [['cyp_nicosia', 'Lefkoşa', 33.36, 35.18, true, true, 'hills', 450, 1]],
};

// Sutherland-Hodgman clip a 2D polygon against half-plane: a*x + b*y <= c
function clipPolygonHalfPlane(poly, a, b, c) {
  if (poly.length < 3) return [];
  const out = [];
  const n = poly.length;
  for (let i = 0; i < n; i++) {
    const p1 = poly[i];
    const p2 = poly[(i + 1) % n];
    const d1 = a * p1[0] + b * p1[1] - c;
    const d2 = a * p2[0] + b * p2[1] - c;
    const in1 = d1 <= 1e-6;
    const in2 = d2 <= 1e-6;
    if (in1 && in2) {
      out.push(p2);
    } else if (in1 && !in2) {
      const t = d1 / (d1 - d2);
      out.push([p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1])]);
    } else if (!in1 && in2) {
      const t = d1 / (d1 - d2);
      out.push([p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1])]);
      out.push(p2);
    }
  }
  return out;
}

// Unwrap antimeridian +/-180 longitude discontinuities so rings stay continuous
function unwrapGeoRing(ring) {
  if (!ring || ring.length === 0) return [];
  const out = [[ring[0][0], ring[0][1]]];
  for (let i = 1; i < ring.length; i++) {
    let lon = ring[i][0];
    const prevLon = out[i - 1][0];
    while (lon - prevLon > 180) lon -= 360;
    while (lon - prevLon < -180) lon += 360;
    out.push([lon, ring[i][1]]);
  }
  return out;
}

// Clip geo ring in lon/lat space
function clipGeoRing(ring, countryCode) {
  let poly = unwrapGeoRing(ring);
  if (poly.length < 3) return [];

  // Skip isolated high-Arctic Russian archipelagos (Novaya Zemlya / Franz Josef) above mainland 70.2N
  if (countryCode === 'RUS') {
    let minLat = Infinity;
    for (const pt of poly) {
      if (pt[1] < minLat) minLat = pt[1];
    }
    if (minLat > 70.2) return [];
  }

  // Theater clip box: lon [-25, 60], lat [12.5, 71.2]
  poly = clipPolygonHalfPlane(poly, -1, 0, 25); // lon >= -25
  poly = clipPolygonHalfPlane(poly, 1, 0, 60); // lon <= 60 (Urals!)
  poly = clipPolygonHalfPlane(poly, 0, -1, -12.5); // lat >= 12.5
  poly = clipPolygonHalfPlane(poly, 0, 1, 71.2); // lat <= 71.2

  if (countryCode === 'FRA') {
    // Keep only Metropolitan France + Corsica
    poly = clipPolygonHalfPlane(poly, -1, 0, 6.0); // lon >= -6
    poly = clipPolygonHalfPlane(poly, 0, -1, -41.0); // lat >= 41
  }
  if (countryCode === 'ESP') {
    poly = clipPolygonHalfPlane(poly, -1, 0, 10.0); // drop Canary Islands
    poly = clipPolygonHalfPlane(poly, 0, -1, -35.5);
  }
  if (countryCode === 'POR') {
    poly = clipPolygonHalfPlane(poly, -1, 0, 10.0); // drop Azores/Madeira
  }
  if (countryCode === 'NOR') {
    poly = clipPolygonHalfPlane(poly, -1, 0, -4.0); // lon >= 4 (drop Svalbard/Jan Mayen)
    poly = clipPolygonHalfPlane(poly, 0, -1, -57.5);
  }
  if (countryCode === 'DEN') {
    poly = clipPolygonHalfPlane(poly, -1, 0, -7.5); // drop Greenland/Faroes
    poly = clipPolygonHalfPlane(poly, 0, 1, 58.2);
  }
  if (countryCode === 'MOR') {
    poly = clipPolygonHalfPlane(poly, 0, -1, -26.5); // trim deep south W. Sahara
  }
  if (countryCode === 'ALG') {
    poly = clipPolygonHalfPlane(poly, 0, -1, -24.5);
  }
  if (countryCode === 'LBY') {
    poly = clipPolygonHalfPlane(poly, 0, -1, -22.5);
  }
  if (countryCode === 'RUS') {
    poly = clipPolygonHalfPlane(poly, -1, 0, -26.5); // lon >= 26.5 (drop Kaliningrad/western-hemisphere Chukotka wrap)
    poly = clipPolygonHalfPlane(poly, 0, -1, -41.0);
  }
  if (countryCode === 'EGY') {
    poly = clipPolygonHalfPlane(poly, 0, -1, -22.0);
  }
  return poly;
}

function polygonArea(poly) {
  let area = 0;
  for (let i = 0; i < poly.length; i++) {
    const [x1, y1] = poly[i];
    const [x2, y2] = poly[(i + 1) % poly.length];
    area += x1 * y2 - x2 * y1;
  }
  return Math.abs(area) * 0.5;
}

function polygonCentroid(poly) {
  let cx = 0;
  let cy = 0;
  let signedArea = 0;
  for (let i = 0; i < poly.length; i++) {
    const [x0, y0] = poly[i];
    const [x1, y1] = poly[(i + 1) % poly.length];
    const a = x0 * y1 - x1 * y0;
    signedArea += a;
    cx += (x0 + x1) * a;
    cy += (y0 + y1) * a;
  }
  if (Math.abs(signedArea) < 1e-6) {
    const sx = poly.reduce((acc, p) => acc + p[0], 0) / poly.length;
    const sy = poly.reduce((acc, p) => acc + p[1], 0) / poly.length;
    return [sx, sy];
  }
  signedArea *= 0.5;
  return [cx / (6 * signedArea), cy / (6 * signedArea)];
}

function simplifyRing(poly, tolerance = 1.2) {
  if (poly.length <= 8) return poly;
  const out = [poly[0]];
  for (let i = 1; i < poly.length - 1; i++) {
    const prev = out[out.length - 1];
    const cur = poly[i];
    const dist = Math.hypot(cur[0] - prev[0], cur[1] - prev[1]);
    if (dist >= tolerance) {
      out.push(cur);
    }
  }
  out.push(poly[poly.length - 1]);
  return out.length >= 3 ? out : poly;
}

// Extract all exterior rings per countryCode
const countryRings = {};
for (const feature of rawFeatures) {
  const code = getCountryCode(feature);
  if (!code || !PROVINCE_SEEDS[code]) continue;
  if (!countryRings[code]) countryRings[code] = [];

  const geom = feature.geometry;
  const polygons = geom.type === 'Polygon' ? [geom.coordinates] : geom.coordinates;
  for (const polyRings of polygons) {
    const outer = polyRings[0];
    const clippedGeo = clipGeoRing(outer, code);
    if (clippedGeo.length < 3) continue;
    const projected = [];
    for (const pt of clippedGeo) {
      const xy = projection(pt);
      if (xy && Number.isFinite(xy[0]) && Number.isFinite(xy[1])) {
        projected.push([Math.round(xy[0] * 10) / 10, Math.round(xy[1] * 10) / 10]);
      }
    }
    const simplified = simplifyRing(projected, 1.3);
    if (simplified.length >= 3 && polygonArea(simplified) >= 1) {
      countryRings[code].push(simplified);
    }
  }
}

// Split each country's projected rings by Voronoi bisectors of its province seeds
const provinces = [];
const provinceMap = {};

for (const [code, seeds] of Object.entries(PROVINCE_SEEDS)) {
  const rings = countryRings[code] || [];

  const projectedSeeds = seeds.map((s) => {
    const xy = projection([s[2], s[3]]);
    return {
      id: s[0],
      name: s[1],
      countryId: code,
      seedX: xy[0],
      seedY: xy[1],
      isCapital: s[4],
      isPort: s[5],
      terrain: s[6],
      basePop: s[7],
      baseFactories: s[8],
      polygons: [],
    };
  });

  if (projectedSeeds.length === 1) {
    projectedSeeds[0].polygons = rings;
  } else {
    for (const ring of rings) {
      for (let i = 0; i < projectedSeeds.length; i++) {
        let cell = ring;
        const si = projectedSeeds[i];
        for (let j = 0; j < projectedSeeds.length; j++) {
          if (i === j) continue;
          const sj = projectedSeeds[j];
          // Half-plane closer to si than sj:
          // (x - si.x)^2 + (y - si.y)^2 <= (x - sj.x)^2 + (y - sj.y)^2
          // 2*(sj.x - si.x)*x + 2*(sj.y - si.y)*y <= sj.x^2 + sj.y^2 - si.x^2 - si.y^2
          const a = 2 * (sj.seedX - si.seedX);
          const b = 2 * (sj.seedY - si.seedY);
          const c = sj.seedX * sj.seedX + sj.seedY * sj.seedY - si.seedX * si.seedX - si.seedY * si.seedY;
          cell = clipPolygonHalfPlane(cell, a, b, c);
          if (cell.length < 3) break;
        }
        if (cell.length >= 3 && polygonArea(cell) >= 8) {
          si.polygons.push(cell.map((p) => [Math.round(p[0] * 10) / 10, Math.round(p[1] * 10) / 10]));
        }
      }
    }
  }

  for (const ps of projectedSeeds) {
    if (ps.polygons.length === 0) {
      // Fallback small diamond around seed if tiny city-state
      const r = 8;
      ps.polygons.push([
        [Math.round((ps.seedX - r) * 10) / 10, Math.round(ps.seedY * 10) / 10],
        [Math.round(ps.seedX * 10) / 10, Math.round((ps.seedY - r) * 10) / 10],
        [Math.round((ps.seedX + r) * 10) / 10, Math.round(ps.seedY * 10) / 10],
        [Math.round(ps.seedX * 10) / 10, Math.round((ps.seedY + r) * 10) / 10],
      ]);
    }
    // Use largest polygon centroid for label/army position
    let bestPoly = ps.polygons[0];
    let bestArea = polygonArea(bestPoly);
    for (const p of ps.polygons) {
      const a = polygonArea(p);
      if (a > bestArea) {
        bestArea = a;
        bestPoly = p;
      }
    }
    const [cx, cy] = polygonCentroid(bestPoly);
    const provObj = {
      id: ps.id,
      name: ps.name,
      countryId: ps.countryId,
      isCapital: ps.isCapital,
      isPort: ps.isPort,
      terrain: ps.terrain,
      basePop: ps.basePop,
      baseFactories: ps.baseFactories,
      x: Math.round(cx * 10) / 10,
      y: Math.round(cy * 10) / 10,
      polygons: ps.polygons,
      neighbors: [],
      seaNeighbors: [],
    };
    provinces.push(provObj);
    provinceMap[provObj.id] = provObj;
  }
}

// Compute adjacency between provinces via bounding box + vertex-to-segment distance
function pointToSegDist(px, py, ax, ay, bx, by) {
  const dx = bx - ax;
  const dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  if (lenSq < 1e-6) return Math.hypot(px - ax, py - ay);
  let t = ((px - ax) * dx + (py - ay) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

function getBBox(polys) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const poly of polys) {
    for (const [x, y] of poly) {
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
  }
  return { minX, minY, maxX, maxY };
}

const bboxes = {};
for (const p of provinces) bboxes[p.id] = getBBox(p.polygons);

function arePolysTouching(polysA, polysB, threshold = 4.5) {
  for (const pa of polysA) {
    for (const pb of polysB) {
      for (const [ax, ay] of pa) {
        for (let i = 0; i < pb.length; i++) {
          const [b1x, b1y] = pb[i];
          const [b2x, b2y] = pb[(i + 1) % pb.length];
          if (pointToSegDist(ax, ay, b1x, b1y, b2x, b2y) <= threshold) return true;
        }
      }
      for (const [bx, by] of pb) {
        for (let i = 0; i < pa.length; i++) {
          const [a1x, a1y] = pa[i];
          const [a2x, a2y] = pa[(i + 1) % pa.length];
          if (pointToSegDist(bx, by, a1x, a1y, a2x, a2y) <= threshold) return true;
        }
      }
    }
  }
  return false;
}

function addNeighbor(aId, bId) {
  if (aId === bId) return;
  const a = provinceMap[aId];
  const b = provinceMap[bId];
  if (!a || !b) return;
  if (!a.neighbors.includes(bId)) a.neighbors.push(bId);
  if (!b.neighbors.includes(aId)) b.neighbors.push(aId);
}

for (let i = 0; i < provinces.length; i++) {
  for (let j = i + 1; j < provinces.length; j++) {
    const a = provinces[i];
    const b = provinces[j];
    const ba = bboxes[a.id];
    const bb = bboxes[b.id];
    const pad = 6;
    if (ba.maxX + pad < bb.minX || bb.maxX + pad < ba.minX || ba.maxY + pad < bb.minY || bb.maxY + pad < ba.minY) {
      continue;
    }
    if (arePolysTouching(a.polygons, b.polygons, 4.5)) {
      addNeighbor(a.id, b.id);
    }
  }
}

// Strategic Strait & Island Land Crossings (important for playability!)
const STRAIT_LINKS = [
  ['tur_istanbul', 'tur_izmir'],
  ['tur_istanbul', 'gre_thessaloniki'],
  ['den_copenhagen', 'den_aarhus'],
  ['den_copenhagen', 'swe_gothenburg'],
  ['ita_naples', 'ita_palermo'],
  ['esp_sevilla', 'mor_rabat'],
  ['uk_london', 'fra_calais'],
  ['uk_manchester', 'uk_belfast'],
  ['uk_belfast', 'ire_dublin'],
  ['est_tallinn', 'fin_helsinki'],
  ['ita_palermo', 'tun_tunis'],
  ['gre_athens', 'tur_izmir'],
  ['tur_adana', 'cyp_nicosia'],
  ['ita_palermo', 'mlt_valletta'],
  ['yem_sanaa', 'sau_jeddah'],
  ['bhr_manama', 'qat_doha'],
  ['bhr_manama', 'sau_riyadh'],
];
for (const [a, b] of STRAIT_LINKS) {
  addNeighbor(a, b);
}

// Ensure no province is completely isolated
for (const p of provinces) {
  if (p.neighbors.length === 0) {
    let bestId = null;
    let bestDist = Infinity;
    for (const q of provinces) {
      if (q.id === p.id) continue;
      const d = Math.hypot(p.x - q.x, p.y - q.y);
      if (d < bestDist) {
        bestDist = d;
        bestId = q.id;
      }
    }
    if (bestId) addNeighbor(p.id, bestId);
  }
}

// Define 16 Named Sea Zones (lon/lat centers projected to map space)
const SEA_ZONE_DEFS = [
  { id: 'sea_norwegian', name: 'Norveç Denizi', lon: 2, lat: 65, neighbors: ['sea_atlantic', 'sea_north'] },
  { id: 'sea_atlantic', name: 'Kuzey Atlas Okyanusu', lon: -14, lat: 54, neighbors: ['sea_norwegian', 'sea_north', 'sea_channel', 'sea_biscay'] },
  { id: 'sea_north', name: 'Kuzey Denizi', lon: 3.5, lat: 56.5, neighbors: ['sea_norwegian', 'sea_atlantic', 'sea_channel', 'sea_baltic'] },
  { id: 'sea_baltic', name: 'Baltık Denizi', lon: 19, lat: 58.5, neighbors: ['sea_north'] },
  { id: 'sea_channel', name: 'Manş Denizi', lon: -2.5, lat: 49.8, neighbors: ['sea_atlantic', 'sea_north', 'sea_biscay'] },
  { id: 'sea_biscay', name: 'Biskay Körfezi', lon: -9, lat: 43, neighbors: ['sea_atlantic', 'sea_channel', 'sea_med_west'] },
  { id: 'sea_med_west', name: 'Batı Akdeniz', lon: 3, lat: 38.5, neighbors: ['sea_biscay', 'sea_med_central'] },
  { id: 'sea_med_central', name: 'Orta Akdeniz', lon: 15, lat: 35.5, neighbors: ['sea_med_west', 'sea_adriatic', 'sea_ionian', 'sea_med_east'] },
  { id: 'sea_adriatic', name: 'Adriyatik Denizi', lon: 15.5, lat: 43, neighbors: ['sea_med_central', 'sea_ionian'] },
  { id: 'sea_ionian', name: 'İyon Denizi', lon: 19, lat: 37.5, neighbors: ['sea_med_central', 'sea_adriatic', 'sea_aegean', 'sea_med_east'] },
  { id: 'sea_aegean', name: 'Ege Denizi', lon: 25.2, lat: 38.2, neighbors: ['sea_ionian', 'sea_med_east', 'sea_black'] },
  { id: 'sea_med_east', name: 'Doğu Akdeniz', lon: 31, lat: 33.8, neighbors: ['sea_med_central', 'sea_ionian', 'sea_aegean', 'sea_red'] },
  { id: 'sea_black', name: 'Karadeniz', lon: 34.5, lat: 43.3, neighbors: ['sea_aegean'] },
  { id: 'sea_caspian', name: 'Hazar Denizi', lon: 51, lat: 41.5, neighbors: [] },
  { id: 'sea_red', name: 'Kızıldeniz', lon: 38.5, lat: 21.5, neighbors: ['sea_med_east', 'sea_persian'] },
  { id: 'sea_persian', name: 'Basra Körfezi', lon: 52, lat: 26, neighbors: ['sea_red'] },
];

const seaZones = SEA_ZONE_DEFS.map((sz) => {
  const [x, y] = projection([sz.lon, sz.lat]);
  return {
    id: sz.id,
    name: sz.name,
    x: Math.round(x * 10) / 10,
    y: Math.round(y * 10) / 10,
    neighbors: sz.neighbors,
    portProvinces: [],
  };
});

// Link every port province to its nearest sea zone
for (const p of provinces) {
  if (!p.isPort) continue;
  let bestSea = null;
  let bestDist = Infinity;
  for (const sz of seaZones) {
    // Special rule: Caspian ports only link to Caspian
    if ((p.id === 'aze_baku' || p.id === 'irn_tehran') && sz.id !== 'sea_caspian') continue;
    if (p.id !== 'aze_baku' && p.id !== 'irn_tehran' && sz.id === 'sea_caspian') continue;
    const d = Math.hypot(p.x - sz.x, p.y - sz.y);
    if (d < bestDist) {
      bestDist = d;
      bestSea = sz;
    }
  }
  if (bestSea) {
    p.seaNeighbors.push(bestSea.id);
    bestSea.portProvinces.push(p.id);
  }
}

const outData = {
  width: WIDTH,
  height: HEIGHT,
  source: 'Natural Earth 50m via world-atlas (Public Domain)',
  provinces,
  seaZones,
};

fs.mkdirSync(path.resolve('src/shared/data'), { recursive: true });
fs.writeFileSync(path.resolve('src/shared/data/mapData.json'), JSON.stringify(outData));

console.log(
  `Generated mapData.json: ${provinces.length} land provinces, ${seaZones.length} sea zones, size: ${(
    fs.statSync(path.resolve('src/shared/data/mapData.json')).size / 1024
  ).toFixed(1)} KB`
);
