# European Conquest 1939

**European Conquest 1939**, Hearts of Iron IV ve büyük strateji oyunlarından esinlenilmiş; tarayıcı üzerinden oynanan, sunucu otoriteli, gerçek zamanlı **Tek Oyunculu (Singleplayer)** ve **Çok Oyunculu (Multiplayer)** bir 1939 Avrupa, Anadolu, Kafkasya, Orta Doğu ve Kuzey Afrika strateji oyunudur.

---

## İçindekiler
1. [Öne Çıkan Özellikler](#öne-çıkan-özellikler)
2. [Klasör Yapısı](#klasör-yapısı)
3. [Harita Verisi ve Lisans Bilgisi](#harita-verisi-ve-lisans-bilgisi)
4. [Gerekli Kurulumlar ve Yerel Çalıştırma](#gerekli-kurulumlar-ve-yerel-çalıştırma)
5. [Çok Oyunculu (Multiplayer) Nasıl Oynanır?](#çok-oyunculu-multiplayer-nasıl-oynanır)
6. [Veritabanı ve Kayıt Sistemi Kurulumu](#veritabanı-ve-kayıt-sistemi-kurulumu)
7. [İnternette Yayınlama (Deployment) Rehberi](#i̇nternette-yayınlama-deployment-rehberi)
8. [Bilinen Sınırlar ve Gelecek Geliştirmeler](#bilinen-sınırlar-ve-gelecek-gelistirmeler)

---

## Öne Çıkan Özellikler

- **Coğrafi Sınır Doğruluğu (GeoJSON Tabanlı Phaser 3/4 Canvas Harita)**: Avrupa (Britanya, İrlanda, İzlanda, Baltıklar, Balkanlar, mikro devletler), Ural Dağları'na kadar Avrupa Rusyası, Türkiye ve Kafkasya, Orta Doğu, Arap Yarımadası ve Kuzey Afrika; 141 kara eyaleti, 67 oynanabilir ülke ve 16 deniz bölgesi.
- **Tarih & Senaryo Motoru**: **1 Eylül 1939** başlangıçlı *Alternatif 1939 (Serbest Gelişim)* ve *Tarihsel 1939 (Bloklar ve Gerilim)* senaryoları.
- **Askeri Harekat & 12 Kriterli Savaş Motoru**: 1K birimler (Piyade, Tank, Anti-Tank, Topçu, Motorize Piyade, Uçaksavar), otomatik BFS rota bulma (limanlı deniz aşırı sevkiyat dahil), çakışmayan ordu rozetleri ve sunucu otoriteli çok faktörlü muharebe hesaplayıcısı.
- **Tarihsel Komutanlar**: Başlıca ülkeler için 5'er tarihsel komutan (Türkiye dahil: *Mustafa Kemal Atatürk [Miras]*, *Fevzi Çakmak*, *Kazım Karabekir*, *İsmet İnönü*, *Enver Paşa*), Diplomasi Puanı ile açma, orduya atama kilidi ve savaşta seviye atlama.
- **Ekonomi, Üretim & Teknoloji**: 4 temel kaynak (Para, İnsangücü, Uranyum, Diplomasi Puanı), 9 eyalet binası, fabrika dağıtım kaydırıcıları ve 10 kategorili teknoloji ağacı (5 aşamalı Nükleer araştırma zinciri dahil).
- **Hükümet & Diplomasi**: 4 ideoloji, 15 maddelik Ulusal Odak Ağacı, ittifak, saldırmazlık paktı, savaş, toprak talepli barış anlaşması ve dış yardım.
- **Hava & Deniz Kuvvetleri**: Avcı, CAS, Bombardıman, Keşif filoları ile Taşıma, Muhrip, Kruvazör, Zırhlı, Uçak Gemisi ve Denizaltı filoları; deniz muharebeleri ve amfibi çıkarım desteği.
- **Adil Yapay Zeka & Gerçek Zamanlı Çok Oyunculu**: `Kolay / Normal / Zor` zorluk seviyeleri; WebSocket oda kodu ve davet linki ile varsayılan 5 oyunculu (ayarlanabilir) eşzamanlı lobi, bağlantı kopmasında otomatik bekleme süresi ve Yapay Zeka devralma seçeneği.

---

## Klasör Yapısı

```text
.
├── server.ts                       # Express REST API + WebSocket (/ws) + Vite sunucusu (Port 3000)
├── server/
│   ├── engine/
│   │   ├── GameEngine.ts           # Günlük oyun döngüsü, ekonomi, üretim, nükleer, zafer
│   │   ├── CombatEngine.ts         # 12 kriterli savaş motoru, zayiat, komutan TP ve fetih
│   │   └── AIEngine.ts             # Hilesiz yapay zeka karar motoru (Kolay/Normal/Zor)
│   ├── rooms/
│   │   └── RoomManager.ts          # SP/MP odaları, oda kodu, reconnect, otomatik kayıt
│   └── storage/
│       └── SaveStore.ts            # Atomik JSON kayıt/yükleme deposu (data/saves/)
├── scripts/
│   └── buildMapData.mjs            # Natural Earth GeoJSON -> mapData.json dönüştürücüsü
├── src/
│   ├── shared/
│   │   ├── types.ts                # İstemci ve sunucu ortak TypeScript tipleri
│   │   ├── data/                   # Ülkeler, senaryolar, birimler, teknoloji, odaklar, komutanlar, mapData.json
│   │   └── utils/gameHelpers.ts    # Tarih biçimlendirme, BFS rota bulucu, değiştiriciler
│   └── client/
│       ├── audio/SoundEngine.ts    # Web Audio API ses efektleri
│       ├── network/GameClient.ts   # Yeniden bağlanan WebSocket istemcisi ve API yardımcıları
│       ├── map/                    # Phaser harita sahnesi ve React sarmalayıcısı
│       └── components/             # HUD, 7 ana panel, eyalet çekmecesi, modallar ve öğretici
├── .env.example                    # Ortam değişkenleri şablonu
└── package.json                    # Bağımlılıklar ve çalıştırma komutları
```

---

## Harita Verisi ve Lisans Bilgisi

- **Kaynak**: [Natural Earth Data](https://www.naturalearthdata.com/) — `world-atlas` (`countries-50m.json`)
- **Lisans**: **Public Domain (Kamu Malı)** — Ticari ve ticari olmayan tüm projelerde serbestçe kullanılabilir.
- **İşleme**: `scripts/buildMapData.mjs`, `d3-geo` (Conic Equal-Area projeksiyonu), `topojson-client`, Ural sınırı poligon kırpması (`~60°E`) ve büyük ülkeler için Voronoi eyalet bölümlemesi ile coğrafi doğruluğu yüksek `src/shared/data/mapData.json` dosyasını üretir. Ülke mülkiyeti harita geometrisinden ayrı tutularak her senaryoda esnek sınır değişimi sağlanır.

---

## Gerekli Kurulumlar ve Yerel Çalıştırma

### 1. Gereksinimler
- **Node.js 20+** (Önerilen: Node.js 22 LTS)
- **npm** (Node.js ile birlikte gelir)

### 2. Adım Adım Kurulum
Terminal (Komut İstemi) açıp proje klasörüne girin ve aşağıdaki komutları çalıştırın:

```bash
# 1. Gerekli tüm paketleri yükleyin
npm install

# 2. (İsteğe bağlı) Ortam ayar dosyasını oluşturun
cp .env.example .env
```

### 3. Geliştirme (Oyun) Sunucusunu Başlatma
```bash
npm run dev
```
Ardından tarayıcınızdan şu adrese gidin:
`http://localhost:3000`

### 4. Üretim Derlemesi (Production Build)
```bash
npm run build
npm start
```

---

## Çok Oyunculu (Multiplayer) Nasıl Oynanır?

1. Ana ekranda **"Çok Oyunculu (Oda)"** sekmesine tıklayın.
2. Oyuncu adınızı yazın, senaryo (*Alternatif 1939* veya *Tarihsel 1939*), maksimum oyuncu sınırı (varsayılan **5**) ve Yapay Zeka zorluğunu seçip **"Yeni Oda Oluştur"** butonuna basın.
3. Açılan lobide ekranın üstündeki **6 haneli Oda Kodunu** veya **"Davet Linkini Kopyala"** butonunu kullanarak arkadaşlarınıza bağlantıyı gönderin (`?room=KOD`).
4. Her oyuncu kendi ülkesini seçer ve **"Hazırım"** işaretini koyar. Sunucu ülke çakışmasını otomatik engeller.
5. Oda kurucusu **"Savaşı Başlat"** dediğinde tüm oyuncuların ekranları sunucu saati ile senkronize çalışmaya başlar.
6. Bir oyuncunun bağlantısı koparsa sunucu kısa bir yeniden bağlanma penceresi tanır; süresi dolarsa diğer oyuncular **"AI Devralsın"** veya lobide bekleme kararı verebilir.

---

## Veritabanı ve Kayıt Sistemi Kurulumu

### Varsayılan Yerel Kayıt Sistemi (Kurulum Gerektirmez)
- Oyun hem **Tek Oyunculu** hem **Çok Oyunculu** odaları otomatik olarak her 30 oyun gününde ve **"Kaydet"** butonuna basıldığında sunucudaki `data/saves/` klasörüne atomik JSON dosyaları olarak kaydeder.
- Herhangi bir ek veritabanı kurmadan oyunu hemen oynayabilir, kaydedebilir ve ana menüdeki **"Kayıtlı Oyunlar"** sekmesinden devam edebilirsiniz.

### İsteğe Bağlı Üretim Veritabanı (PostgreSQL / Supabase)
Projeyi buluta kalıcı disk olmadan (stateless container) dağıtmak isterseniz `.env` dosyasına `DATABASE_URL` ekleyebilirsiniz:
1. [Supabase](https://supabase.com/) veya [Neon](https://neon.tech/) üzerinden ücretsiz bir PostgreSQL veritabanı açın.
2. Bağlantı adresini (`postgres://...`) `.env` dosyanıza `DATABASE_URL` olarak ekleyin (**asla GitHub'a gizli anahtar yüklemeyin**).

---

## İnternette Yayınlama (Deployment) Rehberi

Proje hem Express API hem WebSocket (`/ws`) sunucusu içerdiği için kalıcı Node.js sunucusu destekleyen platformlarda tek tıkla yayınlanabilir:

### Seçenek A: Render veya Railway (Önerilen, Kolay)
1. Projenizi GitHub'a yükleyin (`.env` ve `data/` hariç).
2. [Render.com](https://render.com/) veya [Railway.app](https://railway.app/) hesabınızda **New Web Service** oluşturup deponuzu seçin.
3. Ayarları şu şekilde girin:
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   - **Environment Variables**: `NODE_ENV=production`
4. Platform size otomatik olarak `https://...` adresini ve WebSocket (`wss://...`) desteğini sağlar; arkadaşlarınıza linki atıp hemen çok oyunculu oynayabilirsiniz.

### Seçenek B: Kendi Sunucunuz (VPS / Ubuntu)
```bash
git clone <depo-adresi>
cd european-conquest-1939
npm install
npm run build
PORT=3000 npm start
```
Arka planda sürekli çalışması için `pm2 start "npm start" --name ec1939` komutunu ve HTTPS/WSS için Nginx ters vekil yönlendirmesini kullanabilirsiniz.

---

## Bilinen Sınırlar ve Gelecek Geliştirmeler
- Mikro eyaletlerde (ör. Monako, San Marino) tıklama kolaylığı sağlamak için küçük elmas poligonlar kullanılmıştır; haritaya yaklaştıkça (zoom) seçilebilir.
- Varsayılan kayıt sistemi yerel dosya tabanlı (`data/saves/`) çalıştığı için disk sıfırlayan ücretsiz bulut servislerinde kalıcı kayıt için harici disk (Volume) bağlanması veya PostgreSQL modülünün aktifleştirilmesi önerilir.
- Gelecek sürümlerde özel kullanıcı hesap sistemi, sohbet kanalı filtreleri ve mod/senaryo editörü eklenebilir.
