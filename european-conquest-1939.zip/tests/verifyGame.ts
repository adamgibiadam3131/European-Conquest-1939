import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import type { MapDataStatic } from '../src/shared/types.ts';
import { COUNTRIES } from '../src/shared/data/countries.ts';
import { getCommandersForCountry } from '../src/shared/data/commanders.ts';
import {
  canPlayerSeeArmy,
  findProvincePath,
  formatGameDate,
  getArmyTotal,
} from '../src/shared/utils/gameHelpers.ts';
import { applyClientAction, createInitialGameState, tickGameDay } from '../server/engine/GameEngine.ts';
import { captureProvince } from '../server/engine/CombatEngine.ts';
import { SaveStore } from '../server/storage/SaveStore.ts';

function runTests() {
  console.log('=== European Conquest 1939 Dogrulama Testleri ===');

  // 1. MapData & Geographic Scope
  const mapRaw = fs.readFileSync(path.resolve(process.cwd(), 'src/shared/data/mapData.json'), 'utf8');
  const mapData = JSON.parse(mapRaw) as MapDataStatic;
  assert.ok(mapData.provinces.length >= 135, `Beklenen min 135 eyalet, bulunan: ${mapData.provinces.length}`);
  assert.equal(mapData.seaZones.length, 16, '16 deniz bolgesi olmali');
  const countrySet = new Set(mapData.provinces.map((p) => p.countryId));
  assert.ok(countrySet.has('TUR'), 'Turkiye haritada olmali');
  assert.ok(countrySet.has('RUS'), 'Avrupa Rusyasi haritada olmali');
  assert.ok(countrySet.has('SAU') && countrySet.has('EGY') && countrySet.has('IRN'), 'Orta Dogu ve Kuzey Afrika haritada olmali');
  assert.ok(!countrySet.has('USA') && !countrySet.has('CHN') && !countrySet.has('ZAF'), 'Amerika/Uzak Dogu/Guney Afrika haric tutulmali');
  console.log(`[OK] 1. Harita verisi dogrulandi (${mapData.provinces.length} eyalet, ${countrySet.size} ulke, ${mapData.seaZones.length} deniz bolgesi)`);

  // 2. Scenario & Commanders
  const state = createInitialGameState({
    roomId: 'test-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1' },
    mapData,
  });
  assert.equal(state.day, 0);
  assert.equal(formatGameDate(state.day), '1 Eylül 1939');

  const turCmds = getCommandersForCountry('TUR', COUNTRIES['TUR'].region);
  assert.equal(turCmds.length, 5, 'Turkiye icin 5 tarihsel komutan olmali');
  assert.equal(turCmds[0].name, 'Mustafa Kemal Atatürk');
  assert.equal(turCmds[0].isLegacy, true);
  console.log(`[OK] 2. 1939 senaryosu ve Turkiye komutanlari dogrulandi (${turCmds.map((c) => c.name).join(', ')})`);

  // 3. Recruit 1K, Commander 1-army lock, Split & Merge
  state.countries['TUR'].money = 100000;
  state.countries['TUR'].manpower = 100000;
  state.countries['TUR'].diplomacyPoints = 200;

  applyClientAction(state, mapData, 'TUR', { type: 'UNLOCK_COMMANDER', commanderId: turCmds[1].id });
  assert.equal(state.countries['TUR'].commanders[turCmds[1].id].unlocked, true, 'Komutan acilabilmeli');

  const turArmies = Object.values(state.armies).filter((a) => a.countryId === 'TUR');
  assert.ok(turArmies.length >= 1, 'Turkiye baslangic ordusuna sahip olmali');
  const mainArmy = turArmies[0];
  const beforeTotal = getArmyTotal(mainArmy.units);

  applyClientAction(state, mapData, 'TUR', {
    type: 'RECRUIT_UNIT',
    provinceId: mainArmy.provinceId,
    unitType: 'infantry',
  });
  state.paused = false;
  for (let d = 0; d < 10; d++) tickGameDay(state, mapData);
  assert.equal(getArmyTotal(mainArmy.units), beforeTotal + 1, '1K tabanli piyade basimi ve egitimi tamamlanmali');

  // Assign commander to mainArmy
  applyClientAction(state, mapData, 'TUR', {
    type: 'ASSIGN_COMMANDER',
    armyId: mainArmy.id,
    commanderId: turCmds[1].id,
  });
  assert.equal(mainArmy.commanderId, turCmds[1].id);

  // Split army and assign SAME commander -> must auto-detach from mainArmy (1-army lock!)
  applyClientAction(state, mapData, 'TUR', {
    type: 'SPLIT_ARMY',
    armyId: mainArmy.id,
  });
  const secondArmy = Object.values(state.armies).find((a) => a.countryId === 'TUR' && a.id !== mainArmy.id)!;
  assert.ok(secondArmy, 'Ordu bolunebilmeli');

  applyClientAction(state, mapData, 'TUR', {
    type: 'ASSIGN_COMMANDER',
    armyId: secondArmy.id,
    commanderId: turCmds[1].id,
  });
  assert.equal(secondArmy.commanderId, turCmds[1].id);
  assert.equal(mainArmy.commanderId, null, 'Ayni komutan baska bir orduya atandiginda onceki ordudan otomatik sokulmeli (tek-ordu kilidi)');

  applyClientAction(state, mapData, 'TUR', {
    type: 'MERGE_ARMIES',
    provinceId: mainArmy.provinceId,
  });
  const afterMergeArmies = Object.values(state.armies).filter(
    (a) => a.countryId === 'TUR' && a.provinceId === mainArmy.provinceId
  );
  assert.equal(afterMergeArmies.length, 1, 'Ordular ayni eyalette birlestirilebilmeli');
  console.log('[OK] 3. 1K asker basimi, ordu bolme/birlestirme ve tek-ordu komutan kilidi dogrulandi');

  // 4. BFS Pathfinding (Land & Overseas Port)
  const gbrCap = Object.values(state.provinces).find((p) => p.controllerId === 'UK' && COUNTRIES['UK'].capitalProvinceId === p.id) ||
    Object.values(state.provinces).find((p) => p.controllerId === 'UK')!;
  const fraCap = Object.values(state.provinces).find((p) => p.controllerId === 'FRA' && COUNTRIES['FRA'].capitalProvinceId === p.id) ||
    Object.values(state.provinces).find((p) => p.controllerId === 'FRA')!;
  state.countries['UK'].diplomacyPoints = 200;
  applyClientAction(state, mapData, 'UK', {
    type: 'DIPLOMACY_ACTION',
    targetCountryId: 'FRA',
    action: 'declare_war',
  });
  const seaPath = findProvincePath(state, mapData, 'UK', gbrCap.id, fraCap.id);
  assert.ok(seaPath && seaPath.length > 0 && seaPath[seaPath.length - 1] === fraCap.id, 'Liman uzerinden denizasiri BFS rota calismali');
  console.log(`[OK] 4. Deniz asiri BFS rota dogrulandi (${gbrCap.id} -> ${seaPath!.join(' -> ')})`);

  // 5. 12-Factor Combat Engine: High-Tech + Commander + Artillery + Air Support vs Larger Low-Tech Force
  const combatState = createInitialGameState({
    roomId: 'combat-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { GER: 'p1' },
    mapData,
  });

  const polProv = Object.values(combatState.provinces).find((p) => p.controllerId === 'POL')!;
  const polStatic = mapData.provinces.find((p) => p.id === polProv.id)!;
  const deuNeighborId =
    polStatic.neighbors.find((nid) => combatState.provinces[nid]?.controllerId === 'GER') ||
    Object.values(combatState.provinces).find((p) => p.controllerId === 'GER')!.id;

  if (!polStatic.neighbors.includes(deuNeighborId)) {
    polStatic.neighbors.push(deuNeighborId);
    mapData.provinces.find((p) => p.id === deuNeighborId)!.neighbors.push(polProv.id);
  }

  combatState.countries['GER'].diplomacyPoints = 100;
  applyClientAction(combatState, mapData, 'GER', {
    type: 'DIPLOMACY_ACTION',
    targetCountryId: 'POL',
    action: 'declare_war',
  });

  // Remove any other POL/GER armies in those 2 provinces so battle is isolated & clean
  for (const [id, a] of Object.entries(combatState.armies)) {
    if (a.provinceId === deuNeighborId || a.provinceId === polProv.id) {
      delete combatState.armies[id];
    }
  }

  combatState.countries['GER'].researchedTechs.push(
    'inf_1', 'inf_2', 'inf_3',
    'tank_1', 'tank_2', 'tank_3',
    'art_1', 'art_2',
    'air_1', 'air_2'
  );
  const deuCmd = getCommandersForCountry('GER', 'Avrupa')[0];
  combatState.countries['GER'].commanders[deuCmd.id].unlocked = true;
  combatState.countries['GER'].commanders[deuCmd.id].assignedArmyId = 'deu_elite';

  combatState.armies['deu_elite'] = {
    id: 'deu_elite',
    name: 'Elit Kolordu',
    countryId: 'GER',
    provinceId: deuNeighborId,
    units: { infantry: 8, tank: 4, antitank: 1, artillery: 4, motorized: 3, antiair: 0 },
    commanderId: deuCmd.id,
    experience: 65,
    morale: 98,
    supply: 95,
    path: [polProv.id],
    moveProgress: 0,
    inBattleId: null,
    isRetreating: false,
  };

  combatState.airWings['deu_cas'] = {
    id: 'deu_cas',
    countryId: 'GER',
    provinceId: deuNeighborId,
    type: 'cas',
    count: 25,
    mission: 'cas',
    targetProvinceId: polProv.id,
  };

  combatState.armies['pol_militia'] = {
    id: 'pol_militia',
    name: 'Savunma Alayi',
    countryId: 'POL',
    provinceId: polProv.id,
    units: { infantry: 26, tank: 0, antitank: 0, artillery: 0, motorized: 0, antiair: 0 },
    commanderId: null,
    experience: 5,
    morale: 65,
    supply: 75,
    path: [],
    moveProgress: 0,
    inBattleId: null,
    isRetreating: false,
  };

  combatState.paused = false;
  for (let d = 0; d < 35; d++) {
    tickGameDay(combatState, mapData);
    if (combatState.provinces[polProv.id].controllerId === 'GER') break;
  }
  assert.equal(
    combatState.provinces[polProv.id].controllerId,
    'GER',
    'Yuksek teknoloji, komutan, topcu ve hava destekli 20K ordu 26K dusuk teknolojili orduyu yenip eyaleti fethetmeli'
  );
  console.log('[OK] 5. 12 kriterli savas motoru ve aninda harita fethi dogrulandi');

  // 6. 5-step Nuclear Research & Nuclear Strike
  const nukeState = createInitialGameState({
    roomId: 'nuke-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { GER: 'p1' },
    mapData,
  });
  const deu = nukeState.countries['GER'];
  deu.money = 1000000;
  deu.diplomacyPoints = 200;
  deu.uranium = 120;
  deu.researchedTechs.push('eco_slots', 'radar_2', 'air_bomber_1');
  const nukeSteps = ['nuke_physics', 'nuke_uranium', 'nuke_facility', 'nuke_advanced', 'nuke_weapon'];
  nukeState.paused = false;
  for (const step of nukeSteps) {
    applyClientAction(nukeState, mapData, 'GER', { type: 'START_RESEARCH', techId: step });
    assert.ok(
      deu.activeResearch.some((r) => r.techId === step),
      `${step} arastirmasi kuyruga girmeli`
    );
    for (let i = 0; i < 65 && !deu.researchedTechs.includes(step); i++) {
      tickGameDay(nukeState, mapData);
    }
    assert.ok(deu.researchedTechs.includes(step), `${step} tamamlanmali`);
  }

  // Build nuclear facility & accumulate uranium -> daily tick creates nuke automatically
  const deuCap = Object.values(nukeState.provinces).find((p) => p.controllerId === 'GER')!;
  deuCap.buildings.nuclear_facility = 1;
  deu.uranium = 110;
  tickGameDay(nukeState, mapData);
  assert.ok(deu.nukes >= 1, 'Nukleer tesis ve uranyum ile atom bombasi uretilmeli');

  applyClientAction(nukeState, mapData, 'GER', {
    type: 'DIPLOMACY_ACTION',
    targetCountryId: 'POL',
    action: 'declare_war',
  });
  const targetPol = Object.values(nukeState.provinces).find((p) => p.controllerId === 'POL')!;
  applyClientAction(nukeState, mapData, 'GER', { type: 'LAUNCH_NUKE', targetProvinceId: targetPol.id });
  assert.equal(nukeState.provinces[targetPol.id].nuked, true, 'Nukleer saldiri eyaleti isaretlemeli');
  console.log('[OK] 6. 5 asamali nukleer teknoloji zinciri ve nukleer saldiri dogrulandi');

  // 7. SaveStore atomic save / load / delete
  const slotId = `test_verify_${Date.now()}`;
  const saveMeta = SaveStore.saveGame(slotId, 'Dogrulama Kaydi', state);
  assert.equal(saveMeta.slotId, slotId);
  const list = SaveStore.listSaves();
  assert.ok(list.some((s) => s.slotId === slotId), 'Kayit listesinde gorunmeli');
  const loaded = SaveStore.loadGame(slotId);
  assert.ok(loaded && loaded.state.day === state.day, 'Kayit yuklenebilmeli');
  SaveStore.deleteSave(slotId);
  console.log('[OK] 7. Atomik JSON kayit/yukleme/silme sistemi dogrulandi');

  // 8. Victory Threshold (75%)
  const winState = createInitialGameState({
    roomId: 'win-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1' },
    mapData,
  });
  const allProvs = Object.values(winState.provinces);
  const needed = Math.ceil(allProvs.length * 0.76);
  for (let i = 0; i < needed; i++) {
    allProvs[i].controllerId = 'TUR';
  }
  winState.paused = false;
  tickGameDay(winState, mapData);
  assert.ok(winState.victory !== null, '75% toprak kontrolunde zafer tetiklenmeli');
  assert.ok(winState.victory!.winnerIds.includes('TUR'), 'Kazanan ulke TUR olmali');
  console.log(`[OK] 8. %75 Zafer kosulu dogrulandi (%${winState.victory!.controlPercent} kontrol)`);

  // 9. Capital Capture = Total Country Conquest
  const capState = createInitialGameState({
    roomId: 'cap-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1' },
    mapData,
  });
  const greCapId = COUNTRIES['GRE'].capitalProvinceId;
  const greInitialProvs = Object.values(capState.provinces).filter((p) => p.controllerId === 'GRE').length;
  assert.ok(greInitialProvs >= 1 && Boolean(capState.provinces[greCapId]), 'GRE baskenti ve topraklari olmali');
  captureProvince(capState, mapData, greCapId, 'TUR');
  const greLeft = Object.values(capState.provinces).filter((p) => p.controllerId === 'GRE').length;
  assert.equal(greLeft, 0, 'Baskent dusunce tum eyaletler fethedilmeli');
  assert.equal(capState.countries['GRE'].eliminated, true, 'Baskenti dusen ulke elenmeli');
  console.log(`[OK] 9. Baskent fethi ile tum ulkenin ilhak edilmesi dogrulandi (GRE -> TUR, ${greInitialProvs} eyalet)`);

  // 10. Peace Treaty (Provinces, Vassalization, Money, Manpower) & Independence
  const peaceState = createInitialGameState({
    roomId: 'peace-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1' },
    mapData,
  });
  peaceState.countries['TUR'].diplomacyPoints = 200;
  peaceState.countries['BUL'].diplomacyPoints = 100;
  const bulMoneyBefore = peaceState.countries['BUL'].money;
  const bulMpBefore = peaceState.countries['BUL'].manpower;
  const turMoneyBefore = peaceState.countries['TUR'].money;

  // Give TUR overwhelming strength so AI accepts heavy treaty + vassalization
  const bulProvs = Object.values(peaceState.provinces).filter((p) => p.controllerId === 'BUL');
  const nonCapBul = bulProvs.find((p) => p.id !== COUNTRIES['BUL'].capitalProvinceId);
  peaceState.armies['tur_super'] = {
    id: 'tur_super',
    name: 'Zafer Ordusu',
    countryId: 'TUR',
    provinceId: 'tur_istanbul',
    units: { infantry: 80, tank: 30, antitank: 10, artillery: 20, motorized: 10, antiair: 5 },
    commanderId: null,
    experience: 50,
    morale: 100,
    supply: 95,
    path: [],
    moveProgress: 0,
    inBattleId: null,
    isRetreating: false,
  };

  applyClientAction(peaceState, mapData, 'TUR', {
    type: 'DIPLOMACY_ACTION',
    targetCountryId: 'BUL',
    action: 'declare_war',
  });
  applyClientAction(peaceState, mapData, 'TUR', {
    type: 'SEND_PEACE_OFFER',
    targetCountryId: 'BUL',
    terms: {
      demandProvinceIds: nonCapBul && bulProvs.length > 1 ? [nonCapBul.id] : [],
      cedeProvinceIds: [],
      vassalizeTarget: true,
      becomeVassal: false,
      demandMoney: 5000,
      demandManpower: 3000,
    },
  });

  assert.equal(peaceState.countries['BUL'].vassalOfId, 'TUR', 'BUL, TUR vasali olmali');
  assert.ok(peaceState.countries['TUR'].money > turMoneyBefore, 'TUR para tazminati almali');
  assert.ok(peaceState.countries['BUL'].money <= bulMoneyBefore - 5000, 'BUL para odemeli');
  assert.ok(peaceState.countries['BUL'].manpower <= bulMpBefore - 3000, 'BUL insangucu vermeli');

  // Test human peace offer accept flow + declare_independence
  applyClientAction(peaceState, mapData, 'BUL', {
    type: 'DIPLOMACY_ACTION',
    targetCountryId: 'TUR',
    action: 'declare_independence',
  });
  assert.equal(peaceState.countries['BUL'].vassalOfId, null, 'Bagimsizlik ilani vasalligi bitirmeli');

  // Multiplayer offer flow when target is human
  peaceState.countries['BUL'].isHuman = true;
  applyClientAction(peaceState, mapData, 'TUR', {
    type: 'SEND_PEACE_OFFER',
    targetCountryId: 'BUL',
    terms: {
      demandProvinceIds: [],
      cedeProvinceIds: [],
      vassalizeTarget: true,
      becomeVassal: false,
      demandMoney: 1000,
      demandManpower: 0,
    },
  });
  assert.equal(peaceState.peaceOffers.length, 1, 'Insan hedefe baris teklifi kuyruga girmeli');
  applyClientAction(peaceState, mapData, 'BUL', {
    type: 'RESPOND_PEACE_OFFER',
    offerId: peaceState.peaceOffers[0].id,
    accept: true,
  });
  assert.equal(peaceState.countries['BUL'].vassalOfId, 'TUR', 'Insan kabul edince vasallasma uygulanmali');
  console.log('[OK] 10. Gelismis baris masasi, vasallasma, tazminat ve bagimsizlik savasi dogrulandi');

  // 11. Upright Mercator Map Projection, Fog-of-War Border Neighbor Visibility, and Own-City Army March
  const ankaraStatic = mapData.provinces.find((p) => p.id === 'tur_ankara')!;
  const istStatic = mapData.provinces.find((p) => p.id === 'tur_istanbul')!;
  const lenStatic = mapData.provinces.find((p) => p.id === 'rus_leningrad')!;
  assert.ok(ankaraStatic.x > istStatic.x, 'Dik Mercator projeksiyonunda Ankara Istanbulun dogusunda olmali');
  assert.ok(Math.abs(ankaraStatic.y - istStatic.y) < 35, 'Harita yamuk olmamali (Ankara ve Istanbul yatay hizada)');
  assert.ok(lenStatic.x > 900, 'Rusya batim/wrap hatasi duzeltilmis olmali');

  const fowState = createInitialGameState({
    roomId: 'fow-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1' },
    mapData,
  });
  const ownTurArmy = Object.values(fowState.armies).find((a) => a.countryId === 'TUR')!;
  const bulArmy = Object.values(fowState.armies).find((a) => a.countryId === 'BUL')!;
  const espArmy = Object.values(fowState.armies).find((a) => a.countryId === 'ESP')!;
  assert.equal(canPlayerSeeArmy(fowState, mapData, 'TUR', ownTurArmy), true, 'Kendi ordusunu gormeli');
  assert.equal(canPlayerSeeArmy(fowState, mapData, 'TUR', bulArmy), true, 'Sinir komsusu BUL ordusunu gormeli');
  assert.equal(canPlayerSeeArmy(fowState, mapData, 'TUR', espArmy), false, 'Sinir komsusu olmayan ESP ordusunu gormemeli');

  // March own army across own cities
  const targetOwnCity = Object.values(fowState.provinces).find(
    (p) => p.controllerId === 'TUR' && p.id !== ownTurArmy.provinceId
  )!;
  applyClientAction(fowState, mapData, 'TUR', {
    type: 'MOVE_ARMY',
    armyId: ownTurArmy.id,
    targetProvinceId: targetOwnCity.id,
  });
  assert.ok(ownTurArmy.path.length > 0 && ownTurArmy.path[ownTurArmy.path.length - 1] === targetOwnCity.id, 'Kendi sehrine rota olusturulmali');
  fowState.paused = false;
  for (let d = 0; d < 20 && ownTurArmy.provinceId !== targetOwnCity.id; d++) {
    tickGameDay(fowState, mapData);
  }
  assert.equal(ownTurArmy.provinceId, targetOwnCity.id, 'Ordu kendi sehirleri arasinda yuruyerek hedef sehre ulasmali');
  console.log('[OK] 11. Duz Mercator haritasi, sinir komsusu gorus kurali ve kendi sehirleri arasi ordu hareketi dogrulandi');

  // 12. Auto-merge when two armies arrive in same city + Custom recruitProvinceId
  const mergeState = createInitialGameState({
    roomId: 'merge-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1' },
    mapData,
  });
  const turList = Object.values(mergeState.armies).filter((a) => a.countryId === 'TUR');
  assert.ok(turList.length >= 2, 'TUR baslangicta en az 2 orduya sahip olmali');
  const a1 = turList[0];
  const a2 = turList[1];
  const combinedBefore = getArmyTotal(a1.units) + getArmyTotal(a2.units);
  applyClientAction(mergeState, mapData, 'TUR', {
    type: 'MOVE_ARMY',
    armyId: a2.id,
    targetProvinceId: a1.provinceId,
  });
  mergeState.paused = false;
  for (let d = 0; d < 20; d++) {
    tickGameDay(mergeState, mapData);
    const inProv = Object.values(mergeState.armies).filter(
      (a) => a.countryId === 'TUR' && a.provinceId === a1.provinceId
    );
    if (inProv.length === 1 && getArmyTotal(inProv[0].units) >= combinedBefore) break;
  }
  const turLeft = Object.values(mergeState.armies).filter((a) => a.countryId === 'TUR');
  assert.equal(turLeft.length, 1, 'Iki ordu ayni sehre tasininca otomatik birlesmeli');
  assert.equal(getArmyTotal(turLeft[0].units), combinedBefore, 'Birlesen ordunun asker sayisi iki ordunun toplami olmali');

  // Test SET_RECRUIT_PROVINCE -> new recruited troops spawn in chosen city
  const izmirProv = Object.values(mergeState.provinces).find(
    (p) => p.controllerId === 'TUR' && p.id !== turLeft[0].provinceId
  )!;
  mergeState.countries['TUR'].money = 100000;
  mergeState.countries['TUR'].manpower = 100000;
  applyClientAction(mergeState, mapData, 'TUR', {
    type: 'SET_RECRUIT_PROVINCE',
    provinceId: izmirProv.id,
  });
  assert.equal(mergeState.countries['TUR'].recruitProvinceId, izmirProv.id, 'Ordu olusturma sehri guncellenmeli');
  applyClientAction(mergeState, mapData, 'TUR', {
    type: 'RECRUIT_UNIT',
    unitType: 'infantry',
  });
  for (let d = 0; d < 10; d++) tickGameDay(mergeState, mapData);
  const spawnedAtIzmir = Object.values(mergeState.armies).find(
    (a) => a.countryId === 'TUR' && a.provinceId === izmirProv.id
  );
  assert.ok(spawnedAtIzmir && getArmyTotal(spawnedAtIzmir.units) >= 1, 'Egitilen birlik secilen cikis sehrinde olusmali');
  console.log('[OK] 12. Ayni sehirde otomatik ordu birlesimi ve ozel ordu olusturma sehri secimi dogrulandi');

  // 13. Head-on border crossing combat (A -> B vs B -> A) & Friendly-city combat against enemy invader
  const clashState = createInitialGameState({
    roomId: 'clash-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1', BUL: 'p2' },
    mapData,
  });
  clashState.paused = false;
  clashState.countries['TUR'].diplomacyPoints = 100;
  applyClientAction(clashState, mapData, 'TUR', {
    type: 'DIPLOMACY_ACTION',
    targetCountryId: 'BUL',
    action: 'declare_war',
  });

  // Isolate 1 TUR army on tur_istanbul and 1 BUL army on bul_sofia marching directly into each other
  for (const a of Object.values(clashState.armies)) {
    if (a.countryId === 'TUR' || a.countryId === 'BUL') {
      delete clashState.armies[a.id];
    }
  }
  clashState.armies['test_tur_clash'] = {
    id: 'test_tur_clash',
    name: 'TUR Clash',
    countryId: 'TUR',
    provinceId: 'tur_istanbul',
    units: { infantry: 12, tank: 2, antitank: 2, artillery: 2, motorized: 0, antiair: 0 },
    commanderId: null,
    experience: 10,
    morale: 100,
    supply: 90,
    path: [],
    moveProgress: 0,
    inBattleId: null,
    isRetreating: false,
  };
  clashState.armies['test_bul_clash'] = {
    id: 'test_bul_clash',
    name: 'BUL Clash',
    countryId: 'BUL',
    provinceId: 'bul_sofia',
    units: { infantry: 12, tank: 0, antitank: 1, artillery: 2, motorized: 0, antiair: 0 },
    commanderId: null,
    experience: 10,
    morale: 100,
    supply: 90,
    path: [],
    moveProgress: 0,
    inBattleId: null,
    isRetreating: false,
  };

  applyClientAction(clashState, mapData, 'TUR', {
    type: 'MOVE_ARMY',
    armyId: 'test_tur_clash',
    targetProvinceId: 'bul_sofia',
  });
  applyClientAction(clashState, mapData, 'BUL', {
    type: 'MOVE_ARMY',
    armyId: 'test_bul_clash',
    targetProvinceId: 'tur_istanbul',
  });

  let headOnBattleSeen = false;
  for (let d = 0; d < 5; d++) {
    tickGameDay(clashState, mapData);
    const activeBattles = Object.values(clashState.battles);
    if (activeBattles.length > 0) {
      headOnBattleSeen = true;
      const bat = activeBattles[0];
      assert.notEqual(bat.attackerCountryId, bat.defenderCountryId, 'Saldiran ve savunan farkli ulkeler olmali');
      assert.ok(clashState.armies['test_tur_clash'].inBattleId === bat.id, 'TUR ordusu kafa kafaya carpismada savasa girmeli');
      assert.ok(clashState.armies['test_bul_clash'].inBattleId === bat.id, 'BUL ordusu icinden gecip gitmeden savasa girmeli');
      break;
    }
  }
  assert.equal(headOnBattleSeen, true, 'Karsi yonden gelen iki ordu birbirini teget gecmeden carpismali');

  // Test friendly city re-entry combat when enemy stands on our own controlled tile
  const friendlyClashState = createInitialGameState({
    roomId: 'friendly-clash-room',
    mode: 'singleplayer',
    scenarioId: '1939_alt',
    difficulty: 'normal',
    victoryThreshold: 75,
    humanAssignments: { TUR: 'p1', BUL: 'p2' },
    mapData,
  });
  friendlyClashState.paused = false;
  friendlyClashState.countries['TUR'].diplomacyPoints = 100;
  applyClientAction(friendlyClashState, mapData, 'TUR', {
    type: 'DIPLOMACY_ACTION',
    targetCountryId: 'BUL',
    action: 'declare_war',
  });
  for (const a of Object.values(friendlyClashState.armies)) {
    if (a.countryId === 'TUR' || a.countryId === 'BUL') {
      delete friendlyClashState.armies[a.id];
    }
  }
  // TUR controls tur_istanbul, BUL invader is sitting in tur_istanbul, TUR moves from tur_ankara -> tur_istanbul
  friendlyClashState.armies['tur_relief'] = {
    id: 'tur_relief',
    name: 'TUR Relief',
    countryId: 'TUR',
    provinceId: 'tur_ankara',
    units: { infantry: 14, tank: 2, antitank: 2, artillery: 2, motorized: 0, antiair: 0 },
    commanderId: null,
    experience: 10,
    morale: 100,
    supply: 90,
    path: [],
    moveProgress: 0,
    inBattleId: null,
    isRetreating: false,
  };
  friendlyClashState.armies['bul_raider'] = {
    id: 'bul_raider',
    name: 'BUL Raider',
    countryId: 'BUL',
    provinceId: 'tur_istanbul',
    units: { infantry: 8, tank: 0, antitank: 1, artillery: 1, motorized: 0, antiair: 0 },
    commanderId: null,
    experience: 10,
    morale: 100,
    supply: 90,
    path: [],
    moveProgress: 0,
    inBattleId: null,
    isRetreating: false,
  };
  applyClientAction(friendlyClashState, mapData, 'TUR', {
    type: 'MOVE_ARMY',
    armyId: 'tur_relief',
    targetProvinceId: 'tur_istanbul',
  });
  let friendlyReentryBattle: { attackerCountryId: string; defenderCountryId: string } | null = null;
  for (let d = 0; d < 6; d++) {
    tickGameDay(friendlyClashState, mapData);
    const active = Object.values(friendlyClashState.battles)[0];
    if (active) {
      friendlyReentryBattle = active;
      break;
    }
  }
  assert.ok(friendlyReentryBattle, 'Kendi sehrimizde bulunan dusman ordusuyla da savas baslamali');
  assert.equal(friendlyReentryBattle!.attackerCountryId, 'TUR', 'Saldiran TUR olmali');
  assert.equal(friendlyReentryBattle!.defenderCountryId, 'BUL', 'Savunan kendimiz degil dusman BUL olmali');
  console.log('[OK] 13. Kafa kafaya sinir carpismasi ve kendi sehrindeki dusmanla savas baslatma dogrulandi');

  console.log(`Toplam ${Object.keys(COUNTRIES).length} ulke tanimi hazir. TUM TESTLER BASARILI!`);
}

runTests();
