import fs from 'fs';
import path from 'path';
import type { WebSocket } from 'ws';
import type {
  ClientAction,
  DifficultyLevel,
  GameState,
  MapDataStatic,
  RoomLobbyState,
  RoomPlayer,
} from '../../src/shared/types.ts';
import { applyClientAction, createInitialGameState, tickGameDay } from '../engine/GameEngine.ts';
import { SaveStore } from '../storage/SaveStore.ts';

interface ManagedRoom {
  lobby: RoomLobbyState;
  state: GameState | null;
  sockets: Map<string, WebSocket>; // playerId -> ws
  disconnectTimers: Map<string, NodeJS.Timeout>;
  tickTimer: NodeJS.Timeout | null;
}

function loadMapData(): MapDataStatic {
  const filePath = path.resolve(process.cwd(), 'src/shared/data/mapData.json');
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export class RoomManager {
  private rooms = new Map<string, ManagedRoom>(); // roomId -> room
  private codeToRoomId = new Map<string, string>(); // roomCode -> roomId
  private mapData: MapDataStatic;

  constructor() {
    this.mapData = loadMapData();
  }

  getMapData(): MapDataStatic {
    return this.mapData;
  }

  createRoom(params: {
    mode: 'singleplayer' | 'multiplayer';
    playerId: string;
    playerName: string;
    scenarioId?: '1939_alt' | '1939_hist';
    difficulty?: DifficultyLevel;
    victoryThreshold?: 75 | 80;
    maxHumanPlayers?: number;
    countryId?: string;
    loadedState?: GameState;
  }): RoomLobbyState {
    const roomId = `room_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    let roomCode = generateRoomCode();
    while (this.codeToRoomId.has(roomCode)) {
      roomCode = generateRoomCode();
    }

    const hostPlayer: RoomPlayer = {
      playerId: params.playerId,
      name: params.playerName || 'Komutan',
      countryId: params.countryId || null,
      ready: params.mode === 'singleplayer',
      connected: true,
      isHost: true,
    };

    const lobby: RoomLobbyState = {
      roomId,
      roomCode,
      mode: params.mode,
      status: params.loadedState ? 'playing' : 'lobby',
      maxHumanPlayers: params.maxHumanPlayers || 5,
      scenarioId: params.loadedState?.scenarioId || params.scenarioId || '1939_alt',
      difficulty: params.loadedState?.difficulty || params.difficulty || 'normal',
      victoryThreshold: params.loadedState?.victoryThreshold || params.victoryThreshold || 75,
      players: [hostPlayer],
    };

    let state: GameState | null = null;
    if (params.loadedState) {
      state = params.loadedState;
      state.roomId = roomId;
      // Re-bind human player
      const humanCid = Object.values(state.countries).find((c) => c.isHuman)?.id || null;
      if (humanCid) {
        hostPlayer.countryId = humanCid;
        state.countries[humanCid].playerId = params.playerId;
      }
    }

    const room: ManagedRoom = {
      lobby,
      state,
      sockets: new Map(),
      disconnectTimers: new Map(),
      tickTimer: null,
    };

    this.rooms.set(roomId, room);
    this.codeToRoomId.set(roomCode, roomId);

    if (state) {
      this.scheduleNextTick(room);
    }

    return lobby;
  }

  getRoomByCode(code: string): ManagedRoom | undefined {
    const id = this.codeToRoomId.get(code.trim().toUpperCase());
    return id ? this.rooms.get(id) : undefined;
  }

  getRoomById(roomId: string): ManagedRoom | undefined {
    return this.rooms.get(roomId);
  }

  joinConnection(roomCode: string, playerId: string, playerName: string, ws: WebSocket): { ok: boolean; error?: string } {
    const room = this.getRoomByCode(roomCode);
    if (!room) {
      return { ok: false, error: 'Oda bulunamadı. Oda kodunu kontrol edin.' };
    }

    const existing = room.lobby.players.find((p) => p.playerId === playerId);
    if (existing) {
      // Reconnect!
      existing.connected = true;
      if (playerName) existing.name = playerName;
      const timer = room.disconnectTimers.get(playerId);
      if (timer) {
        clearTimeout(timer);
        room.disconnectTimers.delete(playerId);
      }
      if (room.state && existing.countryId && room.state.countries[existing.countryId]) {
        room.state.countries[existing.countryId].isHuman = true;
        room.state.countries[existing.countryId].playerId = playerId;
      }
    } else {
      if (room.lobby.status !== 'lobby') {
        return { ok: false, error: 'Bu oyuna katılım süresi dolmuş (oyun zaten başladı).' };
      }
      if (room.lobby.players.length >= room.lobby.maxHumanPlayers) {
        return {
          ok: false,
          error: `Oda dolu (Maksimum ${room.lobby.maxHumanPlayers} oyuncu).`,
        };
      }
      room.lobby.players.push({
        playerId,
        name: playerName || `Oyuncu ${room.lobby.players.length + 1}`,
        countryId: null,
        ready: false,
        connected: true,
        isHost: false,
      });
    }

    room.sockets.set(playerId, ws);
    this.broadcastRoom(room);
    return { ok: true };
  }

  handleDisconnect(roomId: string, playerId: string) {
    const room = this.rooms.get(roomId);
    if (!room) return;
    room.sockets.delete(playerId);
    const player = room.lobby.players.find((p) => p.playerId === playerId);
    if (!player) return;
    player.connected = false;

    // Give 90s grace period for reconnect; after that, hand country over to AI
    const timer = setTimeout(() => {
      if (!player.connected && room.state && player.countryId) {
        const c = room.state.countries[player.countryId];
        if (c) {
          c.isHuman = false;
          c.playerId = null;
        }
      }
      // If all humans disconnected and room idle, clean up tick timer after 5 mins
      const anyConnected = room.lobby.players.some((p) => p.connected);
      if (!anyConnected && room.tickTimer) {
        clearTimeout(room.tickTimer);
        room.tickTimer = null;
      }
    }, 90_000);
    room.disconnectTimers.set(playerId, timer);

    this.broadcastRoom(room);
  }

  handleClientAction(roomId: string, playerId: string, action: ClientAction) {
    const room = this.rooms.get(roomId);
    if (!room) return;
    const player = room.lobby.players.find((p) => p.playerId === playerId);
    if (!player) return;

    if (action.type === 'SELECT_COUNTRY') {
      if (room.lobby.status !== 'lobby') return;
      const taken = room.lobby.players.some(
        (p) => p.playerId !== playerId && p.countryId === action.countryId
      );
      if (taken) {
        this.sendToPlayer(room, playerId, {
          type: 'ERROR',
          message: 'Bu ülke başka bir oyuncu tarafından seçilmiş.',
        });
        return;
      }
      player.countryId = action.countryId;
      this.broadcastRoom(room);
      return;
    }

    if (action.type === 'TOGGLE_READY') {
      if (room.lobby.status !== 'lobby') return;
      player.ready = !player.ready;
      this.broadcastRoom(room);
      return;
    }

    if (action.type === 'UPDATE_SETTINGS') {
      if (!player.isHost || room.lobby.status !== 'lobby') return;
      if (action.scenarioId) room.lobby.scenarioId = action.scenarioId;
      if (action.difficulty) room.lobby.difficulty = action.difficulty;
      if (action.victoryThreshold) room.lobby.victoryThreshold = action.victoryThreshold;
      if (action.maxHumanPlayers && action.maxHumanPlayers >= 2 && action.maxHumanPlayers <= 16) {
        room.lobby.maxHumanPlayers = action.maxHumanPlayers;
      }
      this.broadcastRoom(room);
      return;
    }

    if (action.type === 'START_GAME') {
      if (!player.isHost || room.lobby.status !== 'lobby') return;
      const missingCountry = room.lobby.players.some((p) => !p.countryId);
      if (missingCountry) {
        this.sendToPlayer(room, playerId, {
          type: 'ERROR',
          message: 'Başlamak için tüm oyuncular bir ülke seçmelidir.',
        });
        return;
      }
      const humanAssignments: Record<string, string> = {};
      for (const p of room.lobby.players) {
        if (p.countryId) humanAssignments[p.countryId] = p.playerId;
      }
      room.state = createInitialGameState({
        roomId: room.lobby.roomId,
        mode: room.lobby.mode,
        scenarioId: room.lobby.scenarioId,
        difficulty: room.lobby.difficulty,
        victoryThreshold: room.lobby.victoryThreshold,
        humanAssignments,
        mapData: this.mapData,
      });
      room.lobby.status = 'playing';
      this.broadcastRoom(room);
      this.scheduleNextTick(room);
      return;
    }

    // In-game actions require active GameState and assigned country
    const state = room.state;
    if (!state) return;

    if (action.type === 'SET_PAUSE') {
      if (room.lobby.mode === 'multiplayer' && !player.isHost) return;
      state.paused = action.paused;
      this.broadcastRoom(room);
      return;
    }

    if (action.type === 'SET_SPEED') {
      if (room.lobby.mode === 'multiplayer' && !player.isHost) return;
      state.speed = action.speed;
      this.broadcastRoom(room);
      return;
    }

    if (action.type === 'SAVE_GAME') {
      const slotId = `${room.lobby.mode}_${player.countryId || 'game'}_${Date.now()}`;
      SaveStore.saveGame(slotId, action.slotName, state);
      this.sendToPlayer(room, playerId, {
        type: 'SAVE_CONFIRMED',
        slotName: action.slotName,
      });
      return;
    }

    if (action.type === 'SURRENDER_TO_AI') {
      if (player.countryId && state.countries[player.countryId]) {
        state.countries[player.countryId].isHuman = false;
        state.countries[player.countryId].playerId = null;
      }
      player.countryId = null;
      this.broadcastRoom(room);
      return;
    }

    if (!player.countryId) return;
    applyClientAction(state, this.mapData, player.countryId, action);
    this.broadcastRoom(room);
  }

  private scheduleNextTick(room: ManagedRoom) {
    if (room.tickTimer) clearTimeout(room.tickTimer);
    if (!room.state || room.state.victory) return;

    const delay =
      room.state.speed === 4 ? 250 : room.state.speed === 2 ? 500 : 1000;

    room.tickTimer = setTimeout(() => {
      if (!room.state) return;
      if (!room.state.paused && !room.state.victory) {
        tickGameDay(room.state, this.mapData);
        // Auto-save every 30 game days
        if (room.state.day > 0 && room.state.day % 30 === 0) {
          try {
            SaveStore.saveGame(
              `autosave_${room.lobby.roomCode}`,
              `Otomatik Kayıt (${room.lobby.roomCode}) - Gün ${room.state.day}`,
              room.state
            );
          } catch {
            // ignore auto-save disk errors
          }
        }
        if (room.state.victory) {
          room.lobby.status = 'finished';
        }
        this.broadcastRoom(room);
      }
      this.scheduleNextTick(room);
    }, delay);
  }

  private sendToPlayer(room: ManagedRoom, playerId: string, payload: unknown) {
    const ws = room.sockets.get(playerId);
    if (ws && ws.readyState === 1) {
      ws.send(JSON.stringify(payload));
    }
  }

  private broadcastRoom(room: ManagedRoom) {
    const msg = JSON.stringify({
      type: 'ROOM_SYNC',
      lobby: room.lobby,
      state: room.state,
    });
    for (const ws of room.sockets.values()) {
      if (ws.readyState === 1) {
        ws.send(msg);
      }
    }
  }
}
