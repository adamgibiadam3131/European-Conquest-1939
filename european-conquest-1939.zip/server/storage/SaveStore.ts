import fs from 'fs';
import path from 'path';
import type { GameState } from '../../src/shared/types.ts';

export interface SaveSlotMeta {
  slotId: string;
  slotName: string;
  savedAt: string;
  day: number;
  scenarioId: string;
  humanCountryIds: string[];
  mode: 'singleplayer' | 'multiplayer';
}

const SAVE_DIR = path.resolve(process.cwd(), 'data', 'saves');

function ensureDir() {
  if (!fs.existsSync(SAVE_DIR)) {
    fs.mkdirSync(SAVE_DIR, { recursive: true });
  }
}

export class SaveStore {
  static saveGame(slotId: string, slotName: string, state: GameState): SaveSlotMeta {
    ensureDir();
    const safeId = slotId.replace(/[^a-zA-Z0-9_-]/g, '_');
    const humanCountryIds = Object.values(state.countries)
      .filter((c) => c.isHuman)
      .map((c) => c.id);

    const meta: SaveSlotMeta = {
      slotId: safeId,
      slotName: slotName || `Kayıt - Gün ${state.day}`,
      savedAt: new Date().toISOString(),
      day: state.day,
      scenarioId: state.scenarioId,
      humanCountryIds,
      mode: state.mode,
    };

    const payload = { meta, state };
    const filePath = path.join(SAVE_DIR, `${safeId}.json`);
    const tmpPath = `${filePath}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(payload), 'utf8');
    fs.renameSync(tmpPath, filePath);
    return meta;
  }

  static loadGame(slotId: string): { meta: SaveSlotMeta; state: GameState } | null {
    ensureDir();
    const safeId = slotId.replace(/[^a-zA-Z0-9_-]/g, '_');
    const filePath = path.join(SAVE_DIR, `${safeId}.json`);
    if (!fs.existsSync(filePath)) return null;
    try {
      const raw = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  static listSaves(): SaveSlotMeta[] {
    ensureDir();
    const files = fs.readdirSync(SAVE_DIR).filter((f) => f.endsWith('.json'));
    const list: SaveSlotMeta[] = [];
    for (const file of files) {
      try {
        const raw = fs.readFileSync(path.join(SAVE_DIR, file), 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed?.meta) list.push(parsed.meta);
      } catch {
        // skip corrupted save
      }
    }
    return list.sort((a, b) => b.savedAt.localeCompare(a.savedAt));
  }

  static deleteSave(slotId: string): boolean {
    ensureDir();
    const safeId = slotId.replace(/[^a-zA-Z0-9_-]/g, '_');
    const filePath = path.join(SAVE_DIR, `${safeId}.json`);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  }
}
