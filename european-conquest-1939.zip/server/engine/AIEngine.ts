import type {
  ClientAction,
  GameState,
  LandUnitType,
  MapDataStatic,
} from '../../src/shared/types.ts';
import { LAND_UNITS, BUILDINGS } from '../../src/shared/data/units.ts';
import { TECH_TREE } from '../../src/shared/data/techTree.ts';
import { getArmyTotal, getRelation } from '../../src/shared/utils/gameHelpers.ts';

function getCountryStrength(state: GameState, countryId: string): number {
  let sum = 0;
  for (const a of Object.values(state.armies)) {
    if (a.countryId === countryId) sum += getArmyTotal(a.units);
  }
  return sum;
}

export function tickAI(
  state: GameState,
  mapData: MapDataStatic,
  executeAction: (state: GameState, mapData: MapDataStatic, countryId: string, action: ClientAction) => void
) {
  const cadence = state.difficulty === 'hard' ? 2 : state.difficulty === 'normal' ? 4 : 7;
  const countryIds = Object.keys(state.countries);

  for (let i = 0; i < countryIds.length; i++) {
    const cid = countryIds[i];
    const country = state.countries[cid];
    if (!country || country.isHuman || country.eliminated) continue;

    // Stagger AI thinking across days so each day only evaluates a subset of nations
    if ((state.day + i) % cadence !== 0) continue;

    const ownedProvs = Object.values(state.provinces).filter((p) => p.controllerId === cid);
    if (ownedProvs.length === 0) continue;

    // 1. Research: keep slots busy
    if (country.activeResearch.length < country.maxResearchSlots && country.money > 8000) {
      const available = TECH_TREE.filter(
        (t) =>
          !country.researchedTechs.includes(t.id) &&
          !country.activeResearch.some((r) => r.techId === t.id) &&
          t.cost <= country.money * 0.65 &&
          t.prerequisites.every((p) => country.researchedTechs.includes(p))
      );
      if (available.length > 0) {
        // Prefer infantry, economy, artillery, tank techs
        const pick =
          available.find((t) => ['infantry', 'economy', 'tank', 'artillery'].includes(t.category)) ||
          available[0];
        executeAction(state, mapData, cid, { type: 'START_RESEARCH', techId: pick.id });
      }
    }

    // 2. Construction: build factories, housing, or military base if budget healthy
    const capitalProv =
      ownedProvs.find((p) => mapData.provinces.find((mp) => mp.id === p.id)?.isCapital) || ownedProvs[0];

    if (country.money > 22000 && capitalProv.constructions.length < 2) {
      if (country.manpower < 12000 && capitalProv.buildings.housing < BUILDINGS.housing.maxPerProvince) {
        executeAction(state, mapData, cid, {
          type: 'BUILD_STRUCTURE',
          provinceId: capitalProv.id,
          buildingType: 'housing',
        });
      } else if (capitalProv.buildings.factory < BUILDINGS.factory.maxPerProvince && Math.random() < 0.55) {
        executeAction(state, mapData, cid, {
          type: 'BUILD_STRUCTURE',
          provinceId: capitalProv.id,
          buildingType: 'factory',
        });
      } else if (capitalProv.buildings.road < 3) {
        executeAction(state, mapData, cid, {
          type: 'BUILD_STRUCTURE',
          provinceId: capitalProv.id,
          buildingType: 'road',
        });
      }
    }

    // 3. Recruit troops (balanced composition, avoid bankruptcy)
    const desiredReserve = state.difficulty === 'hard' ? 4000 : 6000;
    if (
      country.money > desiredReserve &&
      country.manpower >= 2000 &&
      country.economy.netIncome > -150 &&
      country.trainingQueue.length < 3
    ) {
      const myArmies = Object.values(state.armies).filter((a) => a.countryId === cid);
      const totalInf = myArmies.reduce((s, a) => s + a.units.infantry, 0);
      const totalTank = myArmies.reduce((s, a) => s + a.units.tank, 0);
      const totalArt = myArmies.reduce((s, a) => s + a.units.artillery, 0);
      const totalAt = myArmies.reduce((s, a) => s + a.units.antitank, 0);

      let unitToBuy: LandUnitType = 'infantry';
      if (country.researchedTechs.includes('tank_1') && totalTank < totalInf * 0.25 && country.money > 10000) {
        unitToBuy = 'tank';
      } else if (totalArt < totalInf * 0.2 && country.money > 7000) {
        unitToBuy = 'artillery';
      } else if (totalAt < totalInf * 0.18 && country.money > 6000) {
        unitToBuy = 'antitank';
      }

      if (country.money >= LAND_UNITS[unitToBuy].moneyCost) {
        executeAction(state, mapData, cid, {
          type: 'RECRUIT_UNIT',
          unitType: unitToBuy,
          provinceId: capitalProv.id,
        });
      }
    } else if (country.manpower < 3000 && country.money > 18000) {
      executeAction(state, mapData, cid, { type: 'BUY_MANPOWER_CAMPAIGN' });
    }

    // 4. Unlock & assign a commander if diplomacy points allow
    if (country.diplomacyPoints >= 65) {
      const lockedCmd = Object.values(country.commanders).find((c) => !c.unlocked);
      if (lockedCmd) {
        executeAction(state, mapData, cid, { type: 'UNLOCK_COMMANDER', commanderId: lockedCmd.id });
      }
    }
    const freeCmd = Object.values(country.commanders).find((c) => c.unlocked && !c.assignedArmyId);
    if (freeCmd) {
      const unassignedArmy = Object.values(state.armies)
        .filter((a) => a.countryId === cid && !a.commanderId)
        .sort((a, b) => getArmyTotal(b.units) - getArmyTotal(a.units))[0];
      if (unassignedArmy) {
        executeAction(state, mapData, cid, {
          type: 'ASSIGN_COMMANDER',
          commanderId: freeCmd.id,
          armyId: unassignedArmy.id,
        });
      }
    }

    // 5. Warfare, Homeland Interception & Border Defense
    const atWarWith = new Set<string>();
    for (const rel of Object.values(state.relations)) {
      if (!rel.atWar) continue;
      if (rel.countryA === cid) atWarWith.add(rel.countryB);
      if (rel.countryB === cid) atWarWith.add(rel.countryA);
    }

    const myArmies = Object.values(state.armies).filter(
      (a) => a.countryId === cid && !a.inBattleId && a.path.length === 0 && getArmyTotal(a.units) > 0
    );

    if (atWarWith.size > 0) {
      // Identify incoming enemy threats (active battles in AI territory + enemy armies marching into AI provinces)
      const threatenedProvIds: string[] = [];
      for (const battle of Object.values(state.battles)) {
        if (battle.defenderCountryId === cid) threatenedProvIds.push(battle.provinceId);
      }
      const threateningEnemies = Object.values(state.armies).filter(
        (ea) =>
          atWarWith.has(ea.countryId) &&
          getArmyTotal(ea.units) > 0 &&
          (ea.path.some((pid) => state.provinces[pid]?.controllerId === cid) ||
            mapData.provinces
              .find((mp) => mp.id === ea.provinceId)
              ?.neighbors.some((nb) => state.provinces[nb]?.controllerId === cid))
      );
      for (const te of threateningEnemies) {
        const targetedOwn = te.path.find((pid) => state.provinces[pid]?.controllerId === cid);
        if (targetedOwn && !threatenedProvIds.includes(targetedOwn)) {
          threatenedProvIds.push(targetedOwn);
        }
      }

      for (const army of myArmies) {
        const str = getArmyTotal(army.units);
        if (str < 2) continue;

        const staticProv = mapData.provinces.find((p) => p.id === army.provinceId);
        if (!staticProv) continue;

        let targetId: string | null = null;
        let bestScore = -999;

        // Priority 1: If our capital or own province is actively under battle/threat & we aren't defending it, intercept!
        if (threatenedProvIds.length > 0) {
          const capThreat = threatenedProvIds.includes(capitalProv.id) ? capitalProv.id : threatenedProvIds[0];
          if (army.provinceId !== capThreat) {
            targetId = capThreat;
          }
        }

        // Priority 2: Engage adjacent enemy armies OR capture adjacent enemy border provinces (prefer frontline clash over sneaking!)
        if (!targetId) {
          for (const nbId of staticProv.neighbors) {
            const nbProv = state.provinces[nbId];
            if (!nbProv || !atWarWith.has(nbProv.controllerId)) continue;
            const defStr = Object.values(state.armies)
              .filter((a) => a.provinceId === nbId && atWarWith.has(a.countryId))
              .reduce((s, a) => s + getArmyTotal(a.units), 0);

            if (defStr > 0 && str >= defStr * (state.difficulty === 'easy' ? 1.15 : 0.72)) {
              const score = 600 + (str - defStr);
              if (score > bestScore) {
                bestScore = score;
                targetId = nbId;
              }
            } else if (defStr === 0) {
              // Favor capturing empty border province that isn't bypassing an adjacent threat
              const score = threateningEnemies.some((te) => te.provinceId === nbId) ? 700 : 300;
              if (score > bestScore) {
                bestScore = score;
                targetId = nbId;
              }
            }
          }
        }

        // Priority 3: March toward the NEAREST at-war enemy army/frontline province (BFS hop distance, no random flanking snipes)
        if (!targetId) {
          const visited = new Set<string>([army.provinceId]);
          const q: string[] = [army.provinceId];
          while (q.length > 0 && !targetId) {
            const cur = q.shift()!;
            const curMp = mapData.provinces.find((p) => p.id === cur);
            if (!curMp) continue;
            for (const nb of curMp.neighbors) {
              if (visited.has(nb)) continue;
              visited.add(nb);
              const nbProv = state.provinces[nb];
              if (nbProv && atWarWith.has(nbProv.controllerId)) {
                targetId = nb;
                break;
              }
              if (nbProv && nbProv.controllerId === cid) {
                q.push(nb);
              }
            }
          }
        }

        if (targetId) {
          executeAction(state, mapData, cid, {
            type: 'MOVE_ARMY',
            armyId: army.id,
            targetProvinceId: targetId,
          });
        }
      }
    } else {
      // Peacetime: position armies onto border provinces instead of stacking on capital
      const borderProvs = ownedProvs.filter((op) => {
        const sp = mapData.provinces.find((p) => p.id === op.id);
        return sp?.neighbors.some((nb) => state.provinces[nb]?.controllerId !== cid);
      });
      if (borderProvs.length > 0 && myArmies.length > 0) {
        for (const army of myArmies) {
          const isOnBorder = borderProvs.some((bp) => bp.id === army.provinceId);
          if (!isOnBorder && Math.random() < 0.35) {
            const target = borderProvs[Math.floor(Math.random() * borderProvs.length)];
            executeAction(state, mapData, cid, {
              type: 'MOVE_ARMY',
              armyId: army.id,
              targetProvinceId: target.id,
            });
          }
        }
      }

      // Logical AI Diplomacy: majors on Normal/Hard may occasionally declare war on weaker neighbor or ally same-ideology neighbor
      if (state.day > 20 && country.diplomacyPoints >= 40 && Math.random() < (state.difficulty === 'hard' ? 0.08 : 0.03)) {
        const myStrength = getCountryStrength(state, cid);
        const neighborCountries = new Set<string>();
        for (const op of ownedProvs) {
          const sp = mapData.provinces.find((p) => p.id === op.id);
          for (const nb of sp?.neighbors || []) {
            const owner = state.provinces[nb]?.controllerId;
            if (owner && owner !== cid) neighborCountries.add(owner);
          }
        }

        for (const nbCid of neighborCountries) {
          if (country.vassalOfId === nbCid) continue;
          const rel = getRelation(state.relations, cid, nbCid);
          if (rel.allied || rel.nonAggression || rel.atWar) continue;
          const nbCountry = state.countries[nbCid];
          if (!nbCountry || nbCountry.eliminated || nbCountry.vassalOfId === cid) continue;
          const nbStrength = getCountryStrength(state, nbCid);

          // Small nations never pick suicidal fights against stronger neighbors
          if (myStrength >= Math.max(12, nbStrength * 1.45) && country.ideology !== 'democracy') {
            executeAction(state, mapData, cid, {
              type: 'DIPLOMACY_ACTION',
              targetCountryId: nbCid,
              action: 'declare_war',
            });
            break;
          } else if (nbCountry.ideology === country.ideology && Math.random() < 0.3) {
            executeAction(state, mapData, cid, {
              type: 'DIPLOMACY_ACTION',
              targetCountryId: nbCid,
              action: 'form_alliance',
            });
            break;
          }
        }
      }
    }
  }
}
