import type {
  AirWing,
  Army,
  BuildingType,
  ClientAction,
  CountryState,
  DifficultyLevel,
  Fleet,
  GameState,
  LandUnitType,
  MapDataStatic,
  NavalUnitType,
  PeaceTreatyTerms,
  ProductionItemType,
  ProvinceState,
  ShipInstance,
  VictorySummary,
} from '../../src/shared/types.ts';
import { COUNTRIES } from '../../src/shared/data/countries.ts';
import { SCENARIOS } from '../../src/shared/data/scenarios.ts';
import { getCommandersForCountry } from '../../src/shared/data/commanders.ts';
import { TECH_TREE } from '../../src/shared/data/techTree.ts';
import { FOCUS_TREE, IDEOLOGY_DETAILS } from '../../src/shared/data/focusTree.ts';
import {
  AIR_UNITS,
  BUILDINGS,
  LAND_UNITS,
  NAVAL_UNITS,
  PRODUCTION_ITEMS,
  TERRAIN_MODIFIERS,
} from '../../src/shared/data/units.ts';
import {
  autoMergeStationaryArmies,
  calculatePeaceEvaluation,
  canEnterProvince,
  findProvincePath,
  getArmyTotal,
  getCountryModifiers,
  getRelation,
  relationKey,
} from '../../src/shared/utils/gameHelpers.ts';
import { captureProvince, startOrJoinBattle, tickBattles } from './CombatEngine.ts';
import { tickAI } from './AIEngine.ts';

function defaultProductionAlloc(): Record<ProductionItemType, number> {
  return {
    infantry_gear: 2,
    tank_parts: 1,
    antitank_weapons: 1,
    artillery_guns: 1,
    consumer_goods: 3,
    fighters: 0,
    bombers: 0,
    warships: 0,
    submarines: 0,
  };
}

function defaultStockpiles(): Record<ProductionItemType, number> {
  return {
    infantry_gear: 45,
    tank_parts: 20,
    antitank_weapons: 25,
    artillery_guns: 25,
    consumer_goods: 120,
    fighters: 0,
    bombers: 0,
    warships: 0,
    submarines: 0,
  };
}

function defaultDailyProd(): Record<ProductionItemType, number> {
  return {
    infantry_gear: 0,
    tank_parts: 0,
    antitank_weapons: 0,
    artillery_guns: 0,
    consumer_goods: 0,
    fighters: 0,
    bombers: 0,
    warships: 0,
    submarines: 0,
  };
}

export function createInitialGameState(params: {
  roomId: string;
  mode: 'singleplayer' | 'multiplayer';
  scenarioId: '1939_alt' | '1939_hist';
  difficulty: DifficultyLevel;
  victoryThreshold: 75 | 80;
  humanAssignments: Record<string, string>; // countryId -> playerId
  mapData: MapDataStatic;
}): GameState {
  const scenario = SCENARIOS[params.scenarioId] || SCENARIOS['1939_alt'];
  const provinces: Record<string, ProvinceState> = {};

  for (const mp of params.mapData.provinces) {
    const ownerId = scenario.provinceOwnerOverrides[mp.id] || mp.countryId;
    const isCap = mp.isCapital && ownerId === mp.countryId;
    provinces[mp.id] = {
      id: mp.id,
      ownerId,
      controllerId: ownerId,
      population: mp.basePop * 1000,
      buildings: {
        factory: mp.baseFactories,
        housing: isCap ? 2 : 1,
        road: isCap ? 2 : 1,
        railway: 0,
        military_base: isCap ? 1 : 0,
        airbase: isCap || mp.baseFactories >= 4 ? 1 : 0,
        port: mp.isPort ? 1 : 0,
        radar: 0,
        nuclear_facility: 0,
      },
      constructions: [],
      supplyLevel: isCap ? 95 : 80,
      defenseLevel: isCap ? 15 : 5,
      nuked: false,
    };
  }

  const countries: Record<string, CountryState> = {};
  const armies: Record<string, Army> = {};
  const fleets: Record<string, Fleet> = {};
  const airWings: Record<string, AirWing> = {};

  for (const cStatic of Object.values(COUNTRIES)) {
    const ownedProvs = Object.values(provinces).filter((p) => p.controllerId === cStatic.id);
    const totalFactories = ownedProvs.reduce((s, p) => s + p.buildings.factory, 0);
    const totalPop = ownedProvs.reduce((s, p) => s + p.population, 0);
    const isEliminated = ownedProvs.length === 0;

    const cmdList = getCommandersForCountry(cStatic.id, cStatic.region);
    const commanders: CountryState['commanders'] = {};
    for (const cm of cmdList) {
      commanders[cm.id] = {
        id: cm.id,
        unlocked: false,
        assignedArmyId: null,
        level: 1,
        xp: 0,
      };
    }

    const startMoney = cStatic.isMajor ? 55000 : Math.max(18000, totalFactories * 7500);
    const startManpower = Math.max(15000, Math.round(totalPop * 0.008));

    countries[cStatic.id] = {
      id: cStatic.id,
      isHuman: Boolean(params.humanAssignments[cStatic.id]),
      playerId: params.humanAssignments[cStatic.id] || null,
      ideology: scenario.ideologyOverrides[cStatic.id] || cStatic.ideology,
      money: startMoney,
      manpower: startManpower,
      maxManpower: Math.max(40000, Math.round(totalPop * 0.025)),
      uranium: 0,
      nukes: 0,
      diplomacyPoints: cStatic.isMajor ? 45 : 30,
      totalFactories: Math.max(1, totalFactories),
      productionAllocations: defaultProductionAlloc(),
      stockpiles: defaultStockpiles(),
      dailyProduction: defaultDailyProd(),
      researchedTechs: cStatic.isMajor ? ['inf_1'] : [],
      activeResearch: [],
      maxResearchSlots: cStatic.isMajor ? 2 : 1,
      completedFocuses: [],
      trainingQueue: [],
      shipQueue: [],
      recruitProvinceId:
        ownedProvs.find((p) => p.id === cStatic.capitalProvinceId)?.id || ownedProvs[0]?.id || null,
      commanders,
      economy: {
        taxIncome: 0,
        consumerGoodsIncome: 0,
        armyUpkeep: 0,
        navyUpkeep: 0,
        airUpkeep: 0,
        otherUpkeep: 0,
        netIncome: 0,
        factoryEfficiency: 1,
        totalFactories: Math.max(1, totalFactories),
      },
      provincesCaptured: 0,
      totalCasualtiesInflicted: 0,
      totalCasualtiesTaken: 0,
      vassalOfId: null,
      eliminated: isEliminated,
    };

    if (!isEliminated) {
      // Place starting army at capital or first owned province
      const cap =
        ownedProvs.find((p) => p.id === cStatic.capitalProvinceId) || ownedProvs[0];
      const baseInf = cStatic.isMajor ? 18 : Math.max(4, Math.min(12, totalFactories * 2));
      const baseTank = cStatic.isMajor ? 4 : 0;
      const baseArt = cStatic.isMajor ? 4 : Math.max(1, Math.floor(totalFactories / 2));
      const baseAt = cStatic.isMajor ? 4 : 1;

      if (cStatic.isMajor) {
        countries[cStatic.id].researchedTechs.push('tank_1');
      }

      const armyId = `army_${cStatic.id}_1`;
      armies[armyId] = {
        id: armyId,
        name: `${cStatic.name} 1. Ordu`,
        countryId: cStatic.id,
        provinceId: cap.id,
        units: {
          infantry: baseInf,
          tank: baseTank,
          antitank: baseAt,
          artillery: baseArt,
          motorized: 0,
          antiair: 0,
        },
        commanderId: null,
        experience: cStatic.isMajor ? 20 : 10,
        morale: 100,
        supply: 95,
        path: [],
        moveProgress: 0,
        inBattleId: null,
        isRetreating: false,
      };

      // Place secondary garrison army for larger multi-province nations
      if (ownedProvs.length >= 4) {
        const secondProv = ownedProvs.find((p) => p.id !== cap.id)!;
        const armyId2 = `army_${cStatic.id}_2`;
        armies[armyId2] = {
          id: armyId2,
          name: `${cStatic.name} 2. Kolordu`,
          countryId: cStatic.id,
          provinceId: secondProv.id,
          units: {
            infantry: Math.max(4, Math.round(baseInf * 0.55)),
            tank: Math.round(baseTank * 0.5),
            antitank: Math.max(1, Math.round(baseAt * 0.5)),
            artillery: Math.max(1, Math.round(baseArt * 0.5)),
            motorized: 0,
            antiair: 0,
          },
          commanderId: null,
          experience: 12,
          morale: 100,
          supply: 92,
          path: [],
          moveProgress: 0,
          inBattleId: null,
          isRetreating: false,
        };
      }

      // Starting fleet at primary port if country has ports
      const portProv = ownedProvs.find((p) => p.buildings.port > 0);
      if (portProv) {
        const ships: ShipInstance[] = [
          { id: `ship_${cStatic.id}_tr1`, type: 'transport', name: `${cStatic.id} Nakliye I`, hp: 50, maxHp: 50 },
        ];
        if (cStatic.isMajor) {
          ships.push(
            { id: `ship_${cStatic.id}_dd1`, type: 'destroyer', name: `${cStatic.id} Muhrip I`, hp: 120, maxHp: 120 },
            { id: `ship_${cStatic.id}_dd2`, type: 'destroyer', name: `${cStatic.id} Muhrip II`, hp: 120, maxHp: 120 }
          );
          if (cStatic.id === 'UK' || cStatic.id === 'FRA' || cStatic.id === 'ITA' || cStatic.id === 'GER') {
            ships.push({
              id: `ship_${cStatic.id}_bb1`,
              type: 'battleship',
              name: `${cStatic.id} Zırhlısı`,
              hp: 380,
              maxHp: 380,
            });
          }
        }
        fleets[`fleet_${cStatic.id}_1`] = {
          id: `fleet_${cStatic.id}_1`,
          name: `${cStatic.name} Donanması`,
          countryId: cStatic.id,
          locationId: portProv.id,
          isAtSea: false,
          ships,
          mission: 'docked',
          targetSeaZoneId: null,
        };
      }

      // Starting Air Wing for major powers
      const airProv = ownedProvs.find((p) => p.buildings.airbase > 0);
      if (cStatic.isMajor && airProv) {
        countries[cStatic.id].researchedTechs.push('air_fighter_1');
        airWings[`wing_${cStatic.id}_1`] = {
          id: `wing_${cStatic.id}_1`,
          countryId: cStatic.id,
          provinceId: airProv.id,
          type: 'fighter',
          count: 15,
          mission: 'air_superiority',
          targetProvinceId: airProv.id,
        };
      }
    }
  }

  const relations: GameState['relations'] = {};
  for (const [a, b] of scenario.initialAlliances) {
    const key = relationKey(a, b);
    relations[key] = {
      countryA: a < b ? a : b,
      countryB: a < b ? b : a,
      opinion: 80,
      atWar: false,
      allied: true,
      nonAggression: true,
    };
  }
  for (const [a, b] of scenario.initialWars) {
    const key = relationKey(a, b);
    relations[key] = {
      countryA: a < b ? a : b,
      countryB: a < b ? b : a,
      opinion: -100,
      atWar: true,
      allied: false,
      nonAggression: false,
      warStartDay: 0,
    };
  }

  const state: GameState = {
    roomId: params.roomId,
    mode: params.mode,
    scenarioId: params.scenarioId,
    difficulty: params.difficulty,
    victoryThreshold: params.victoryThreshold,
    day: 0,
    paused: false,
    speed: 1,
    countries,
    provinces,
    armies,
    airWings,
    fleets,
    relations,
    peaceOffers: [],
    battles: {},
    battleHistory: [],
    notifications: [
      {
        id: 'notif_start',
        day: 0,
        type: 'info',
        title: '1 Eylül 1939 — Seferberlik Başladı',
        message: 'Fabrikalarınızı kurun, üretimi düzenleyin ve ordularınızı komuta edin.',
      },
    ],
    victory: null,
  };

  recalculateAllCountryEconomies(state);
  return state;
}

function recalculateAllCountryEconomies(state: GameState) {
  const ownedCounts: Record<string, number> = {};
  const provPopSum: Record<string, number> = {};
  const factoryCounts: Record<string, number> = {};
  const housingCounts: Record<string, number> = {};

  for (const prov of Object.values(state.provinces)) {
    const cid = prov.controllerId;
    ownedCounts[cid] = (ownedCounts[cid] || 0) + 1;
    provPopSum[cid] = (provPopSum[cid] || 0) + prov.population;
    factoryCounts[cid] = (factoryCounts[cid] || 0) + prov.buildings.factory;
    housingCounts[cid] = (housingCounts[cid] || 0) + prov.buildings.housing;
  }

  const armyUpkeepMap: Record<string, number> = {};
  for (const army of Object.values(state.armies)) {
    let cost = 0;
    for (const [ut, cnt] of Object.entries(army.units)) {
      cost += (cnt as number) * LAND_UNITS[ut as LandUnitType].dailyUpkeep;
    }
    armyUpkeepMap[army.countryId] = (armyUpkeepMap[army.countryId] || 0) + cost;
  }

  const navyUpkeepMap: Record<string, number> = {};
  for (const fleet of Object.values(state.fleets)) {
    let cost = 0;
    for (const ship of fleet.ships) {
      cost += NAVAL_UNITS[ship.type].dailyUpkeep;
    }
    navyUpkeepMap[fleet.countryId] = (navyUpkeepMap[fleet.countryId] || 0) + cost;
  }

  const airUpkeepMap: Record<string, number> = {};
  for (const wing of Object.values(state.airWings)) {
    const cost = wing.count * AIR_UNITS[wing.type].dailyUpkeep * 0.2;
    airUpkeepMap[wing.countryId] = (airUpkeepMap[wing.countryId] || 0) + cost;
  }

  for (const country of Object.values(state.countries)) {
    if (country.eliminated) continue;
    const mods = getCountryModifiers(country);
    const factories = Math.max(1, factoryCounts[country.id] || 0);
    country.totalFactories = factories;
    country.maxManpower = Math.round(
      ((provPopSum[country.id] || 500_000) * 0.025 + (housingCounts[country.id] || 0) * 8000) *
        mods.manpowerFactor
    );

    // Production allocations normalized to totalFactories
    const totalWeight = Object.values(country.productionAllocations).reduce((a, b) => a + Math.max(0, b), 0);
    const consumerShare =
      totalWeight > 0
        ? (country.productionAllocations.consumer_goods / totalWeight) * factories
        : factories * 0.35;

    const baseTax =
      ((provPopSum[country.id] || 500_000) / 1000) * 0.28 + factories * 180;
    const taxIncome = Math.round(baseTax * mods.taxIncome);
    const consumerGoodsIncome = Math.round(
      consumerShare * 115 * mods.factoryEfficiency
    );
    const armyUpkeep = Math.round(armyUpkeepMap[country.id] || 0);
    const navyUpkeep = Math.round(navyUpkeepMap[country.id] || 0);
    const airUpkeep = Math.round(airUpkeepMap[country.id] || 0);
    const otherUpkeep = Math.round(factories * 22);

    country.economy = {
      taxIncome,
      consumerGoodsIncome,
      armyUpkeep,
      navyUpkeep,
      airUpkeep,
      otherUpkeep,
      netIncome: taxIncome + consumerGoodsIncome - armyUpkeep - navyUpkeep - airUpkeep - otherUpkeep,
      factoryEfficiency: Math.round(mods.factoryEfficiency * 100),
      totalFactories: factories,
    };
  }

  // Apply daily vassal tribute (20% of positive vassal net income -> overlord)
  for (const country of Object.values(state.countries)) {
    if (country.eliminated || !country.vassalOfId) continue;
    const overlord = state.countries[country.vassalOfId];
    if (!overlord || overlord.eliminated) {
      country.vassalOfId = null;
      continue;
    }
    if (country.economy.netIncome > 0) {
      const tribute = Math.round(country.economy.netIncome * 0.2);
      country.economy.otherUpkeep += tribute;
      country.economy.netIncome -= tribute;
      overlord.economy.taxIncome += tribute;
      overlord.economy.netIncome += tribute;
    }
  }
}

export function tickGameDay(state: GameState, mapData: MapDataStatic) {
  if (state.paused || state.victory) return;
  state.day += 1;

  // 1. Update Constructions & Supply levels per province
  for (const prov of Object.values(state.provinces)) {
    const mp = mapData.provinces.find((p) => p.id === prov.id);
    if (!mp) continue;

    for (let i = prov.constructions.length - 1; i >= 0; i--) {
      const c = prov.constructions[i];
      c.daysRemaining -= 1;
      if (c.daysRemaining <= 0) {
        prov.buildings[c.buildingType] += 1;
        prov.constructions.splice(i, 1);

        if (c.buildingType === 'housing') {
          const country = state.countries[prov.controllerId];
          if (country) country.manpower = Math.min(country.maxManpower, country.manpower + 8000);
        }
      }
    }

    const country = state.countries[prov.controllerId];
    if (country?.vassalOfId && state.countries[country.vassalOfId] && !state.countries[country.vassalOfId].eliminated) {
      const ov = state.countries[country.vassalOfId];
      const key = relationKey(country.id, ov.id);
      const r = state.relations[key];
      if (!r || !r.allied || r.atWar) {
        state.relations[key] = {
          countryA: country.id < ov.id ? country.id : ov.id,
          countryB: country.id < ov.id ? ov.id : country.id,
          opinion: Math.max(40, r?.opinion || 40),
          atWar: false,
          allied: true,
          nonAggression: true,
        };
      }
    }
    const mods = country ? getCountryModifiers(country) : null;
    prov.supplyLevel = Math.min(
      100,
      60 +
        prov.buildings.road * 10 +
        prov.buildings.railway * 18 +
        (mods ? mods.supplyBonus * 100 : 0) -
        (prov.nuked ? 35 : 0)
    );
    prov.defenseLevel = Math.round(
      (TERRAIN_MODIFIERS[mp.terrain].defenseMod - 1) * 100 + prov.buildings.military_base * 15
    );
  }

  // 2. Recalculate country economies, apply income, production, research, training, uranium
  recalculateAllCountryEconomies(state);

  for (const country of Object.values(state.countries)) {
    if (country.eliminated) continue;
    const mods = getCountryModifiers(country);

    country.money = Math.max(0, Math.round(country.money + country.economy.netIncome));
    country.diplomacyPoints = Math.min(250, +(country.diplomacyPoints + 0.6 * mods.diplomacyGain).toFixed(1));
    country.manpower = Math.min(
      country.maxManpower,
      country.manpower + Math.round(Math.max(120, country.maxManpower * 0.0025))
    );

    // Production output
    const totalWeight = Object.values(country.productionAllocations).reduce((a, b) => a + Math.max(0, b), 0);
    for (const itemSpec of PRODUCTION_ITEMS) {
      if (itemSpec.requiredTech && !country.researchedTechs.includes(itemSpec.requiredTech)) {
        country.dailyProduction[itemSpec.id] = 0;
        continue;
      }
      const weight = Math.max(0, country.productionAllocations[itemSpec.id] || 0);
      const effectiveFactories = totalWeight > 0 ? (weight / totalWeight) * country.totalFactories : 0;
      const produced = +(effectiveFactories * itemSpec.perFactoryPerDay * mods.factoryEfficiency).toFixed(2);
      country.dailyProduction[itemSpec.id] = produced;
      country.stockpiles[itemSpec.id] = Math.min(
        itemSpec.maxStock,
        +(country.stockpiles[itemSpec.id] + produced).toFixed(1)
      );
    }

    // Active research
    for (let i = country.activeResearch.length - 1; i >= 0; i--) {
      const ar = country.activeResearch[i];
      ar.daysRemaining -= 1 * mods.researchSpeed;
      if (ar.daysRemaining <= 0) {
        country.activeResearch.splice(i, 1);
        if (!country.researchedTechs.includes(ar.techId)) {
          country.researchedTechs.push(ar.techId);
          const tech = TECH_TREE.find((t) => t.id === ar.techId);
          if (tech?.bonuses.researchSlots) {
            country.maxResearchSlots += tech.bonuses.researchSlots;
          }
          if (country.isHuman && tech) {
            state.notifications.unshift({
              id: `notif_tech_${Date.now()}_${Math.random()}`,
              day: state.day,
              type: 'research',
              title: `Araştırma Tamamlandı: ${tech.name}`,
              message: tech.description,
            });
          }
        }
      }
    }

    // Training Queue
    for (let i = country.trainingQueue.length - 1; i >= 0; i--) {
      const tr = country.trainingQueue[i];
      tr.daysRemaining -= 1;
      if (tr.daysRemaining <= 0) {
        country.trainingQueue.splice(i, 1);
        const targetProv =
          state.provinces[tr.targetProvinceId]?.controllerId === country.id
            ? tr.targetProvinceId
            : Object.values(state.provinces).find((p) => p.controllerId === country.id)?.id;

        if (targetProv) {
          const existingArmy = Object.values(state.armies).find(
            (a) => a.countryId === country.id && a.provinceId === targetProv && !a.inBattleId
          );
          if (existingArmy) {
            existingArmy.units[tr.unitType] += 1;
          } else {
            const newId = `army_${country.id}_${state.day}_${Math.random().toString(36).slice(2, 6)}`;
            state.armies[newId] = {
              id: newId,
              name: `${COUNTRIES[country.id]?.name || country.id} Tümeni`,
              countryId: country.id,
              provinceId: targetProv,
              units: {
                infantry: tr.unitType === 'infantry' ? 1 : 0,
                tank: tr.unitType === 'tank' ? 1 : 0,
                antitank: tr.unitType === 'antitank' ? 1 : 0,
                artillery: tr.unitType === 'artillery' ? 1 : 0,
                motorized: tr.unitType === 'motorized' ? 1 : 0,
                antiair: tr.unitType === 'antiair' ? 1 : 0,
              },
              commanderId: null,
              experience: 5,
              morale: 100,
              supply: state.provinces[targetProv]?.supplyLevel || 80,
              path: [],
              moveProgress: 0,
              inBattleId: null,
              isRetreating: false,
            };
          }
        }
      }
    }

    // Ship Queue
    for (let i = country.shipQueue.length - 1; i >= 0; i--) {
      const sq = country.shipQueue[i];
      sq.daysRemaining -= 1 * mods.navalBuildSpeed;
      if (sq.daysRemaining <= 0) {
        country.shipQueue.splice(i, 1);
        const spec = NAVAL_UNITS[sq.shipType];
        let dockedFleet = Object.values(state.fleets).find(
          (f) => f.countryId === country.id && !f.isAtSea && f.locationId === sq.provinceId
        );
        if (!dockedFleet) {
          const fid = `fleet_${country.id}_${state.day}_${Math.random().toString(36).slice(2, 5)}`;
          dockedFleet = {
            id: fid,
            name: `${COUNTRIES[country.id]?.name || country.id} Filosu`,
            countryId: country.id,
            locationId: sq.provinceId,
            isAtSea: false,
            ships: [],
            mission: 'docked',
            targetSeaZoneId: null,
          };
          state.fleets[fid] = dockedFleet;
        }
        dockedFleet.ships.push({
          id: `ship_${country.id}_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
          type: sq.shipType,
          name: `${spec.name} #${dockedFleet.ships.length + 1}`,
          hp: spec.maxHp,
          maxHp: spec.maxHp,
        });
      }
    }

    // Uranium production from nuclear facilities
    const nukeFacs = Object.values(state.provinces)
      .filter((p) => p.controllerId === country.id)
      .reduce((s, p) => s + p.buildings.nuclear_facility, 0);
    if (nukeFacs > 0) {
      country.uranium += nukeFacs * 1.5;
      if (mods.nukeReady && country.uranium >= 100) {
        country.uranium -= 100;
        country.nukes += 1;
        if (country.isHuman) {
          state.notifications.unshift({
            id: `notif_nuke_ready_${Date.now()}`,
            day: state.day,
            type: 'nuke',
            title: 'Atom Bombası Hazır!',
            message: 'Nükleer cephaneliğinize 1 adet yeni nükleer silah eklendi.',
          });
        }
      }
    }
  }

  // 3. Army movement, head-on border interception & supply update
  for (const army of Object.values(state.armies)) {
    if (!state.armies[army.id]) continue;
    if (getArmyTotal(army.units) <= 0) {
      delete state.armies[army.id];
      continue;
    }

    const curProv = state.provinces[army.provinceId];
    if (curProv) {
      // Update supply smoothly toward province supply
      const targetSupply = curProv.controllerId === army.countryId ? curProv.supplyLevel : Math.max(45, curProv.supplyLevel - 20);
      army.supply = Math.round(army.supply * 0.75 + targetSupply * 0.25);
    }

    if (army.inBattleId) continue;

    // Recover morale when idle
    if (army.path.length === 0) {
      army.morale = Math.min(100, army.morale + 2.5);
      continue;
    }

    const nextProvId = army.path[0];
    if (!canEnterProvince(state, army.countryId, nextProvId)) {
      army.path = [];
      army.moveProgress = 0;
      continue;
    }

    const mp = mapData.provinces.find((p) => p.id === nextProvId);
    const terrainMod = mp ? TERRAIN_MODIFIERS[mp.terrain].moveMod : 1;
    const roadBonus = 1 + (curProv?.buildings.road || 0) * 0.1;
    const speedStep = 38 * terrainMod * roadBonus;
    army.moveProgress += speedStep;

    // Head-on Border Clash: Prevent armies from passing through each other between adjacent provinces (A <-> B)
    const headOnEnemy = Object.values(state.armies).find(
      (other) =>
        other.id !== army.id &&
        !other.inBattleId &&
        other.provinceId === nextProvId &&
        other.path[0] === army.provinceId &&
        getArmyTotal(other.units) > 0 &&
        getRelation(state.relations, army.countryId, other.countryId).atWar
    );
    if (headOnEnemy && army.moveProgress + headOnEnemy.moveProgress >= 100) {
      headOnEnemy.moveProgress = 0;
      const battle = startOrJoinBattle(state, mapData, army, army.provinceId, nextProvId);
      if (battle) continue;
    }

    if (army.moveProgress >= 100) {
      army.moveProgress = 0;
      const targetProv = state.provinces[nextProvId];
      if (!targetProv) {
        army.path = [];
        continue;
      }

      // Always engage ANY at-war enemy army currently stationed in nextProvId (even if province controller is own/allied)
      const enemies = Object.values(state.armies).filter(
        (a) =>
          a.provinceId === nextProvId &&
          a.countryId !== army.countryId &&
          getArmyTotal(a.units) > 0 &&
          getRelation(state.relations, army.countryId, a.countryId).atWar
      );
      if (enemies.length > 0) {
        startOrJoinBattle(state, mapData, army, army.provinceId, nextProvId);
        continue;
      }

      const rel = getRelation(state.relations, army.countryId, targetProv.controllerId);
      if (targetProv.controllerId !== army.countryId && rel.atWar) {
        // Undefended enemy province -> instant capture!
        captureProvince(state, mapData, nextProvId, army.countryId);
      }

      army.provinceId = nextProvId;
      army.path.shift();
      if (army.path.length === 0 && !army.inBattleId) {
        autoMergeStationaryArmies(state, army.countryId, nextProvId, army.id);
      }
    }
  }

  // Sweep provinces: ensure hostile at-war armies in the same province always engage in battle
  const armiesByProv: Record<string, Army[]> = {};
  for (const a of Object.values(state.armies)) {
    if (a.inBattleId || getArmyTotal(a.units) <= 0) continue;
    if (!armiesByProv[a.provinceId]) armiesByProv[a.provinceId] = [];
    armiesByProv[a.provinceId].push(a);
  }
  for (const [provId, list] of Object.entries(armiesByProv)) {
    if (list.length < 2) continue;
    for (let i = 0; i < list.length; i++) {
      const a1 = list[i];
      if (!state.armies[a1.id] || a1.inBattleId) continue;
      for (let j = i + 1; j < list.length; j++) {
        const a2 = list[j];
        if (!state.armies[a2.id] || a2.inBattleId) continue;
        if (getRelation(state.relations, a1.countryId, a2.countryId).atWar) {
          startOrJoinBattle(state, mapData, a1, a1.provinceId, provId);
          break;
        }
      }
    }
  }

  // 4. Naval combat between hostile fleets at sea
  tickNavalCombat(state, mapData);

  // 5. Land Combat resolution
  tickBattles(state, mapData);

  // 6. AI decisions
  tickAI(state, mapData, applyClientAction);

  // 7. Victory evaluation
  checkVictory(state, mapData);
}

function tickNavalCombat(state: GameState, mapData: MapDataStatic) {
  const seaFleets: Record<string, Fleet[]> = {};
  for (const fleet of Object.values(state.fleets)) {
    fleet.ships = fleet.ships.filter((s) => s.hp > 0);
    if (fleet.ships.length === 0) {
      delete state.fleets[fleet.id];
      continue;
    }
    if (!fleet.isAtSea) continue;
    if (!seaFleets[fleet.locationId]) seaFleets[fleet.locationId] = [];
    seaFleets[fleet.locationId].push(fleet);
  }

  for (const [seaId, list] of Object.entries(seaFleets)) {
    if (list.length < 2) continue;
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const fa = list[i];
        const fb = list[j];
        if (fa.ships.length === 0 || fb.ships.length === 0) continue;
        const rel = getRelation(state.relations, fa.countryId, fb.countryId);
        if (!rel.atWar) continue;

        const modA = getCountryModifiers(state.countries[fa.countryId]).navalPower;
        const modB = getCountryModifiers(state.countries[fb.countryId]).navalPower;
        const atkA = fa.ships.reduce((s, sh) => s + NAVAL_UNITS[sh.type].attack, 0) * modA;
        const atkB = fb.ships.reduce((s, sh) => s + NAVAL_UNITS[sh.type].attack, 0) * modB;

        const targetB = fb.ships[Math.floor(Math.random() * fb.ships.length)];
        const targetA = fa.ships[Math.floor(Math.random() * fa.ships.length)];
        targetB.hp = Math.max(0, targetB.hp - Math.round(atkA * 0.45));
        targetA.hp = Math.max(0, targetA.hp - Math.round(atkB * 0.45));

        if (targetB.hp === 0 || targetA.hp === 0) {
          const seaName = mapData.seaZones.find((s) => s.id === seaId)?.name || seaId;
          state.notifications.unshift({
            id: `notif_naval_${Date.now()}_${Math.random()}`,
            day: state.day,
            type: 'war',
            title: `${seaName} Deniz Çatışması`,
            message: `${COUNTRIES[fa.countryId]?.name} ve ${COUNTRIES[fb.countryId]?.name} filoları arasında gemi battı!`,
          });
        }
      }
    }
  }
}

function checkVictory(state: GameState, mapData: MapDataStatic) {
  const totalLand = mapData.provinces.length;
  if (totalLand === 0) return;

  const counts: Record<string, number> = {};
  const empireCounts: Record<string, number> = {};
  for (const p of Object.values(state.provinces)) {
    counts[p.controllerId] = (counts[p.controllerId] || 0) + 1;
    const ownerNode = state.countries[p.controllerId];
    const effective = ownerNode?.vassalOfId && !state.countries[ownerNode.vassalOfId]?.eliminated
      ? ownerNode.vassalOfId
      : p.controllerId;
    empireCounts[effective] = (empireCounts[effective] || 0) + 1;
  }

  const threshold = state.victoryThreshold;

  // Build allied connected components (official alliances & vassals)
  const activeCountries = Object.keys(counts).filter((cid) => counts[cid] > 0);
  const visited = new Set<string>();

  for (const cid of activeCountries) {
    const pct = ((empireCounts[cid] || 0) / totalLand) * 100;
    if (pct >= threshold) {
      state.victory = buildVictorySummary(state, totalLand, counts, 'country', [cid], pct);
      state.paused = true;
      return;
    }

    if (visited.has(cid)) continue;
    const component: string[] = [];
    const q = [cid];
    visited.add(cid);
    while (q.length > 0) {
      const cur = q.shift()!;
      component.push(cur);
      for (const other of activeCountries) {
        if (visited.has(other)) continue;
        const rel = getRelation(state.relations, cur, other);
        if (rel.allied) {
          visited.add(other);
          q.push(other);
        }
      }
    }

    if (component.length > 1) {
      const sumProvs = component.reduce((s, id) => s + (counts[id] || 0), 0);
      const coalitionPct = (sumProvs / totalLand) * 100;
      if (coalitionPct >= threshold) {
        state.victory = buildVictorySummary(state, totalLand, counts, 'coalition', component, coalitionPct);
        state.paused = true;
        return;
      }
    }
  }
}

function buildVictorySummary(
  state: GameState,
  totalLand: number,
  counts: Record<string, number>,
  winnerType: 'country' | 'coalition',
  winnerIds: string[],
  controlPercent: number
): VictorySummary {
  const rankings = Object.values(state.countries)
    .map((c) => {
      const provs = counts[c.id] || 0;
      return {
        countryId: c.id,
        name: COUNTRIES[c.id]?.name || c.id,
        color: COUNTRIES[c.id]?.color || '#64748b',
        provinces: provs,
        controlPercent: +((provs / totalLand) * 100).toFixed(1),
        casualtiesInflicted: c.totalCasualtiesInflicted,
        casualtiesTaken: c.totalCasualtiesTaken,
        isHuman: c.isHuman,
      };
    })
    .filter((r) => r.provinces > 0 || r.isHuman)
    .sort((a, b) => b.provinces - a.provinces)
    .slice(0, 12);

  return {
    winnerType,
    winnerIds,
    winnerNames: winnerIds.map((id) => COUNTRIES[id]?.name || id),
    controlPercent: +controlPercent.toFixed(1),
    thresholdPercent: state.victoryThreshold,
    day: state.day,
    rankings,
  };
}

export function applyClientAction(
  state: GameState,
  mapData: MapDataStatic,
  countryId: string,
  action: ClientAction
) {
  const country = state.countries[countryId];
  if (!country || country.eliminated) return;

  switch (action.type) {
    case 'RECRUIT_UNIT': {
      const spec = LAND_UNITS[action.unitType];
      if (!spec) return;
      if (spec.requiredTech && !country.researchedTechs.includes(spec.requiredTech)) return;
      if (country.money < spec.moneyCost || country.manpower < spec.manpowerCost) return;

      // Consume stockpiles if available (gives faster training when equipped!)
      let hasStock = true;
      for (const [eq, amt] of Object.entries(spec.equipmentCost)) {
        if ((country.stockpiles[eq as ProductionItemType] || 0) < (amt as number)) {
          hasStock = false;
        }
      }
      if (hasStock) {
        for (const [eq, amt] of Object.entries(spec.equipmentCost)) {
          country.stockpiles[eq as ProductionItemType] -= amt as number;
        }
      }

      country.money -= spec.moneyCost;
      country.manpower -= spec.manpowerCost;

      const ownedProvs = Object.values(state.provinces).filter((p) => p.controllerId === countryId);
      const targetProv =
        (action.provinceId &&
          state.provinces[action.provinceId]?.controllerId === countryId &&
          action.provinceId) ||
        (country.recruitProvinceId &&
          state.provinces[country.recruitProvinceId]?.controllerId === countryId &&
          country.recruitProvinceId) ||
        ownedProvs.find((p) => p.id === COUNTRIES[countryId]?.capitalProvinceId)?.id ||
        ownedProvs[0]?.id;

      if (!targetProv) return;
      country.trainingQueue.push({
        id: `trn_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
        unitType: action.unitType,
        targetProvinceId: targetProv,
        daysRemaining: hasStock ? spec.trainDays : spec.trainDays + 3,
        totalDays: hasStock ? spec.trainDays : spec.trainDays + 3,
      });
      break;
    }

    case 'SET_RECRUIT_PROVINCE': {
      const prov = state.provinces[action.provinceId];
      if (!prov || prov.controllerId !== countryId) return;
      country.recruitProvinceId = action.provinceId;
      break;
    }

    case 'BUY_MANPOWER_CAMPAIGN': {
      if (country.money < 12000) return;
      country.money -= 12000;
      country.manpower = Math.min(country.maxManpower, country.manpower + 10000);
      break;
    }

    case 'BUILD_STRUCTURE': {
      const prov = state.provinces[action.provinceId];
      const mp = mapData.provinces.find((p) => p.id === action.provinceId);
      const spec = BUILDINGS[action.buildingType];
      if (!prov || !mp || !spec) return;
      if (prov.controllerId !== countryId) return;
      if (spec.requiresPort && !mp.isPort) return;
      if (spec.requiredTech && !country.researchedTechs.includes(spec.requiredTech)) return;

      const queuedCount = prov.constructions.filter((c) => c.buildingType === action.buildingType).length;
      if (prov.buildings[action.buildingType] + queuedCount >= spec.maxPerProvince) return;
      if (country.money < spec.cost) return;

      country.money -= spec.cost;
      prov.constructions.push({
        id: `bld_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
        buildingType: action.buildingType,
        daysRemaining: spec.buildDays,
        totalDays: spec.buildDays,
      });
      break;
    }

    case 'SET_PRODUCTION_ALLOCATION': {
      const item = PRODUCTION_ITEMS.find((i) => i.id === action.item);
      if (!item) return;
      if (item.requiredTech && !country.researchedTechs.includes(item.requiredTech)) return;
      country.productionAllocations[action.item] = Math.max(0, Math.min(20, Math.round(action.factories)));
      recalculateAllCountryEconomies(state);
      break;
    }

    case 'START_RESEARCH': {
      const tech = TECH_TREE.find((t) => t.id === action.techId);
      if (!tech) return;
      if (country.researchedTechs.includes(tech.id)) return;
      if (country.activeResearch.some((r) => r.techId === tech.id)) return;
      if (country.activeResearch.length >= country.maxResearchSlots) return;
      if (!tech.prerequisites.every((p) => country.researchedTechs.includes(p))) return;
      if (country.money < tech.cost) return;

      country.money -= tech.cost;
      country.activeResearch.push({
        techId: tech.id,
        daysRemaining: tech.days,
        totalDays: tech.days,
      });
      break;
    }

    case 'UNLOCK_COMMANDER': {
      const cmdState = country.commanders[action.commanderId];
      if (!cmdState || cmdState.unlocked) return;
      const list = getCommandersForCountry(countryId, COUNTRIES[countryId]?.region);
      const cmdSpec = list.find((c) => c.id === action.commanderId);
      if (!cmdSpec) return;
      if (country.diplomacyPoints < cmdSpec.unlockCost) return;

      country.diplomacyPoints -= cmdSpec.unlockCost;
      cmdState.unlocked = true;
      break;
    }

    case 'ASSIGN_COMMANDER': {
      const cmdState = country.commanders[action.commanderId];
      if (!cmdState || !cmdState.unlocked) return;

      // Detach from any previous army (1 commander = max 1 army!)
      if (cmdState.assignedArmyId && state.armies[cmdState.assignedArmyId]) {
        state.armies[cmdState.assignedArmyId].commanderId = null;
      }
      cmdState.assignedArmyId = null;

      if (action.armyId) {
        const army = state.armies[action.armyId];
        if (!army || army.countryId !== countryId) return;
        // Detach previous commander on target army if any
        if (army.commanderId && country.commanders[army.commanderId]) {
          country.commanders[army.commanderId].assignedArmyId = null;
        }
        army.commanderId = action.commanderId;
        cmdState.assignedArmyId = army.id;
      }
      break;
    }

    case 'SWITCH_IDEOLOGY': {
      if (country.ideology === action.ideology) return;
      const spec = IDEOLOGY_DETAILS[action.ideology];
      const hasDiscount = country.completedFocuses.some(
        (fid) => FOCUS_TREE.find((f) => f.id === fid)?.effects.ideologyDiscount === action.ideology
      );
      const moneyCost = hasDiscount ? Math.round(spec.switchCostMoney * 0.5) : spec.switchCostMoney;
      const dipCost = hasDiscount ? Math.round(spec.switchCostDiplomacy * 0.5) : spec.switchCostDiplomacy;

      if (country.money < moneyCost || country.diplomacyPoints < dipCost) return;
      country.money -= moneyCost;
      country.diplomacyPoints -= dipCost;
      country.ideology = action.ideology;
      recalculateAllCountryEconomies(state);
      break;
    }

    case 'COMPLETE_FOCUS': {
      const focus = FOCUS_TREE.find((f) => f.id === action.focusId);
      if (!focus || country.completedFocuses.includes(focus.id)) return;
      if (!focus.prerequisites.every((p) => country.completedFocuses.includes(p))) return;
      if (country.diplomacyPoints < focus.costDiplomacy) return;

      country.diplomacyPoints -= focus.costDiplomacy;
      country.completedFocuses.push(focus.id);
      recalculateAllCountryEconomies(state);
      break;
    }

    case 'DIPLOMACY_ACTION': {
      const target = state.countries[action.targetCountryId];
      if (!target || target.eliminated || action.targetCountryId === countryId) return;
      const key = relationKey(countryId, action.targetCountryId);
      const rel = state.relations[key] || {
        countryA: countryId < action.targetCountryId ? countryId : action.targetCountryId,
        countryB: countryId < action.targetCountryId ? action.targetCountryId : countryId,
        opinion: 0,
        atWar: false,
        allied: false,
        nonAggression: false,
      };
      state.relations[key] = rel;

      if (action.action === 'declare_war') {
        if (country.vassalOfId === action.targetCountryId || target.vassalOfId === countryId) return;
        if (rel.atWar || country.diplomacyPoints < 20) return;
        country.diplomacyPoints -= 20;
        rel.atWar = true;
        rel.allied = false;
        rel.nonAggression = false;
        rel.opinion = -100;
        rel.warStartDay = state.day;
        state.notifications.unshift({
          id: `notif_war_${Date.now()}_${Math.random()}`,
          day: state.day,
          type: 'war',
          title: 'Savaş İlanı!',
          message: `${COUNTRIES[countryId]?.name} ülkesi ${COUNTRIES[action.targetCountryId]?.name} ülkesine savaş ilan etti!`,
        });
      } else if (action.action === 'release_vassal') {
        if (target.vassalOfId !== countryId) return;
        target.vassalOfId = null;
        rel.allied = false;
        recalculateAllCountryEconomies(state);
        state.notifications.unshift({
          id: `notif_vassal_free_${Date.now()}`,
          day: state.day,
          type: 'peace',
          title: 'Vasal Özgür Bırakıldı',
          message: `${COUNTRIES[countryId]?.name}, ${COUNTRIES[action.targetCountryId]?.name} devletinin bağımsızlığını tanıdı.`,
        });
      } else if (action.action === 'declare_independence') {
        if (country.vassalOfId !== action.targetCountryId) return;
        country.vassalOfId = null;
        rel.allied = false;
        rel.nonAggression = false;
        rel.atWar = true;
        rel.opinion = -100;
        rel.warStartDay = state.day;
        recalculateAllCountryEconomies(state);
        state.notifications.unshift({
          id: `notif_indep_${Date.now()}`,
          day: state.day,
          type: 'war',
          title: 'Bağımsızlık Ayaklanması!',
          message: `${COUNTRIES[countryId]?.name}, ${COUNTRIES[action.targetCountryId]?.name} hakimiyetine karşı bağımsızlık ilan etti!`,
        });
      } else if (action.action === 'propose_peace') {
        if (!rel.atWar || country.diplomacyPoints < 15) return;
        country.diplomacyPoints -= 15;
        const borderTarget = action.demandProvinces
          ? Object.values(state.provinces).find((p) => {
              if (p.controllerId !== action.targetCountryId) return false;
              const mp = mapData.provinces.find((x) => x.id === p.id);
              return mp?.neighbors.some((nb) => state.provinces[nb]?.controllerId === countryId);
            })
          : null;
        const quickTerms: PeaceTreatyTerms = {
          demandProvinceIds: borderTarget ? [borderTarget.id] : [],
          cedeProvinceIds: [],
          vassalizeTarget: false,
          becomeVassal: false,
          demandMoney: 0,
          demandManpower: 0,
        };
        const evalRes = !target.isHuman
          ? calculatePeaceEvaluation(state, countryId, action.targetCountryId, quickTerms)
          : { willAiAccept: true };
        if (evalRes.willAiAccept) {
          executePeaceTreaty(state, mapData, countryId, action.targetCountryId, quickTerms);
        }
      } else if (action.action === 'form_alliance') {
        if (rel.atWar || rel.allied || country.diplomacyPoints < 15) return;
        const accept = !target.isHuman
          ? rel.opinion >= -15 || target.ideology === country.ideology
          : true;
        if (accept) {
          country.diplomacyPoints -= 15;
          rel.allied = true;
          rel.nonAggression = true;
          rel.opinion = Math.min(100, rel.opinion + 45);
          state.notifications.unshift({
            id: `notif_ally_${Date.now()}`,
            day: state.day,
            type: 'alliance',
            title: 'İttifak Kuruldu',
            message: `${COUNTRIES[countryId]?.name} ve ${COUNTRIES[action.targetCountryId]?.name} resmî müttefik oldu.`,
          });
        }
      } else if (action.action === 'break_alliance') {
        if (target.vassalOfId === countryId || country.vassalOfId === action.targetCountryId) return;
        rel.allied = false;
        rel.opinion = Math.max(-100, rel.opinion - 40);
      } else if (action.action === 'non_aggression') {
        if (rel.atWar || country.diplomacyPoints < 10) return;
        country.diplomacyPoints -= 10;
        rel.nonAggression = true;
        rel.opinion = Math.min(100, rel.opinion + 20);
      } else if (action.action === 'send_aid') {
        if (rel.atWar || country.money < 5000) return;
        country.money -= 5000;
        target.money += 5000;
        rel.opinion = Math.min(100, rel.opinion + 25);
      }
      break;
    }

    case 'SEND_PEACE_OFFER': {
      const target = state.countries[action.targetCountryId];
      if (!target || target.eliminated || action.targetCountryId === countryId) return;
      const rel = getRelation(state.relations, countryId, action.targetCountryId);
      if (!rel.atWar || country.diplomacyPoints < 15) return;

      country.diplomacyPoints -= 15;
      const sanitizedTerms: PeaceTreatyTerms = {
        demandProvinceIds: (action.terms.demandProvinceIds || []).filter(
          (pid) => state.provinces[pid]?.controllerId === action.targetCountryId
        ),
        cedeProvinceIds: (action.terms.cedeProvinceIds || []).filter(
          (pid) => state.provinces[pid]?.controllerId === countryId
        ),
        vassalizeTarget: Boolean(action.terms.vassalizeTarget && !action.terms.becomeVassal),
        becomeVassal: Boolean(action.terms.becomeVassal && !action.terms.vassalizeTarget),
        demandMoney: Math.max(0, Math.round(action.terms.demandMoney || 0)),
        demandManpower: Math.max(0, Math.round(action.terms.demandManpower || 0)),
      };

      if (!target.isHuman) {
        const evaluation = calculatePeaceEvaluation(state, countryId, action.targetCountryId, sanitizedTerms);
        if (evaluation.willAiAccept) {
          executePeaceTreaty(state, mapData, countryId, action.targetCountryId, sanitizedTerms);
        } else {
          state.notifications.unshift({
            id: `notif_peace_reject_${Date.now()}_${Math.random()}`,
            day: state.day,
            type: 'info',
            title: `${COUNTRIES[action.targetCountryId]?.name} Barış Teklifini Reddetti`,
            message: evaluation.summaryText,
          });
        }
      } else {
        // Queue pending human multiplayer treaty offer
        state.peaceOffers = state.peaceOffers.filter(
          (o) => !(o.fromCountryId === countryId && o.toCountryId === action.targetCountryId)
        );
        state.peaceOffers.push({
          id: `peace_${countryId}_${action.targetCountryId}_${Date.now()}`,
          fromCountryId: countryId,
          toCountryId: action.targetCountryId,
          terms: sanitizedTerms,
          createdDay: state.day,
        });
      }
      break;
    }

    case 'RESPOND_PEACE_OFFER': {
      const idx = state.peaceOffers.findIndex(
        (o) => o.id === action.offerId && o.toCountryId === countryId
      );
      if (idx === -1) return;
      const offer = state.peaceOffers[idx];
      state.peaceOffers.splice(idx, 1);
      if (action.accept) {
        executePeaceTreaty(state, mapData, offer.fromCountryId, offer.toCountryId, offer.terms);
      } else {
        state.notifications.unshift({
          id: `notif_peace_declined_${Date.now()}`,
          day: state.day,
          type: 'info',
          title: 'Barış Teklifi Reddedildi',
          message: `${COUNTRIES[countryId]?.name} sunulan barış koşullarını kabul etmedi.`,
        });
      }
      break;
    }

    case 'MOVE_ARMY': {
      const army = state.armies[action.armyId];
      if (!army || army.countryId !== countryId || army.inBattleId) return;
      const path = findProvincePath(state, mapData, countryId, army.provinceId, action.targetProvinceId);
      if (path && path.length > 0) {
        army.path = path;
        army.moveProgress = 0;
      }
      break;
    }

    case 'SPLIT_ARMY': {
      const army = state.armies[action.armyId];
      if (!army || army.countryId !== countryId || army.inBattleId) return;
      const total = getArmyTotal(army.units);
      if (total < 2) return;

      const halfUnits = {
        infantry: Math.floor(army.units.infantry / 2),
        tank: Math.floor(army.units.tank / 2),
        antitank: Math.floor(army.units.antitank / 2),
        artillery: Math.floor(army.units.artillery / 2),
        motorized: Math.floor(army.units.motorized / 2),
        antiair: Math.floor(army.units.antiair / 2),
      };
      if (getArmyTotal(halfUnits) === 0) halfUnits.infantry = 1;

      army.units.infantry -= halfUnits.infantry;
      army.units.tank -= halfUnits.tank;
      army.units.antitank -= halfUnits.antitank;
      army.units.artillery -= halfUnits.artillery;
      army.units.motorized -= halfUnits.motorized;
      army.units.antiair -= halfUnits.antiair;

      const newId = `army_${countryId}_${state.day}_${Math.random().toString(36).slice(2, 6)}`;
      state.armies[newId] = {
        id: newId,
        name: `${army.name} (II)`,
        countryId,
        provinceId: army.provinceId,
        units: halfUnits,
        commanderId: null,
        experience: army.experience,
        morale: army.morale,
        supply: army.supply,
        path: [],
        moveProgress: 0,
        inBattleId: null,
        isRetreating: false,
      };
      break;
    }

    case 'MERGE_ARMIES': {
      const candidates = Object.values(state.armies).filter(
        (a) => a.countryId === countryId && a.provinceId === action.provinceId && !a.inBattleId
      );
      if (candidates.length < 2) return;
      const primary = candidates[0];
      for (let i = 1; i < candidates.length; i++) {
        const sec = candidates[i];
        primary.units.infantry += sec.units.infantry;
        primary.units.tank += sec.units.tank;
        primary.units.antitank += sec.units.antitank;
        primary.units.artillery += sec.units.artillery;
        primary.units.motorized += sec.units.motorized;
        primary.units.antiair += sec.units.antiair;
        if (sec.commanderId && country.commanders[sec.commanderId]) {
          country.commanders[sec.commanderId].assignedArmyId = null;
        }
        delete state.armies[sec.id];
      }
      break;
    }

    case 'BUILD_AIR_WING': {
      const prov = state.provinces[action.provinceId];
      const spec = AIR_UNITS[action.airType];
      if (!prov || prov.controllerId !== countryId || !spec) return;
      if (prov.buildings.airbase <= 0) return;
      if (spec.requiredTech && !country.researchedTechs.includes(spec.requiredTech)) return;
      if (country.money < spec.moneyCost) return;

      const currentPlanes = Object.values(state.airWings)
        .filter((w) => w.provinceId === action.provinceId)
        .reduce((s, w) => s + w.count, 0);
      const maxCap = prov.buildings.airbase * 30;
      if (currentPlanes + 10 > maxCap) return;

      country.money -= spec.moneyCost;
      const existing = Object.values(state.airWings).find(
        (w) => w.countryId === countryId && w.provinceId === action.provinceId && w.type === action.airType
      );
      if (existing) {
        existing.count += 10;
      } else {
        const wid = `wing_${countryId}_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
        state.airWings[wid] = {
          id: wid,
          countryId,
          provinceId: action.provinceId,
          type: action.airType,
          count: 10,
          mission: 'air_superiority',
          targetProvinceId: action.provinceId,
        };
      }
      break;
    }

    case 'SET_AIR_MISSION': {
      const wing = state.airWings[action.wingId];
      if (!wing || wing.countryId !== countryId) return;
      wing.mission = action.mission;
      wing.targetProvinceId = action.targetProvinceId;
      break;
    }

    case 'BUILD_SHIP': {
      const prov = state.provinces[action.provinceId];
      const spec = NAVAL_UNITS[action.shipType];
      if (!prov || prov.controllerId !== countryId || !spec) return;
      if (prov.buildings.port <= 0) return;
      if (spec.requiredTech && !country.researchedTechs.includes(spec.requiredTech)) return;
      if (country.money < spec.moneyCost) return;

      country.money -= spec.moneyCost;
      country.shipQueue.push({
        id: `shipq_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
        provinceId: action.provinceId,
        shipType: action.shipType,
        daysRemaining: spec.buildDays,
        totalDays: spec.buildDays,
      });
      break;
    }

    case 'MOVE_FLEET': {
      const fleet = state.fleets[action.fleetId];
      if (!fleet || fleet.countryId !== countryId) return;
      if (action.mission === 'docked') {
        const ownPort = Object.values(state.provinces).find(
          (p) => p.controllerId === countryId && p.buildings.port > 0
        );
        if (ownPort) {
          fleet.isAtSea = false;
          fleet.locationId = ownPort.id;
          fleet.mission = 'docked';
          fleet.targetSeaZoneId = null;
        }
      } else {
        const seaExists = mapData.seaZones.some((s) => s.id === action.targetSeaZoneId);
        if (!seaExists) return;
        fleet.isAtSea = true;
        fleet.locationId = action.targetSeaZoneId;
        fleet.mission = action.mission;
        fleet.targetSeaZoneId = action.targetSeaZoneId;
      }
      break;
    }

    case 'LAUNCH_NUKE': {
      if (country.nukes <= 0) return;
      const targetProv = state.provinces[action.targetProvinceId];
      if (!targetProv || targetProv.controllerId === countryId) return;
      const rel = getRelation(state.relations, countryId, targetProv.controllerId);
      if (!rel.atWar) return;

      country.nukes -= 1;
      targetProv.nuked = true;
      targetProv.buildings.factory = Math.max(0, Math.floor(targetProv.buildings.factory * 0.4));
      targetProv.buildings.military_base = 0;

      // Inflict massive casualties on garrisoned armies in that province
      for (const army of Object.values(state.armies)) {
        if (army.provinceId === targetProv.id && army.countryId === targetProv.controllerId) {
          army.units.infantry = Math.floor(army.units.infantry * 0.35);
          army.units.tank = Math.floor(army.units.tank * 0.4);
          army.units.artillery = Math.floor(army.units.artillery * 0.35);
          army.units.antitank = Math.floor(army.units.antitank * 0.35);
          army.morale = 15;
        }
      }

      const provName = mapData.provinces.find((p) => p.id === targetProv.id)?.name || targetProv.id;
      state.notifications.unshift({
        id: `notif_nuke_${Date.now()}`,
        day: state.day,
        type: 'nuke',
        title: `NÜKLEER SALDIRI: ${provName}`,
        message: `${COUNTRIES[countryId]?.name} tarafından ${provName} üzerine atom bombası atıldı!`,
      });
      break;
    }

    default:
      break;
  }
}

function executePeaceTreaty(
  state: GameState,
  mapData: MapDataStatic,
  fromCountryId: string,
  toCountryId: string,
  terms: PeaceTreatyTerms
) {
  const fromCountry = state.countries[fromCountryId];
  const toCountry = state.countries[toCountryId];
  if (!fromCountry || !toCountry) return;

  const key = relationKey(fromCountryId, toCountryId);
  const rel = state.relations[key] || {
    countryA: fromCountryId < toCountryId ? fromCountryId : toCountryId,
    countryB: fromCountryId < toCountryId ? toCountryId : fromCountryId,
    opinion: -20,
    atWar: false,
    allied: false,
    nonAggression: false,
  };
  rel.atWar = false;
  rel.opinion = Math.max(-35, rel.opinion);
  state.relations[key] = rel;

  // Clear pending peace offers between the two sides
  state.peaceOffers = state.peaceOffers.filter(
    (o) =>
      !(
        (o.fromCountryId === fromCountryId && o.toCountryId === toCountryId) ||
        (o.fromCountryId === toCountryId && o.toCountryId === fromCountryId)
      )
  );

  // Stop any active battles between these two sides
  for (const [bid, b] of Object.entries(state.battles)) {
    if (
      (b.attackerCountryId === fromCountryId && b.defenderCountryId === toCountryId) ||
      (b.defenderCountryId === fromCountryId && b.attackerCountryId === toCountryId)
    ) {
      for (const aid of [...b.attacker.armyIds, ...b.defender.armyIds]) {
        if (state.armies[aid]) state.armies[aid].inBattleId = null;
      }
      delete state.battles[bid];
    }
  }

  // Stop armies marching onto each other's land unless allied/vassalized
  for (const army of Object.values(state.armies)) {
    if (
      (army.countryId === fromCountryId || army.countryId === toCountryId) &&
      army.path.length > 0
    ) {
      army.path = [];
      army.moveProgress = 0;
    }
  }

  // Transfer demanded provinces (preserve >= 1 province if target will become vassal)
  let targetOwnedCount = Object.values(state.provinces).filter((p) => p.controllerId === toCountryId).length;
  for (const pid of terms.demandProvinceIds) {
    if (state.provinces[pid]?.controllerId !== toCountryId) continue;
    if (terms.vassalizeTarget && targetOwnedCount <= 1) break;
    captureProvince(state, mapData, pid, fromCountryId, false);
    targetOwnedCount -= 1;
  }

  // Transfer ceded provinces
  let myOwnedCount = Object.values(state.provinces).filter((p) => p.controllerId === fromCountryId).length;
  for (const pid of terms.cedeProvinceIds) {
    if (state.provinces[pid]?.controllerId !== fromCountryId) continue;
    if (terms.becomeVassal && myOwnedCount <= 1) break;
    captureProvince(state, mapData, pid, toCountryId, false);
    myOwnedCount -= 1;
  }

  // Financial & Manpower Reparations
  const paidMoney = Math.min(toCountry.money, Math.max(0, terms.demandMoney));
  toCountry.money -= paidMoney;
  fromCountry.money += paidMoney;

  const paidManpower = Math.min(toCountry.manpower, Math.max(0, terms.demandManpower));
  toCountry.manpower -= paidManpower;
  fromCountry.manpower = Math.min(fromCountry.maxManpower, fromCountry.manpower + paidManpower);

  // Vassalization terms
  let vassalMsg = '';
  if (terms.vassalizeTarget && !toCountry.eliminated && targetOwnedCount > 0) {
    toCountry.vassalOfId = fromCountryId;
    rel.allied = true;
    rel.nonAggression = true;
    rel.opinion = 25;
    vassalMsg = ` ${COUNTRIES[toCountryId]?.name}, ${COUNTRIES[fromCountryId]?.name} vasalı oldu!`;
  } else if (terms.becomeVassal && !fromCountry.eliminated && myOwnedCount > 0) {
    fromCountry.vassalOfId = toCountryId;
    rel.allied = true;
    rel.nonAggression = true;
    rel.opinion = 25;
    vassalMsg = ` ${COUNTRIES[fromCountryId]?.name}, ${COUNTRIES[toCountryId]?.name} vasallığını kabul etti.`;
  }

  recalculateAllCountryEconomies(state);

  state.notifications.unshift({
    id: `notif_peace_${Date.now()}_${Math.random()}`,
    day: state.day,
    type: 'peace',
    title: 'Barış Antlaşması İmzalandı',
    message: `${COUNTRIES[fromCountryId]?.name} ve ${COUNTRIES[toCountryId]?.name} arasında barış sağlandı.${vassalMsg}`,
  });
}
