import type {
  Army,
  ArmyComposition,
  Battle,
  GameState,
  LandUnitType,
  MapDataStatic,
} from '../../src/shared/types.ts';
import { AIR_UNITS, LAND_UNITS, TERRAIN_MODIFIERS } from '../../src/shared/data/units.ts';
import { HISTORICAL_COMMANDERS } from '../../src/shared/data/commanders.ts';
import { COUNTRIES } from '../../src/shared/data/countries.ts';
import {
  autoMergeStationaryArmies,
  getArmyTotal,
  getCountryModifiers,
  getRelation,
} from '../../src/shared/utils/gameHelpers.ts';

function getCommanderData(countryId: string, commanderId: string | null) {
  if (!commanderId) return null;
  const found = HISTORICAL_COMMANDERS.find((c) => c.id === commanderId);
  if (found) return found;
  // Generic staff fallback matches getCommandersForCountry formula
  const slotMatch = commanderId.match(/_staff_(\d+)$/);
  const slot = slotMatch ? Number(slotMatch[1]) : 1;
  return {
    id: commanderId,
    countryId,
    name: `Komutan #${slot}`,
    attackBonus: 0.04 + (slot % 3) * 0.02,
    defenseBonus: 0.05 + ((slot + 1) % 3) * 0.02,
    tankBonus: 0.04 + (slot % 2) * 0.03,
    infantryBonus: 0.05 + ((slot + 1) % 2) * 0.03,
    xpBonus: 0.05 + (slot % 3) * 0.02,
  };
}

function emptyComp(): ArmyComposition {
  return { infantry: 0, tank: 0, antitank: 0, artillery: 0, motorized: 0, antiair: 0 };
}

function calculateSidePower(
  state: GameState,
  mapData: MapDataStatic,
  armyIds: string[],
  isAttacker: boolean,
  provinceId: string,
  enemyHasTanks: number,
  enemyArtilleryRatio: number,
  enemyAirPower: number
) {
  const provStatic = mapData.provinces.find((p) => p.id === provinceId)!;
  const provState = state.provinces[provinceId];
  const terrain = TERRAIN_MODIFIERS[provStatic.terrain];

  let rawPower = 0;
  let totalStrength = 0;
  let totalTankShare = 0;
  let totalAaPower = 0;
  let commanderBonusSum = 0;
  let techBonusSum = 0;
  let supplySum = 0;
  let commanderCount = 0;

  for (const aid of armyIds) {
    const army = state.armies[aid];
    if (!army) continue;
    const str = getArmyTotal(army.units);
    if (str <= 0) continue;
    totalStrength += str;

    const country = state.countries[army.countryId];
    const mods = getCountryModifiers(country);
    const cmd = getCommanderData(army.countryId, army.commanderId);
    const cmdState = army.commanderId ? country.commanders[army.commanderId] : null;
    const cmdLevelScale = cmdState ? 1 + (cmdState.level - 1) * 0.12 : 1;

    const cmdInf = cmd ? cmd.infantryBonus * cmdLevelScale : 0;
    const cmdTank = cmd ? cmd.tankBonus * cmdLevelScale : 0;
    const cmdGen = cmd ? (isAttacker ? cmd.attackBonus : cmd.defenseBonus) * cmdLevelScale : 0;
    if (cmd) {
      commanderBonusSum += (cmdGen + (cmdInf + cmdTank) * 0.5) * str;
      commanderCount++;
    }

    const expFactor = 1 + (army.experience / 100) * 0.25;
    const moraleFactor = 0.65 + (army.morale / 100) * 0.35;
    const supplyFactor = 0.55 + (army.supply / 100) * 0.45;
    supplySum += army.supply * str;

    const infPower =
      army.units.infantry *
      (isAttacker ? LAND_UNITS.infantry.attack : LAND_UNITS.infantry.defense) *
      (isAttacker ? mods.infantryAttack : mods.infantryDefense) *
      (1 + cmdInf);

    const motPower =
      army.units.motorized *
      (isAttacker ? LAND_UNITS.motorized.attack : LAND_UNITS.motorized.defense) *
      (isAttacker ? mods.infantryAttack : mods.infantryDefense) *
      (1 + cmdInf);

    const tankPower =
      army.units.tank *
      (isAttacker ? LAND_UNITS.tank.attack : LAND_UNITS.tank.defense) *
      (isAttacker ? mods.tankAttack : mods.tankDefense) *
      (1 + cmdTank);

    totalTankShare += army.units.tank;

    // Anti-tank shines when enemy has tanks
    const atMultiplier = 1 + Math.min(1.8, enemyHasTanks * 0.08);
    const atPower =
      army.units.antitank *
      (isAttacker ? LAND_UNITS.antitank.attack : LAND_UNITS.antitank.defense) *
      mods.antitankPower *
      atMultiplier;

    const artPower =
      army.units.artillery *
      (isAttacker ? LAND_UNITS.artillery.attack : LAND_UNITS.artillery.defense) *
      mods.artilleryPower;

    const aaPower = army.units.antiair * LAND_UNITS.antiair.defense * mods.antiairPower;
    totalAaPower += army.units.antiair * LAND_UNITS.antiair.antiAir * mods.antiairPower;

    const armyBase = infPower + motPower + tankPower + atPower + artPower + aaPower;
    rawPower += armyBase * (1 + cmdGen) * expFactor * moraleFactor * supplyFactor;

    const avgTech =
      ((mods.infantryAttack + mods.infantryDefense + mods.tankAttack + mods.artilleryPower) / 4 - 1) * 100;
    techBonusSum += avgTech * str;
  }

  if (totalStrength <= 0) {
    return {
      power: 0,
      strength: 0,
      techBonusPct: 0,
      commanderBonusPct: 0,
      terrainBonusPct: 0,
      airSupportPct: 0,
      supplyPenaltyPct: 0,
    };
  }

  // Terrain & fortification
  let terrainMult = isAttacker ? terrain.attackMod : terrain.defenseMod;
  if (!isAttacker && provState) {
    // Military base fortification + artillery suppression from attacker
    const fortBonus = provState.buildings.military_base * 0.14;
    const suppressedFort = fortBonus * Math.max(0.25, 1 - enemyArtilleryRatio * 1.4);
    terrainMult += suppressedFort;
  }

  // Air support for this side vs enemy AA + radar
  const radarMitigation = !isAttacker ? 0 : (provState?.buildings.radar || 0) * 0.12;
  const aaMitigation = Math.min(0.65, totalAaPower / Math.max(100, enemyAirPower * 4 + 100));
  const netAirBonus = Math.max(0, (enemyAirPower > 0 ? 0 : 0)); // placeholder below

  // Compute own air wings targeting this province or nearby
  const sideCountryIds = new Set(armyIds.map((id) => state.armies[id]?.countryId).filter(Boolean));
  let ownAirGround = 0;
  let ownAirFighters = 0;
  for (const wing of Object.values(state.airWings)) {
    if (!sideCountryIds.has(wing.countryId) || wing.count <= 0) continue;
    if (wing.mission === 'idle') continue;
    const inRange =
      wing.targetProvinceId === provinceId ||
      wing.provinceId === provinceId ||
      provStatic.neighbors.includes(wing.provinceId);
    if (!inRange) continue;
    const spec = AIR_UNITS[wing.type];
    const mods = getCountryModifiers(state.countries[wing.countryId]);
    if (wing.mission === 'cas' || wing.mission === 'bombing') {
      ownAirGround += wing.count * spec.groundSupport * mods.airPower * 0.04;
    } else if (wing.mission === 'air_superiority' || wing.mission === 'recon') {
      ownAirFighters += wing.count * (spec.airAttack + spec.reconBonus) * mods.airPower * 0.025;
    }
  }
  const airMult = 1 + Math.min(0.38, (ownAirGround + ownAirFighters) * (1 - radarMitigation) * (1 - aaMitigation));
  void netAirBonus;

  const finalPower = rawPower * terrainMult * airMult;

  return {
    power: finalPower,
    strength: totalStrength,
    techBonusPct: Math.round(techBonusSum / totalStrength),
    commanderBonusPct: commanderCount > 0 ? Math.round((commanderBonusSum / totalStrength) * 100) : 0,
    terrainBonusPct: Math.round((terrainMult - 1) * 100),
    airSupportPct: Math.round((airMult - 1) * 100),
    supplyPenaltyPct: Math.round((1 - supplySum / (totalStrength * 100)) * 100),
  };
}

function applyCasualtiesToArmies(
  state: GameState,
  armyIds: string[],
  totalLossK: number,
  lossAccumulator: ArmyComposition
) {
  if (totalLossK <= 0) return;
  const activeArmies = armyIds
    .map((id) => state.armies[id])
    .filter((a) => a && getArmyTotal(a.units) > 0);
  const sumStr = activeArmies.reduce((acc, a) => acc + getArmyTotal(a.units), 0);
  if (sumStr <= 0) return;

  const unitTypes: LandUnitType[] = ['infantry', 'motorized', 'tank', 'antitank', 'artillery', 'antiair'];
  let remainingLoss = Math.min(sumStr, Math.max(1, Math.round(totalLossK)));

  // Distribute proportionally across unit types inside armies
  for (const army of activeArmies) {
    if (remainingLoss <= 0) break;
    const armyStr = getArmyTotal(army.units);
    const share = Math.max(1, Math.round((armyStr / sumStr) * remainingLoss));
    let leftForArmy = Math.min(armyStr, share);

    while (leftForArmy > 0) {
      let deducted = false;
      for (const ut of unitTypes) {
        if (leftForArmy <= 0) break;
        if (army.units[ut] > 0) {
          army.units[ut] -= 1;
          lossAccumulator[ut] += 1;
          leftForArmy -= 1;
          remainingLoss -= 1;
          deducted = true;
        }
      }
      if (!deducted) break;
    }

    // Combat grants experience and reduces morale slightly
    const cmdBonus = army.commanderId ? 1.15 : 1.0;
    army.experience = Math.min(100, army.experience + 1.2 * cmdBonus);
    army.morale = Math.max(15, army.morale - 2.2);

    if (army.commanderId) {
      const cmdState = state.countries[army.countryId]?.commanders[army.commanderId];
      if (cmdState) {
        cmdState.xp += 12;
        if (cmdState.xp >= cmdState.level * 100) {
          cmdState.xp -= cmdState.level * 100;
          cmdState.level = Math.min(10, cmdState.level + 1);
        }
      }
    }
  }
}

export function startOrJoinBattle(
  state: GameState,
  mapData: MapDataStatic,
  attackerArmy: Army,
  fromProvinceId: string,
  targetProvinceId: string
) {
  const defenderArmies = Object.values(state.armies).filter(
    (a) =>
      a.provinceId === targetProvinceId &&
      a.countryId !== attackerArmy.countryId &&
      getArmyTotal(a.units) > 0 &&
      getRelation(state.relations, attackerArmy.countryId, a.countryId).atWar
  );

  if (defenderArmies.length === 0) return null;

  // Check if a battle already exists in targetProvinceId
  const existing = Object.values(state.battles).find((b) => b.provinceId === targetProvinceId);
  if (existing) {
    const isAtkSide =
      existing.attackerCountryId === attackerArmy.countryId ||
      getRelation(state.relations, attackerArmy.countryId, existing.attackerCountryId).allied;
    const isDefSide =
      existing.defenderCountryId === attackerArmy.countryId ||
      getRelation(state.relations, attackerArmy.countryId, existing.defenderCountryId).allied;

    if (isAtkSide) {
      if (!existing.attacker.armyIds.includes(attackerArmy.id)) {
        existing.attacker.armyIds.push(attackerArmy.id);
        existing.attacker.initialStrength += getArmyTotal(attackerArmy.units);
      }
      attackerArmy.inBattleId = existing.id;
      attackerArmy.moveProgress = 0;
    } else if (isDefSide) {
      if (!existing.defender.armyIds.includes(attackerArmy.id)) {
        existing.defender.armyIds.push(attackerArmy.id);
        existing.defender.initialStrength += getArmyTotal(attackerArmy.units);
      }
      attackerArmy.inBattleId = existing.id;
      attackerArmy.moveProgress = 0;
    }
    return existing;
  }

  const defCountryId = defenderArmies[0].countryId;
  if (defCountryId === attackerArmy.countryId) return null;
  const battleId = `bat_${targetProvinceId}_${state.day}_${Math.random().toString(36).slice(2, 6)}`;
  const atkStrength = getArmyTotal(attackerArmy.units);
  const defStrength = defenderArmies.reduce((acc, a) => acc + getArmyTotal(a.units), 0);

  const atkCmd = attackerArmy.commanderId
    ? HISTORICAL_COMMANDERS.find((c) => c.id === attackerArmy.commanderId)?.name || 'Komutan'
    : null;
  const defWithCmd = defenderArmies.find((a) => a.commanderId);
  const defCmd = defWithCmd?.commanderId
    ? HISTORICAL_COMMANDERS.find((c) => c.id === defWithCmd.commanderId)?.name || 'Komutan'
    : null;

  const battle: Battle = {
    id: battleId,
    provinceId: targetProvinceId,
    fromProvinceId,
    attackerCountryId: attackerArmy.countryId,
    defenderCountryId: defCountryId,
    startDay: state.day,
    attacker: {
      countryId: attackerArmy.countryId,
      armyIds: [attackerArmy.id],
      initialStrength: atkStrength,
      currentStrength: atkStrength,
      casualties: emptyComp(),
      commanderName: atkCmd,
      modifiers: { techBonus: 0, commanderBonus: 0, terrainBonus: 0, airSupport: 0, supplyPenalty: 0 },
    },
    defender: {
      countryId: defCountryId,
      armyIds: defenderArmies.map((a) => a.id),
      initialStrength: defStrength,
      currentStrength: defStrength,
      casualties: emptyComp(),
      commanderName: defCmd,
      modifiers: { techBonus: 0, commanderBonus: 0, terrainBonus: 0, airSupport: 0, supplyPenalty: 0 },
    },
    progress: 50,
  };

  attackerArmy.inBattleId = battleId;
  attackerArmy.moveProgress = 0;
  for (const d of defenderArmies) {
    d.inBattleId = battleId;
    d.moveProgress = 0;
  }
  state.battles[battleId] = battle;

  const provName = mapData.provinces.find((p) => p.id === targetProvinceId)?.name || targetProvinceId;
  state.notifications.unshift({
    id: `notif_${Date.now()}_${Math.random()}`,
    day: state.day,
    type: 'war',
    title: `${provName} Muharebesi Başladı`,
    message: `${COUNTRIES[attackerArmy.countryId]?.name || attackerArmy.countryId} (${atkStrength}K) ile ${COUNTRIES[defCountryId]?.name || defCountryId} (${defStrength}K) çatışıyor.`,
  });
  if (state.notifications.length > 40) state.notifications.length = 40;

  return battle;
}

export function tickBattles(state: GameState, mapData: MapDataStatic) {
  for (const battleId of Object.keys(state.battles)) {
    const battle = state.battles[battleId];
    if (!battle) continue;

    // Filter still-alive armies
    battle.attacker.armyIds = battle.attacker.armyIds.filter(
      (id) => state.armies[id] && getArmyTotal(state.armies[id].units) > 0
    );
    battle.defender.armyIds = battle.defender.armyIds.filter(
      (id) => state.armies[id] && getArmyTotal(state.armies[id].units) > 0
    );

    const atkTanks = battle.attacker.armyIds.reduce(
      (acc, id) => acc + (state.armies[id]?.units.tank || 0),
      0
    );
    const defTanks = battle.defender.armyIds.reduce(
      (acc, id) => acc + (state.armies[id]?.units.tank || 0),
      0
    );
    const atkStrNow = battle.attacker.armyIds.reduce(
      (acc, id) => acc + getArmyTotal(state.armies[id].units),
      0
    );
    const defStrNow = battle.defender.armyIds.reduce(
      (acc, id) => acc + getArmyTotal(state.armies[id].units),
      0
    );
    const atkArtRatio = atkStrNow > 0
      ? battle.attacker.armyIds.reduce((acc, id) => acc + (state.armies[id]?.units.artillery || 0), 0) / atkStrNow
      : 0;
    const defArtRatio = defStrNow > 0
      ? battle.defender.armyIds.reduce((acc, id) => acc + (state.armies[id]?.units.artillery || 0), 0) / defStrNow
      : 0;

    const atkStats = calculateSidePower(
      state,
      mapData,
      battle.attacker.armyIds,
      true,
      battle.provinceId,
      defTanks,
      defArtRatio,
      0
    );
    const defStats = calculateSidePower(
      state,
      mapData,
      battle.defender.armyIds,
      false,
      battle.provinceId,
      atkTanks,
      atkArtRatio,
      0
    );

    battle.attacker.currentStrength = atkStats.strength;
    battle.defender.currentStrength = defStats.strength;
    battle.attacker.modifiers = {
      techBonus: atkStats.techBonusPct,
      commanderBonus: atkStats.commanderBonusPct,
      terrainBonus: atkStats.terrainBonusPct,
      airSupport: atkStats.airSupportPct,
      supplyPenalty: atkStats.supplyPenaltyPct,
    };
    battle.defender.modifiers = {
      techBonus: defStats.techBonusPct,
      commanderBonus: defStats.commanderBonusPct,
      terrainBonus: defStats.terrainBonusPct,
      airSupport: defStats.airSupportPct,
      supplyPenalty: defStats.supplyPenaltyPct,
    };

    if (atkStats.strength <= 0 || defStats.strength <= 0) {
      resolveBattleEnd(state, mapData, battle, defStats.strength <= 0 ? battle.attackerCountryId : battle.defenderCountryId);
      continue;
    }

    // Daily casualty exchange scaled cleanly by combat power superiority ratio
    const totalPower = Math.max(1, atkStats.power + defStats.power);
    const atkShare = atkStats.power / totalPower;
    const defShare = defStats.power / totalPower;
    const powerRatio = atkStats.power / Math.max(1, defStats.power);
    const ratioFactor = Math.pow(Math.max(0.25, Math.min(4, powerRatio)), 0.5);

    const baseIntensity = Math.max(1, Math.min(8, Math.round((atkStats.strength + defStats.strength) * 0.08)));
    const defLosses = Math.max(1, Math.round(baseIntensity * Math.min(2.5, 0.3 + atkShare * 1.65 * ratioFactor)));
    const atkLosses = Math.max(1, Math.round(baseIntensity * Math.min(2.5, 0.3 + (defShare * 1.65) / ratioFactor)));

    applyCasualtiesToArmies(state, battle.defender.armyIds, defLosses, battle.defender.casualties);
    applyCasualtiesToArmies(state, battle.attacker.armyIds, atkLosses, battle.attacker.casualties);

    state.countries[battle.attackerCountryId].totalCasualtiesInflicted += defLosses;
    state.countries[battle.attackerCountryId].totalCasualtiesTaken += atkLosses;
    state.countries[battle.defenderCountryId].totalCasualtiesInflicted += atkLosses;
    state.countries[battle.defenderCountryId].totalCasualtiesTaken += defLosses;

    // Shift battle progress bar
    const delta = (atkShare - 0.5) * 44;
    battle.progress = Math.max(0, Math.min(100, battle.progress + delta));

    // Recompute strength after casualties
    const atkLeft = battle.attacker.armyIds.reduce(
      (acc, id) => acc + getArmyTotal(state.armies[id].units),
      0
    );
    const defLeft = battle.defender.armyIds.reduce(
      (acc, id) => acc + getArmyTotal(state.armies[id].units),
      0
    );
    battle.attacker.currentStrength = atkLeft;
    battle.defender.currentStrength = defLeft;

    if (defLeft <= 0 || battle.progress >= 98) {
      resolveBattleEnd(state, mapData, battle, battle.attackerCountryId);
    } else if (atkLeft <= 0 || battle.progress <= 2) {
      resolveBattleEnd(state, mapData, battle, battle.defenderCountryId);
    }
  }
}

function resolveBattleEnd(
  state: GameState,
  mapData: MapDataStatic,
  battle: Battle,
  winnerCountryId: string
) {
  const provStatic = mapData.provinces.find((p) => p.id === battle.provinceId);
  const provName = provStatic?.name || battle.provinceId;

  // Release all participating armies from battle lock
  for (const id of [...battle.attacker.armyIds, ...battle.defender.armyIds]) {
    const army = state.armies[id];
    if (!army) continue;
    army.inBattleId = null;
    if (getArmyTotal(army.units) <= 0) {
      if (army.commanderId && state.countries[army.countryId]?.commanders[army.commanderId]) {
        state.countries[army.countryId].commanders[army.commanderId].assignedArmyId = null;
      }
      delete state.armies[id];
    }
  }

  if (winnerCountryId === battle.attackerCountryId) {
    // Surviving defender armies retreat to an adjacent friendly province if possible
    for (const defId of battle.defender.armyIds) {
      const defArmy = state.armies[defId];
      if (!defArmy) continue;
      const retreatProv = provStatic?.neighbors.find(
        (nb) => state.provinces[nb]?.controllerId === defArmy.countryId
      );
      if (retreatProv) {
        defArmy.provinceId = retreatProv;
        defArmy.path = [];
        defArmy.moveProgress = 0;
        defArmy.morale = Math.max(25, defArmy.morale - 15);
      } else {
        // Encircled and destroyed
        if (defArmy.commanderId && state.countries[defArmy.countryId]?.commanders[defArmy.commanderId]) {
          state.countries[defArmy.countryId].commanders[defArmy.commanderId].assignedArmyId = null;
        }
        delete state.armies[defId];
      }
    }

    // Move attacker armies into conquered province & flip ownership!
    for (const atkId of battle.attacker.armyIds) {
      const atkArmy = state.armies[atkId];
      if (!atkArmy) continue;
      atkArmy.provinceId = battle.provinceId;
      atkArmy.moveProgress = 0;
      if (atkArmy.path[0] === battle.provinceId) {
        atkArmy.path.shift();
      }
    }

    captureProvince(state, mapData, battle.provinceId, battle.attackerCountryId);
    autoMergeStationaryArmies(state, battle.attackerCountryId, battle.provinceId);
  } else {
    // Attacker pushed back
    for (const atkId of battle.attacker.armyIds) {
      const atkArmy = state.armies[atkId];
      if (!atkArmy) continue;
      if (atkArmy.provinceId === battle.provinceId) {
        const retreatProv = provStatic?.neighbors.find(
          (nb) => state.provinces[nb]?.controllerId === atkArmy.countryId
        );
        if (retreatProv) {
          atkArmy.provinceId = retreatProv;
        }
      }
      atkArmy.path = [];
      atkArmy.moveProgress = 0;
    }
  }

  const atkLosses = getArmyTotal(battle.attacker.casualties);
  const defLosses = getArmyTotal(battle.defender.casualties);

  state.battleHistory.unshift({
    id: battle.id,
    provinceId: battle.provinceId,
    provinceName: provName,
    attackerCountryId: battle.attackerCountryId,
    defenderCountryId: battle.defenderCountryId,
    winnerCountryId,
    attackerLosses: atkLosses,
    defenderLosses: defLosses,
    day: state.day,
  });
  if (state.battleHistory.length > 50) state.battleHistory.length = 50;

  delete state.battles[battle.id];
}

export function captureProvince(
  state: GameState,
  mapData: MapDataStatic,
  provinceId: string,
  newOwnerId: string,
  annexOnCapital = true
) {
  const prov = state.provinces[provinceId];
  if (!prov || prov.controllerId === newOwnerId) return;

  const oldOwnerId = prov.controllerId;
  prov.controllerId = newOwnerId;
  prov.ownerId = newOwnerId;

  const attacker = state.countries[newOwnerId];
  const defender = state.countries[oldOwnerId];
  if (attacker) attacker.provincesCaptured += 1;

  const provName = mapData.provinces.find((p) => p.id === provinceId)?.name || provinceId;
  const isCapitalFall = annexOnCapital && COUNTRIES[oldOwnerId]?.capitalProvinceId === provinceId;

  // Capital Capture = Total Capitulation & Full Annexation of all remaining defender provinces!
  if (isCapitalFall && defender && !defender.eliminated) {
    let annexedCount = 1;
    for (const p of Object.values(state.provinces)) {
      if (p.controllerId === oldOwnerId) {
        p.controllerId = newOwnerId;
        p.ownerId = newOwnerId;
        annexedCount += 1;
        if (attacker) attacker.provincesCaptured += 1;
      }
    }

    // Cancel any active battles involving the capitulated defender
    for (const [bid, b] of Object.entries(state.battles)) {
      if (b.attackerCountryId === oldOwnerId || b.defenderCountryId === oldOwnerId) {
        for (const aid of [...b.attacker.armyIds, ...b.defender.armyIds]) {
          if (state.armies[aid]) state.armies[aid].inBattleId = null;
        }
        delete state.battles[bid];
      }
    }

    // Remove eliminated country forces & release any vassals
    defender.eliminated = true;
    defender.vassalOfId = null;
    for (const c of Object.values(state.countries)) {
      if (c.vassalOfId === oldOwnerId) c.vassalOfId = null;
    }
    for (const a of Object.values(state.armies)) {
      if (a.countryId === oldOwnerId) delete state.armies[a.id];
    }
    for (const f of Object.values(state.fleets)) {
      if (f.countryId === oldOwnerId) delete state.fleets[f.id];
    }
    for (const w of Object.values(state.airWings)) {
      if (w.countryId === oldOwnerId) delete state.airWings[w.id];
    }

    state.notifications.unshift({
      id: `notif_cap_fall_${Date.now()}_${Math.random()}`,
      day: state.day,
      type: 'conquest',
      title: `Başkent Düştü: ${COUNTRIES[oldOwnerId]?.name || oldOwnerId} Tamamen Fethedildi!`,
      message: `${COUNTRIES[newOwnerId]?.name || newOwnerId}, ${provName} başkentini alarak ${annexedCount} eyaletin tamamını ilhak etti.`,
    });
    if (state.notifications.length > 40) state.notifications.length = 40;
    return;
  }

  // Check if oldOwner lost all provinces -> eliminated
  if (defender) {
    const remaining = Object.values(state.provinces).filter((p) => p.controllerId === oldOwnerId).length;
    if (remaining === 0) {
      defender.eliminated = true;
      defender.vassalOfId = null;
      for (const c of Object.values(state.countries)) {
        if (c.vassalOfId === oldOwnerId) c.vassalOfId = null;
      }
      for (const a of Object.values(state.armies)) {
        if (a.countryId === oldOwnerId) delete state.armies[a.id];
      }
      for (const f of Object.values(state.fleets)) {
        if (f.countryId === oldOwnerId) delete state.fleets[f.id];
      }
      for (const w of Object.values(state.airWings)) {
        if (w.countryId === oldOwnerId) delete state.airWings[w.id];
      }
      state.notifications.unshift({
        id: `notif_elim_${Date.now()}_${Math.random()}`,
        day: state.day,
        type: 'conquest',
        title: `${COUNTRIES[oldOwnerId]?.name || oldOwnerId} Teslim Oldu`,
        message: `${COUNTRIES[newOwnerId]?.name || newOwnerId} tüm toprakları ele geçirdi!`,
      });
    }
  }

  state.notifications.unshift({
    id: `notif_cap_${Date.now()}_${Math.random()}`,
    day: state.day,
    type: 'conquest',
    title: `${provName} Fethedildi`,
    message: `${COUNTRIES[newOwnerId]?.name || newOwnerId} kontrolü devraldı.`,
  });
  if (state.notifications.length > 40) state.notifications.length = 40;
}
